<?php

class Report extends My_Controller {

    private $user_type = null;

    public function __construct() {
        parent::__construct();

        $this->load->library('grocery_CRUD');

        if($this->session->has_userdata('user_id')) { //if logged-in
            $this->user_type = $this->session->usertype;
        }
    }

    public function index() {
        redirect(base_url('admin/report_item'));
    }

    public function check_permission($auth_usertype = array()) {
        //if not logged-in
        if($this->user_type == null) {
            $this->session->set_flashdata('title', 'Log-in!');
            $this->session->set_flashdata('msg', 'Kindly log-in to access that page.');
            redirect(base_url('admin'));
        }

        //if no special permission required (should be logged-in only)
        if(count($auth_usertype) == 0) {
            return true;
        }

        if(in_array($this->user_type, $auth_usertype)) {
            return true;
        } else {
            $this->session->set_flashdata('title', 'Prohibited!');
            $this->session->set_flashdata('msg', 'You do not have permission to access that page, kindly contact Administrator.');
            redirect(base_url('admin/dashboard'));
        }
    }
	
	public function report_item() {
        if($this->check_permission(array(1,2)) == true) {
            $this->load->model('Report_item_m');
            $data = $this->Report_item_m->report_item();
            $this->load->view($data['page'], $data['data']);
        }
    }
	
	public function ajax_item_detail_table_data(){
        if($this->check_permission(array(1,2)) == true) {
            $this->load->model('Report_item_m');
            $data = $this->Report_item_m->ajax_item_detail_table_data();
            echo json_encode($data, JSON_HEX_QUOT | JSON_HEX_TAG);
            exit();
        }
    }
	
    public function report_order_status() {
        if($this->check_permission(array(1,2)) == true) {
            $this->load->model('Report_order_status_m');
            $data = $this->Report_order_status_m->report_order_status();
            $this->load->view($data['page'], $data['data']);
        }
    }
    
    public function report_shipment_buyerwise_status() {
        if($this->check_permission(array(1,2)) == true) {
            $this->load->model('Report_order_status_m');
            $data = $this->Report_order_status_m->report_shipment_buyerwise_status();
            $this->load->view($data['page'], $data['data']);
        }
    }
    
    public function report_buyerwise_shipment_details() {
        if($this->check_permission(array(1,2)) == true) {
            $this->load->model('Report_order_status_m');
            $data = $this->Report_order_status_m->report_buyerwise_shipment_details();
            $this->load->view($data['page'], $data['data']);
        }
    }
    
    public function report_shipment_status() {
        if($this->check_permission(array(1,2)) == true) {
            $this->load->model('Report_order_status_m');
            $data = $this->Report_order_status_m->report_shipment_status();
            $this->load->view($data['page'], $data['data']);
        }
    }

    public function report_order_status_details() {
        if($this->check_permission(array(1,2)) == true) {
            $this->load->model('Report_order_status_m');
            $data = $this->Report_order_status_m->report_order_status_details();
            $this->load->view($data['page'], $data['data']);
        }
    }
    
    public function report_material_status_details() {
        if($this->check_permission(array(1,2)) == true) {
            $this->load->model('Report_order_status_m');
            $data = $this->Report_order_status_m->report_material_status_details();
            $this->load->view($data['page'], $data['data']);
        }
    }
    
    public function material_issue_status() {
        if($this->check_permission(array(1,2)) == true) {
            $this->load->model('Report_order_status_m');
            $data = $this->Report_order_status_m->material_issue_status();
            $this->load->view($data['page'], $data['data']);
        }
    }
    
    public function report_shipment_details() {
        if($this->check_permission(array(1,2)) == true) {
            $this->load->model('Report_order_status_m');
            $data = $this->Report_order_status_m->report_shipment_details();
            $this->load->view($data['page'], $data['data']);
        }
    }
	
    public function ajax_fetch_article_on_group(){
        if($this->check_permission(array(1,2)) == true) {
            $this->load->model('Report_order_status_m');
            $data = $this->Report_order_status_m->ajax_fetch_article_on_group();
            // echo '<pre>',print_r($res),'</pre>'; die;
            echo json_encode($data, JSON_HEX_QUOT | JSON_HEX_TAG);
            exit();
        }
    }

    public function jobber_ledger() {
        if($this->check_permission(array(1,2)) == true) {
            $this->load->model('Report_order_status_m');
            $job = $this->input->post('fab[]');
            $from = $this->input->post('from');
                $to = $this->input->post('to');
                $job_type = $this->input->post('jobber_type');
            $data = $this->Report_order_status_m->jobber_ledger_status($job , $from, $to, $job_type);
            $this->load->view($data['page'], $data['data']);
        }
    }

    public function report_leather_status() {
        if($this->check_permission(array(1,2)) == true) {
            $this->load->model('Report_order_status_m');
            $data = $this->Report_order_status_m->fetch_report_leather_status();
            $this->load->view($data['page'], $data['data']);
        }
    }
    
    public function report_article_costing_details() {
        if($this->check_permission(array(1,2)) == true) {
            $this->load->model('Report_order_status_m');
            $data = $this->Report_order_status_m->report_article_costing_details();
            $this->load->view($data['page'], $data['data']);
        }
    }

    public function report_item_status() {
        if($this->check_permission(array(1,2)) == true) {
            $this->load->model('Report_order_status_m');
            $data = $this->Report_order_status_m->fetch_report_item_status();
            $this->load->view($data['page'], $data['data']);
        }
    }

    public function checking_summary_status() {
        if($this->check_permission(array(1,2)) == true) {
            $this->load->model('Report_order_status_m');
            $data = $this->Report_order_status_m->fetch_checking_summary_status_v();
            $this->load->view($data['page'], $data['data']);
        }
    }

    public function stock_summary_status(){
        $this->load->model('Report_order_status_m');
    $data = $this->Report_order_status_m->fetch_stock_summary_status();
            $this->load->view($data['page'], $data['data']);
            // $this->load->view('report/stock_detail_ledger', $data)
    }

public function fetch_items_on_item_group(){
        $this->load->model('Report_order_status_m');
        $datam =$this->Report_order_status_m->items_on_item_group_m($this->input->post('gr_id'));
        echo json_encode($datam);
    }

    public function fetch_articles_on_article_group(){
        $this->load->model('Report_order_status_m');
        $datam =$this->Report_order_status_m->fetch_articles_on_article_group($this->input->post('gr_id'));
        echo json_encode($datam);
    }

    public function stock_detail_ledger() {
        $this->load->model('Report_order_status_m');
    $data = $this->Report_order_status_m->fetch_stock_summary_ledger();
            $this->load->view($data['page'], $data['data']);
            // $this->load->view('report/stock_detail_ledger', $data)
    }

    public function supplier_wise_item_position() {
        $this->load->model('Report_order_status_m');
        $data = $this->Report_order_status_m->fetch_supplier_wise_item_position();
            $this->load->view($data['page'], $data['data']);
            // $this->load->view('report/stock_detail_ledger', $data)
    } 

    public function checking_entry_sheet() {
        $this->load->model('Report_order_status_m');
        $data = $this->Report_order_status_m->fetch_checking_entry_sheet();
            $this->load->view($data['page'], $data['data']);
            // $this->load->view('report/stock_detail_ledger', $data)
    }
    
    public function supplier_purchase_ledger() {
        $this->load->model('Report_order_status_m');
        $data = $this->Report_order_status_m->fetch_supplier_purchase_ledger();
            $this->load->view($data['page'], $data['data']);
            // $this->load->view('report/stock_detail_ledger', $data)
    }
    
    public function supplier_wise_purchase_position() {
        $this->load->model('Report_order_status_m');
        $data = $this->Report_order_status_m->fetch_supplier_wise_purchase_position();
            $this->load->view($data['page'], $data['data']);
            // $this->load->view('report/stock_detail_ledger', $data)
    }
    
    public function group_stock_summary() {
        $this->load->model('Report_order_status_m');
        $data = $this->Report_order_status_m->fetch_group_stock_summary();
            $this->load->view($data['page'], $data['data']);
            // $this->load->view('report/stock_detail_ledger', $data)
    }
    
    public function jobber_bill_summary() {
        $this->load->model('Report_order_status_m');
        $data = $this->Report_order_status_m->fetch_jobber_bill_summary();
            $this->load->view($data['page'], $data['data']);
            // $this->load->view('report/stock_detail_ledger', $data)
    }
    
    public function cutter_bill_summary() {
        $this->load->model('Report_order_status_m');
        $data = $this->Report_order_status_m->fetch_cutter_bill_summary();
            $this->load->view($data['page'], $data['data']);
            // $this->load->view('report/stock_detail_ledger', $data)
    }
    
    public function monthly_production_status() {
        $this->load->model('Report_order_status_m');
        $data = $this->Report_order_status_m->fetch_monthly_production_status();
            $this->load->view($data['page'], $data['data']);
            // $this->load->view('report/stock_detail_ledger', $data)
    }
    
    public function production_register() {
        $this->load->model('Report_order_status_m');
        $data = $this->Report_order_status_m->fetch_production_register();
            $this->load->view($data['page'], $data['data']);
            // $this->load->view('report/stock_detail_ledger', $data)
    }
    
    public function outstanding_report() {
        $this->load->model('Report_order_status_m');
        $data = $this->Report_order_status_m->fetch_outstanding_report();
            $this->load->view($data['page'], $data['data']);
            // $this->load->view('report/stock_detail_ledger', $data)
    }
    
    public function payroll_reports() {
        $this->load->model('Report_order_status_m');
        $data = $this->Report_order_status_m->fetch_payroll_reports();
            $this->load->view($data['page'], $data['data']);
            // $this->load->view('report/stock_detail_ledger', $data)
    }
    
    public function get_fetch_all_item_for_supplier_basis(){

        if($this->check_permission(array(1,2)) == true) {

            $this->load->model('Report_order_status_m');

            $data = $this->Report_order_status_m->get_fetch_all_item_for_supplier_basis();

            echo json_encode($data, JSON_HEX_QUOT | JSON_HEX_TAG);

            exit();

        }

    }
    
     public function get_fetch_all_order_for_supplier_basis(){

        if($this->check_permission(array(1,2)) == true) {

            $this->load->model('Report_order_status_m');

            $data = $this->Report_order_status_m->get_fetch_all_order_for_supplier_basis();

            echo json_encode($data, JSON_HEX_QUOT | JSON_HEX_TAG);

            exit();

        }

    }
    
    
     public function get_fetch_all_item_for_costings_article(){

        if($this->check_permission(array(1,2)) == true) {

            $this->load->model('Report_order_status_m');

            $data = $this->Report_order_status_m->get_fetch_all_item_for_costings_article();

            echo json_encode($data, JSON_HEX_QUOT | JSON_HEX_TAG);

            exit();

        }

    }
    
    
    public function get_fetch_all_item_for_costings_article_all_details(){

        if($this->check_permission(array(1,2)) == true) {

            $this->load->model('Report_order_status_m');

            $data = $this->Report_order_status_m->get_fetch_all_item_for_costings_article_all_details();

            echo json_encode($data, JSON_HEX_QUOT | JSON_HEX_TAG);

            exit();

        }

    }


    public function article_master_report() {
        $this->load->model('Report_order_status_m');
        $data = $this->Report_order_status_m->article_master_report();
            $this->load->view($data['page'], $data['data']);
            // $this->load->view('report/stock_detail_ledger', $data)
    }
    
    public function overtime_reports_m() {
        $this->load->model('Report_order_status_m');
        $data = $this->Report_order_status_m->overtime_reports_details_m();
        $this->load->view($data['page'], $data['data']);
        // $this->load->view('report/stock_detail_ledger', $data)
    }
    
}//end ctrl

?>