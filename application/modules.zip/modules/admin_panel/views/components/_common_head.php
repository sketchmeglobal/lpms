<?php
/**
 * Coded by: Pran Krishna Das
 * Social: www.fb.com/pran93
 * CI: 3.0.6
 * Date: 09-07-17
 * Time: 12:00
 */
?>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<meta name="author" content="Pran Krishna Das">

<link href="<?=base_url();?>assets/img/favicon.ico" rel="shortcut icon" type="image/png">

<!--toastr-->
<link href="<?=base_url();?>assets/admin_panel/js/toastr-master/toastr.css" rel="stylesheet" type="text/css" />

<!--common style-->
<link href="<?=base_url();?>assets/admin_panel/css/style.css" rel="stylesheet">
<link href="<?=base_url();?>assets/admin_panel/css/style-responsive.css" rel="stylesheet">
<!--theme color layout-->
<link href="<?=base_url();?>assets/admin_panel/css/layout-theme-two.css" rel="stylesheet">

<!--loading css-->
<link rel="stylesheet" href="<?=base_url();?>assets/admin_panel/css/loading.css" type="text/css" />

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
<script src="<?=base_url();?>assets/admin_panel/js/html5shiv.js"></script>
<script src="<?=base_url();?>assets/admin_panel/js/respond.min.js"></script>
<![endif]-->