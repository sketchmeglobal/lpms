<?php
/**
 * Coded by: Pran Krishna Das
 * Social: www.fb.com/pran93
 * CI: 3.0.6
 * Date: 09-07-17
 * Time: 12:00
 */

class Dashboard_m extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
    private function _dept_wise_module_permission($module_id,$user){

            $dept_id = $this->db->get_where('user_details', array('user_id' => $user))->result()[0]->user_dept;
            if($dept_id != NULL){
                $nr = $this->db->where('module_permission_id', $module_id)->where('FIND_IN_SET('.$dept_id.', dept_id) !=', 0)->get('module_permission')->num_rows();
                // echo $this->db->last_query(); die;
                if($nr == 0){
                    # show-all
                    return 'show';
                }else{
                    # filter according to dept id
                    return $dept_id;
                }
            }else{
                return 'show';
            }
            
        }

        private function _user_wise_view_permission($menu_id,$user){

         $nr = $this->db
                ->where('m_id', $menu_id)
                ->where('user_id', $user)
                ->where('view_permission', 0) #0 -> crud inactive
                ->get('user_permission')->num_rows();
        // echo $this->db->last_query(); die;
        if($nr == 0){
            return 'show';
        }else{
            return 'block';
        }
        
    }

    public function dashboard() {

        // fetch department-wisemodule permission
            $session_user_id = $this->session->user_id;
            # if id is returned then filter else show all
            $module_permission_costing = $this->_dept_wise_module_permission(1, $session_user_id); #1 = costing module_id

            $uvp = $this->_user_wise_view_permission(2, $session_user_id); #2 = costing menu_id

            if($uvp == 'show'){

            if($module_permission_costing == 'show'){

              $sql="SELECT
    f.*
        FROM
            (
                (
                    (
                    SELECT
                        article_master.am_id AS art_id,
                        article_master.modify_date,
                        article_master.art_no,
                        article_master.status AS art_status,article_costing.am_id, article_costing.ac_id, article_costing.user_id, article_costing.status, users.username, 1 as show_name, 'costings' as show_table
                    FROM
                        article_costing
                    INNER JOIN(article_master)
                    ON(article_master.am_id = article_costing.am_id)
                    INNER JOIN(users)
                    ON(users.user_id = article_costing.user_id)
                    WHERE
                    article_costing.status = 1 AND article_master.status = 1
                    ORDER BY article_costing.modify_date desc

                )
            UNION ALL
                (
                SELECT
                        article_master.am_id AS art_id,
                        article_master.modify_date,
                        article_master.art_no,
                        article_master.status AS art_status,article_costing.am_id, article_costing.ac_id, article_costing.user_id, article_costing.status, users.username, 1 as show_name, 'costing charges' as show_table
                FROM
                    article_costing_charges
                    INNER JOIN(article_costing)
                    ON(article_costing.ac_id = article_costing_charges.ac_id)
                INNER JOIN(article_master)
                    ON(article_master.am_id = article_costing.am_id)
                    INNER JOIN(users)
                    ON(users.user_id = article_costing.user_id)
                    WHERE
                    article_costing_charges.status = 1 AND article_master.status = 1
                    GROUP BY article_costing_charges.ac_id
                    ORDER BY article_costing_charges.modify_date desc
            )UNION ALL
                (
                SELECT
                        article_master.am_id AS art_id,
                        article_master.modify_date,
                        article_master.art_no,
                        article_master.status AS art_status,article_costing.am_id, article_costing.ac_id, article_costing.user_id, article_costing.status, users.username, 1 as show_name, 'costing details' as show_table
                FROM
                    article_costing_details
                    INNER JOIN(article_costing)
                    ON(article_costing.ac_id = article_costing_details.ac_id)
                INNER JOIN(article_master)
                    ON(article_master.am_id = article_costing.am_id)
                    INNER JOIN(users)
                    ON(users.user_id = article_costing.user_id)
                    WHERE
                    article_costing_details.status = 1 AND article_master.status = 1
                    GROUP BY article_costing_details.ac_id
                    ORDER BY article_costing_details.modify_date desc
            )UNION ALL
                (
                SELECT
                        article_master.am_id AS art_id,
                        article_master.modify_date,
                        article_master.art_no,
                        article_master.status AS art_status,article_costing.am_id, article_costing.ac_id, article_costing.user_id, article_costing.status, users.username, 1 as show_name, 'costing measurements' as show_table
                FROM
                    article_costing_measurements
                    INNER JOIN(article_costing)
                    ON(article_costing.ac_id = article_costing_measurements.ac_id)
                INNER JOIN(article_master)
                    ON(article_master.am_id = article_costing.am_id)
                    INNER JOIN(users)
                    ON(users.user_id = article_costing_measurements.user_id)
                    WHERE
                    article_costing_measurements.status = 1 AND article_master.status = 1
                    GROUP BY article_costing_measurements.ac_id
                    ORDER BY article_costing_measurements.modify_date desc
            )
                ) AS f
            )
            GROUP BY ac_id
        ORDER BY
            modify_date desc
            LIMIT 5";

        $data['lastest_costings'] = $this->db->query($sql)->result();
        // // echo $this->db->last_query();die;

        //         $data['lastest_costings'] = $this->db
        //         ->select('article_master.am_id, article_master.modify_date, article_master.art_no, article_master.status,article_costing.am_id, article_costing.ac_id, article_costing.user_id, article_costing.status, users.username, 1 as show_name')
        //         ->join('article_master', 'article_master.am_id = article_costing.am_id', 'left')
        //         ->join('users', 'article_costing.user_id = users.user_id', 'left')
        //         ->order_by('article_master.modify_date', 'desc')
        //         ->limit(5)
        //         ->get_where('article_costing', array('article_costing.status' => 1, 'article_master.status' => 1))
        //         ->result();
            } else {
                #module_permission contains the dept id now

                $sql="SELECT
    f.*
        FROM
            (
                (
                    (
                    SELECT
                        article_master.am_id AS art_id,
                        article_master.modify_date,
                        article_master.art_no,
                        article_master.status AS art_status,article_costing.am_id, article_costing.ac_id, article_costing.user_id, article_costing.status, users.username, 0 as show_name, 'costings' as show_table
                    FROM
                        article_costing
                    INNER JOIN(article_master)
                    ON(article_master.am_id = article_costing.am_id)
                    INNER JOIN(users)
                    ON(users.user_id = article_costing.user_id)
                    WHERE
                    article_costing.status = 1 AND article_master.status = 1 AND article_costing.user_id = '".$session_user_id."'
                    ORDER BY article_costing.modify_date desc

                )
            UNION ALL
                (
                SELECT
                        article_master.am_id AS art_id,
                        article_master.modify_date,
                        article_master.art_no,
                        article_master.status AS art_status,article_costing.am_id, article_costing.ac_id, article_costing.user_id, article_costing.status, users.username, 0 as show_name, 'costing charges' as show_table
                FROM
                    article_costing_charges
                    INNER JOIN(article_costing)
                    ON(article_costing.ac_id = article_costing_charges.ac_id)
                INNER JOIN(article_master)
                    ON(article_master.am_id = article_costing.am_id)
                    INNER JOIN(users)
                    ON(users.user_id = article_costing.user_id)
                    WHERE
                    article_costing.status = 1 AND article_master.status = 1 AND article_costing_charges.user_id = '".$session_user_id."'
                    GROUP BY article_costing_charges.ac_id
                    ORDER BY article_costing_charges.modify_date desc
            )UNION ALL
                (
                SELECT
                        article_master.am_id AS art_id,
                        article_master.modify_date,
                        article_master.art_no,
                        article_master.status AS art_status,article_costing.am_id, article_costing.ac_id, article_costing.user_id, article_costing.status, users.username, 0 as show_name, 'costing details' as show_table
                FROM
                    article_costing_details
                    INNER JOIN(article_costing)
                    ON(article_costing.ac_id = article_costing_details.ac_id)
                INNER JOIN(article_master)
                    ON(article_master.am_id = article_costing.am_id)
                    INNER JOIN(users)
                    ON(users.user_id = article_costing.user_id)
                    WHERE
                    article_costing.status = 1 AND article_master.status = 1 AND article_costing_details.user_id = '".$session_user_id."'
                    GROUP BY article_costing_details.ac_id
                    ORDER BY article_costing_details.modify_date desc
            )UNION ALL
                (
                SELECT
                        article_master.am_id AS art_id,
                        article_master.modify_date,
                        article_master.art_no,
                        article_master.status AS art_status,article_costing.am_id, article_costing.ac_id, article_costing.user_id, article_costing.status, users.username, 0 as show_name, 'costing measurements' as show_table
                FROM
                    article_costing_measurements
                    INNER JOIN(article_costing)
                    ON(article_costing.ac_id = article_costing_measurements.ac_id)
                INNER JOIN(article_master)
                    ON(article_master.am_id = article_costing.am_id)
                    INNER JOIN(users)
                    ON(users.user_id = article_costing_measurements.user_id)
                    WHERE
                    article_costing.status = 1 AND article_master.status = 1 AND article_costing_measurements.user_id = '".$session_user_id."'
                    GROUP BY article_costing_measurements.ac_id
                    ORDER BY article_costing_measurements.modify_date desc
            )
                ) AS f
            )
            GROUP BY ac_id
        ORDER BY
            modify_date desc
            LIMIT 5";

        $data['lastest_costings'] = $this->db->query($sql)->result();

            }

            } else {

              $data['lastest_costings'] = '';

            }

            # if id is returned then filter else show all
            $module_permission_order = $this->_dept_wise_module_permission(15, $session_user_id); #15 = customer order module_id

            $show_order = $this->_user_wise_view_permission(3, $session_user_id); #3 = customer order menu_id

            if($show_order == 'show'){

            if($module_permission_order == 'show'){

              $data['lastest_orders'] = $this->db
                ->select('customer_order.co_id, customer_order.modify_date, customer_order.co_no, customer_order.status, customer_order_dtl.user_id, customer_order_dtl.status, users.username, 1 as show_name')
                ->join('customer_order_dtl', 'customer_order_dtl.co_id = customer_order.co_id', 'left')
                ->join('users', 'customer_order_dtl.user_id = users.user_id', 'left')
                ->group_by('co_no')
                ->order_by('customer_order_dtl.modify_date', 'desc')
                ->limit(5)
                ->get_where('customer_order', array('customer_order.status' => 1, 'customer_order_dtl.status' => 1))
                ->result();
            } else {
                #module_permission contains the dept id now

                $data['lastest_orders'] = $this->db
                ->select('customer_order.co_id, customer_order.modify_date, customer_order.co_no, customer_order.status, customer_order_dtl.user_id, customer_order_dtl.status, users.username, 0 as show_name')
                ->join('customer_order_dtl', 'customer_order_dtl.co_id = customer_order.co_id', 'left')
                ->join('users', 'customer_order_dtl.user_id = users.user_id', 'left')
                ->group_by('co_no')
                ->order_by('customer_order_dtl.modify_date', 'desc')
                ->limit(5)
                ->get_where('customer_order', array('customer_order.status' => 1, 'customer_order_dtl.status' => 1, 'customer_order.user_id' => $session_user_id))
                ->result();

            }

            } else {

              $data['lastest_orders'] = '';

            }

            # if id is returned then filter else show all
            $module_permission_cutting = $this->_dept_wise_module_permission(2, $session_user_id); #2 = cutting module_id

            $show_cutting = $this->_user_wise_view_permission(4, $session_user_id); #4 cutting menu_id

            if($show_cutting == 'show'){

            if($module_permission_order == 'show'){

             $data['lastest_cutting_issues'] = $this->db
                ->select('customer_order.co_id, customer_order.co_no, customer_order.status,cutting_issue_challan_details.cut_id, cutting_issue_challan_details.co_id, cutting_issue_challan_details.user_id, cutting_issue_challan_details.status, cutting_issue_challan_details.modify_date, users.username, 1 as show_name')
                ->join('customer_order', 'cutting_issue_challan_details.co_id = customer_order.co_id', 'left')
                ->join('users', 'cutting_issue_challan_details.user_id = users.user_id', 'left')
                ->group_by('cutting_issue_challan_details.co_id')
                ->order_by('cutting_issue_challan_details.modify_date', 'desc')
                ->limit(5)
                ->get_where('cutting_issue_challan_details', array('customer_order.status' => 1, 'cutting_issue_challan_details.status' => 1))
                ->result();
            } else {
                #module_permission contains the dept id now
                $data['lastest_cutting_issues'] = $this->db
                ->select('customer_order.co_id, customer_order.co_no, customer_order.status,cutting_issue_challan_details.cut_id, cutting_issue_challan_details.co_id, cutting_issue_challan_details.user_id, cutting_issue_challan_details.status, cutting_issue_challan_details.modify_date, users.username, 0 as show_name')
                ->join('customer_order', 'cutting_issue_challan_details.co_id = customer_order.co_id', 'left')
                ->join('users', 'cutting_issue_challan_details.user_id = users.user_id', 'left')
                ->group_by('cutting_issue_challan_details.co_id')
                ->order_by('cutting_issue_challan_details.modify_date', 'desc')
                ->limit(5)
                ->get_where('cutting_issue_challan_details', array('customer_order.status' => 1, 'cutting_issue_challan_details.status' => 1, 'cutting_issue_challan_details.user_id' => $session_user_id))
                ->result();

            }

            } else {

              $data['lastest_cutting_issues'] = '';

            }

            # if id is returned then filter else show all
            $module_permission_cutting_receive = $this->_dept_wise_module_permission(2, $session_user_id); #2 = cutting module_id

            $show_cutting_receive = $this->_user_wise_view_permission(5, $session_user_id); #4 cutting receive menu_id 

            if($show_cutting_receive == 'show'){

            if($module_permission_cutting_receive == 'show'){

              $data['lastest_cutting_receive'] = $this->db
                ->select('customer_order.co_id, customer_order.co_no, customer_order.status,cutting_received_challan_detail.cut_rcv_id, cutting_received_challan_detail.co_id, cutting_received_challan_detail.user_id, cutting_received_challan_detail.status, cutting_received_challan_detail.modify_date, users.username, 1 as show_name')
                ->join('customer_order', 'cutting_received_challan_detail.co_id = customer_order.co_id', 'left')
                ->join('users', 'cutting_received_challan_detail.user_id = users.user_id', 'left')
                ->group_by('cutting_received_challan_detail.co_id')
                ->order_by('cutting_received_challan_detail.modify_date', 'desc')
                ->limit(5)
                ->get_where('cutting_received_challan_detail', array('customer_order.status' => 1, 'cutting_received_challan_detail.status' => 1))
                ->result();
            } else {
                #module_permission contains the dept id now
                $data['lastest_cutting_receive'] = $this->db
                ->select('customer_order.co_id, customer_order.co_no, customer_order.status,cutting_received_challan_detail.cut_rcv_id, cutting_received_challan_detail.co_id, cutting_received_challan_detail.user_id, cutting_received_challan_detail.status, cutting_received_challan_detail.modify_date, users.username, 0 as show_name')
                ->join('customer_order', 'cutting_received_challan_detail.co_id = customer_order.co_id', 'left')
                ->join('users', 'cutting_received_challan_detail.user_id = users.user_id', 'left')
                ->group_by('cutting_received_challan_detail.co_id')
                ->order_by('cutting_received_challan_detail.modify_date', 'desc')
                ->limit(5)
                ->get_where('cutting_received_challan_detail', array('customer_order.status' => 1, 'cutting_received_challan_detail.status' => 1, 'cutting_received_challan_detail.user_id' => $session_user_id))
                ->result();

            }

            } else {

              $data['lastest_cutting_receive'] = '';

            }

            # if id is returned then filter else show all
            $module_permission_skiving_receive = $this->_dept_wise_module_permission(3, $session_user_id); #3 = skiving module_id

            $show_skiving_receive = $this->_user_wise_view_permission(8, $session_user_id); #8 skiving receive menu_id 

            if( $show_skiving_receive == 'show'){

            if($module_permission_skiving_receive == 'show'){

              $data['lastest_skiving_receive'] = $this->db
                ->select('skiving_receive_challan.skiving_receive_id, skiving_receive_challan.skiving_receive_challan_number, skiving_receive_challan_details.co_id, skiving_receive_challan_details.user_id, skiving_receive_challan_details.status, skiving_receive_challan_details.modified_date, users.username, 1 as show_name')
                ->join('skiving_receive_challan', 'skiving_receive_challan_details.skiving_receive_id = skiving_receive_challan.skiving_receive_id', 'left')
                ->join('users', 'skiving_receive_challan_details.user_id = users.user_id', 'left')
                ->group_by('skiving_receive_challan_details.skiving_receive_id')
                ->order_by('skiving_receive_challan_details.modified_date', 'desc')
                ->limit(5)
                ->get_where('skiving_receive_challan_details', array('skiving_receive_challan.status' => 1, 'skiving_receive_challan_details.status' => 1))
                ->result();
            } else {
                #module_permission contains the dept id now
                $data['lastest_skiving_receive'] = $this->db
                ->select('skiving_receive_challan.skiving_receive_id, skiving_receive_challan.skiving_receive_challan_number, skiving_receive_challan_details.co_id, skiving_receive_challan_details.user_id, skiving_receive_challan_details.status, skiving_receive_challan_details.modified_date, users.username, 0 as show_name')
                ->join('skiving_receive_challan', 'skiving_receive_challan_details.skiving_receive_id = skiving_receive_challan.skiving_receive_id', 'left')
                ->join('users', 'skiving_receive_challan_details.user_id = users.user_id', 'left')
                ->group_by('skiving_receive_challan_details.skiving_receive_id')
                ->order_by('skiving_receive_challan_details.modified_date', 'desc')
                ->limit(5)
                ->get_where('skiving_receive_challan_details', array('skiving_receive_challan.status' => 1, 'skiving_receive_challan_details.status' => 1, 'skiving_receive_challan_details.user_id' => $session_user_id))
                ->result();

            }

            } else {

              $data['lastest_skiving_receive'] = '';

            }

            # if id is returned then filter else show all
            $module_permission_jobber = $this->_dept_wise_module_permission(4, $session_user_id); #3 = jobber module_id

            $show_jobber = $this->_user_wise_view_permission(9, $session_user_id); #8 jobber issue menu_id 

            if($show_jobber == 'show'){

            if($module_permission_jobber == 'show'){

              $data['lastest_jobber_issues'] = $this->db
                ->select('jobber_issue.jobber_issue_id, jobber_issue.jobber_challan_number,                                jobber_issue_details.modified_date, jobber_issue_details.user_id, jobber_issue_details.status, users.username, 1 as show_name')
                ->join('jobber_issue', 'jobber_issue_details.jobber_issue_id = jobber_issue.jobber_issue_id', 'left')
                ->join('users', 'jobber_issue_details.user_id = users.user_id', 'left')
                ->group_by('jobber_issue_details.jobber_issue_id')
                ->order_by('jobber_issue_details.modified_date', 'desc')
                ->limit(5)
                ->get_where('jobber_issue_details', array('jobber_issue.status' => 1, 'jobber_issue_details.status' => 1))
                ->result();
            } else {
                #module_permission contains the dept id now
                $data['lastest_jobber_issues'] = $this->db
                ->select('jobber_issue.jobber_issue_id, jobber_issue.jobber_challan_number,                                jobber_issue_details.modified_date, jobber_issue_details.user_id, jobber_issue_details.status, users.username, 0 as show_name')
                ->join('jobber_issue', 'jobber_issue_details.jobber_issue_id = jobber_issue.jobber_issue_id', 'left')
                ->join('users', 'jobber_issue_details.user_id = users.user_id', 'left')
                ->group_by('jobber_issue_details.jobber_issue_id')
                ->order_by('jobber_issue_details.modified_date', 'desc')
                ->limit(5)
                ->get_where('jobber_issue_details', array('jobber_issue.status' => 1, 'jobber_issue_details.status' => 1, 'jobber_issue_details.user_id' => $session_user_id))
                ->result();

            }

            } else {

              $data['lastest_jobber_issues'] = '';

            }

            # if id is returned then filter else show all
            $module_permission_jobber_receive = $this->_dept_wise_module_permission(4, $session_user_id); #4 = jobber module_id

            $show_jobber_receive = $this->_user_wise_view_permission(10, $session_user_id); #10 jobber issue menu_id 

            if($show_jobber_receive == 'show'){
 
            if($module_permission_jobber_receive == 'show'){

              $data['lastest_jobber_receive'] = $this->db
                ->select('jobber_challan_receipt.jobber_challan_receipt_id, jobber_challan_receipt.jobber_receipt_challan_number,                                jobber_challan_receipt_details.modify_date, jobber_challan_receipt_details.user_id, jobber_challan_receipt_details.status, users.username, 1 as show_name')
                ->join('jobber_challan_receipt', 'jobber_challan_receipt_details.jobber_challan_receipt_id = jobber_challan_receipt.jobber_challan_receipt_id', 'left')
                ->join('users', 'jobber_challan_receipt_details.user_id = users.user_id', 'left')
                ->group_by('jobber_challan_receipt_details.jobber_challan_receipt_id')
                ->order_by('jobber_challan_receipt_details.modify_date', 'desc')
                ->limit(5)
                ->get_where('jobber_challan_receipt_details', array('jobber_challan_receipt.status' => 1, 'jobber_challan_receipt_details.status' => 1))
                ->result();
            } else {
                #module_permission contains the dept id now
                $data['lastest_jobber_receive'] = $this->db
                ->select('jobber_challan_receipt.jobber_challan_receipt_id, jobber_challan_receipt.jobber_receipt_challan_number,                                jobber_challan_receipt_details.modify_date, jobber_challan_receipt_details.user_id, jobber_challan_receipt_details.status, users.username, 0 as show_name')
                ->join('jobber_challan_receipt', 'jobber_challan_receipt_details.jobber_challan_receipt_id = jobber_challan_receipt.jobber_challan_receipt_id', 'left')
                ->join('users', 'jobber_challan_receipt_details.user_id = users.user_id', 'left')
                ->group_by('jobber_challan_receipt_details.jobber_challan_receipt_id')
                ->order_by('jobber_challan_receipt_details.modify_date', 'desc')
                ->limit(5)
                ->get_where('jobber_challan_receipt_details', array('jobber_challan_receipt.status' => 1, 'jobber_challan_receipt_details.status' => 1, 'jobber_challan_receipt_details.user_id' => $session_user_id))
                ->result();
            }

            } else {

              $data['lastest_jobber_receive'] = '';

            }

            # if id is returned then filter else show all
            $module_permission_shipment = $this->_dept_wise_module_permission(7, $session_user_id); #7 = packing-shipment module_id


            $show_shipment = $this->_user_wise_view_permission(15, $session_user_id); #15 = Packing/Shipment menu_id 

            if($show_shipment == 'show'){

            if($session_user_id == 1){

              $data['lastest_shipment'] = $this->db
                ->select('packing_shipment.packing_shipment_id, packing_shipment.package_name,                                packing_shipment_detail.modify_date, packing_shipment_detail.user_id, packing_shipment_detail.status, users.username, 1 as show_name')
                ->join('packing_shipment', 'packing_shipment_detail.packing_shipment_id = packing_shipment.packing_shipment_id', 'left')
                ->join('users', 'packing_shipment.user_id = users.user_id', 'left')
                ->group_by('packing_shipment.packing_shipment_id')
                ->order_by('packing_shipment_detail.modify_date', 'desc')
                ->limit(5)
                ->get_where('packing_shipment_detail', array('packing_shipment.status' => 1, 'packing_shipment_detail.status' => 1))
                ->result();
            } else {
                #module_permission contains the dept id now
                $data['lastest_shipment'] = $this->db
                ->select('packing_shipment.packing_shipment_id, packing_shipment.package_name,                                packing_shipment_detail.modify_date, packing_shipment_detail.user_id, packing_shipment_detail.status, users.username, 0 as show_name')
                ->join('packing_shipment', 'packing_shipment_detail.packing_shipment_id = packing_shipment.packing_shipment_id', 'left')
                ->join('users', 'packing_shipment.user_id = users.user_id', 'left')
                ->group_by('packing_shipment_detail.packing_shipment_id')
                ->order_by('packing_shipment_detail.modify_date', 'desc')
                ->limit(5)
                ->get_where('packing_shipment_detail', array('packing_shipment.status' => 1, 'packing_shipment_detail.status' => 1, 'packing_shipment.user_id' => $session_user_id))
                ->result();  
            }

            } else {

              $data['lastest_shipment'] = '';

            } 

            if($module_permission_order == 'show'){

            $data['co_ids'] = $this->db->order_by('co_no')->get_where('customer_order', array('status' => 1))->result();  
        }else{
            $data['co_ids'] = $this->db->join('user_details','user_details.user_id = customer_order.user_id','left')->order_by('co_no')->get_where('customer_order', array('status' => 1, 'user_details.user_dept' => $module_permission_order))->result();
        }             
                        
        return array('page' => 'dashboard_v', 'data' => $data);
    }


} // /.Dashboard_m model