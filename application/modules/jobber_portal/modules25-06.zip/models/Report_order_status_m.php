<?php
/**
 * Coded by: Pran Krishna Das
 * Social: www.fb.com/pran93
 * CI: 3.0.6
 * Date: 21-02-2020
 * Time: 11:30 am
 * Last updated on 25-Feb-2021 at 11:30 am
 */

class Report_order_status_m extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    private function _dept_wise_module_permission($module_id,$user){

        $dept_id = $this->db->get_where('user_details', array('user_id' => $user))->result()[0]->user_dept;
        if($dept_id != 0){
            $nr = $this->db->where('module_permission_id', $module_id)->where('FIND_IN_SET('.$dept_id.', dept_id) !=', 0)->get('module_permission')->num_rows();
            // echo $this->db->last_query(); die;
            if($nr == 0){
                # show-all
                return 'show';
            }else{
                # filter according to dept id
                return $dept_id;
            }
        }else{
            return 'show';
        }
        
    }

    public function report_order_status() {
        $session_user_id = $this->session->user_id;
            # if id is returned then filter else show all
        $module_permission = $this->_dept_wise_module_permission(15, $session_user_id); #15 = customer order 
        
        if($module_permission == 'show'){

            $data['co_ids'] = $this->db->order_by('co_no')->get_where('customer_order', array('status' => 1))->result();  
        }else{
            $data['co_ids'] = $this->db->join('user_details','user_details.user_id = customer_order.user_id','left')->order_by('co_no')->get_where('customer_order', array('status' => 1, 'user_details.user_dept' => $module_permission))->result();
        }
        $data['am_id_grs'] = $this->db->get_where('article_groups', array('status' => 1))->result();
        $data['buyers'] = $this->db->get_where('acc_master', array('status' => 1))->result(); 
        return array('page'=>'reports/report_order_status_v', 'data'=>$data);
    }

    public function ajax_fetch_article_on_group() {
        $session_user_id = $this->session->user_id;
            # if id is returned then filter else show all
        $module_permission = $this->_dept_wise_module_permission(15, $session_user_id); #15 = customer order 
        
        if($module_permission == 'show'){

            $am_gr = $this->input->post('am_gr'); 
            $res = $this->db
                ->select('article_dtl.ad_id, article_master.art_no, color')
                ->join('article_dtl', 'article_master.am_id = article_dtl.am_id', 'left')
                ->join('colors', 'colors.c_id = article_dtl.lth_color_id', 'left')
                ->order_by('article_master.art_no, color')
                ->get_where('article_master', array('article_master.ag_id' => $am_gr, 'article_master.status' => 1))->result();
        }else{
            $am_gr = $this->input->post('am_gr'); 
            $res = $this->db
                ->select('article_dtl.ad_id, article_master.art_no, color')
                ->join('article_dtl', 'article_master.am_id = article_dtl.am_id', 'left')
                ->join('colors', 'colors.c_id = article_dtl.lth_color_id', 'left')
                ->join('user_details','user_details.user_id = article_master.user_id','left')
                ->order_by('article_master.art_no, color')
                ->get_where('article_master', array('article_master.ag_id' => $am_gr, 'article_master.status' => 1, 'user_details.user_dept' => $module_permission))->result();
        }
        
        // echo $this->db->last_query();    
        // echo '<pre>',print_r($res),'</pre>'; die;
        return $res;    
    }
	
	public function report_order_status_details() {
        $data = '';

        if($this->input->post('submit') == 'order_details'){
            $cos = implode (",", $this->input->post('customer_order'));
            
            $data['result'] = $this->_custom_order_status_on_co_id($cos);
            
        foreach($this->input->post('customer_order') as $c) {
        $data['count_article'] = $this->db->select('count(article_master.am_id) as count_am')
        ->join('customer_order_dtl', 'customer_order_dtl.co_id = customer_order.co_id', 'left')
        ->join('article_master', 'article_master.am_id = customer_order_dtl.am_id', 'left')
        ->where('customer_order.co_id', $c)
        ->get_where('customer_order')->result();
        // echo $c;
    }

            // echo '<pre>',print_r($data['count_article']),'</pre>';
            $data['segment'] = 'order_details';

            return array('page'=>'reports/common_print_v','data'=>$data);

        }

        if($this->input->post('submit') == 'article_wise_order_details'){
            $ar_dtls = $this->input->post('article_number');
            
            // $query = "
            // SELECT
            //     GROUP_CONCAT(co_details.co_id) AS cos
            //     FROM
            //         (
            //         SELECT
            //             co_id
            //         FROM
            //             `article_dtl`
            //         LEFT JOIN customer_order_dtl ON customer_order_dtl.am_id = article_dtl.am_id AND customer_order_dtl.lc_id = article_dtl.lth_color_id
            //         WHERE
            //             article_dtl.ad_id IN($ar_dtls)
            //         GROUP BY
            //             co_id
            //     ) AS co_details
            // ";

            // $cos = $this->db->query($query)->result()[0]->cos;
            
            foreach($ar_dtls as $a_d) {

            $data['result'][] = $this->_custom_order_status_on_co_id_article($a_d);
            
            }
            
            // echo '<pre>', print_r($data['result']), '</pre>'; die();
            $data['segment'] = 'article_wise_order_details';

            return array('page'=>'reports/common_print_v','data'=>$data);
        }

        if($this->input->post('submit') == 'buyer_wise_order_details'){

            $buyers = implode (",", $this->input->post('buyer_wise_order_details'));
            
            $query = "
            SELECT
                GROUP_CONCAT(co_details.co_id) AS cos
                FROM
                    (
                    SELECT
                        co_id
                    FROM
                        `customer_order`
                    WHERE
                        customer_order.acc_master_id IN($buyers)
                    GROUP BY
                        co_id
                ) AS co_details
            ";

            $cos = $this->db->query($query)->result()[0]->cos;

            $data['result'] = $this->_custom_order_status_on_co_id_buyer($cos);
            $data['segment'] = 'buyer_wise_order_details';

            return array('page'=>'reports/common_print_v','data'=>$data);

        }

        if($this->input->post('submit') == 'order_summary'){
            $cos = implode (",", $this->input->post('customer_order'));

            $data['result'] = $this->_custom_order_summary_on_co_id($cos);
            $data['segment'] = 'order_summary';

            return array('page'=>'reports/common_print_v','data'=>$data);
        }

        return array('page'=>'reports/report_order_status_v', 'data'=>$data);
    }
    
    private function _custom_order_status_on_co_id_article($ar_dtls){
        if(empty($ar_dtls)){
            die('No details found');
        }
        
        $query = "
            SELECT
                ship.*,
                SUM(
                    IFNULL(
                        packing_shipment_detail.article_quantity,
                        0
                    )
                ) AS packing_shipment_quantity
            FROM
                (
            SELECT
                job_receive.*,
                SUM(
                    IFNULL(
                        jobber_challan_receipt_details.jobber_receive_quantity,
                        0
                    )
                ) AS jobber_receive_qnty
            FROM
                (
                SELECT
                    job_issue.*,
                    SUM(
                        IFNULL(
                            jobber_issue_details.jobber_issue_quantity,
                            0
                        )
                    ) AS jobber_issue_qnty
                FROM
                    (
                    SELECT
                        cutting_receive.*,
                        SUM(
                            IFNULL(
                                skiving_receive_challan_details.receive_quantity,
                                0
                            )
                        ) AS skiving_receive_qnty
                    FROM
                        (
                        SELECT
                            cutting_issue.*,
                            IFNULL(
                                SUM(
                                    cutting_received_challan_detail.receive_cut_quantity
                                ),
                                0
                            ) AS cutting_received_qnty,
                            IF(
                                (
                                SELECT
                                    skiving_issue_status
                                FROM
                                    cutting_received_challan
                                WHERE
                                    cutting_received_challan.cut_rcv_id = cutting_received_challan_detail.cut_rcv_id
                            ) = 0 OR cutting_issued_qnty = 0,
                            NULL,
                            'ok'
                            ) AS skiving_issued
                        FROM
                            (
                            SELECT
                                order_table.*,
                                IFNULL(SUM(cut_co_quantity),
                                0) AS cutting_issued_qnty
                            FROM
                                (
                                SELECT
                                    `customer_order`.`co_id`,
                                    `customer_order_dtl`.`cod_id`,
                                    `article_master`.`am_id`,
                                    `colors`.`c_id`,
                                    `customer_order`.`co_no`,
                                    `article_master`.`art_no`,
                                    `colors`.`color`,
                                    `customer_order_dtl`.`co_quantity`
                                FROM
                                    `customer_order_dtl`
                                LEFT JOIN `customer_order` ON `customer_order`.`co_id` = `customer_order_dtl`.`co_id`
                                LEFT JOIN `article_master` ON `customer_order_dtl`.`am_id` = `article_master`.`am_id`
                                LEFT JOIN `article_dtl` ON `article_master`.`am_id` = `article_dtl`.`am_id`
                                LEFT JOIN `colors` ON `colors`.`c_id` = `article_dtl`.`lth_color_id`
                                WHERE
                                    `article_dtl`.ad_id = $ar_dtls 
                                GROUP BY
                                    customer_order.co_id,
                                    article_dtl.am_id,
                                    article_dtl.lth_color_id
                            ) AS order_table
                        LEFT JOIN cutting_issue_challan_details ON cutting_issue_challan_details.cod_id = order_table.cod_id
                        GROUP BY
                            order_table.cod_id
                        ) AS cutting_issue
                    LEFT JOIN cutting_received_challan_detail ON cutting_received_challan_detail.cod_id = cutting_issue.cod_id
                    GROUP BY
                        cutting_issue.cod_id
                    ) AS cutting_receive
                LEFT JOIN skiving_receive_challan_details ON skiving_receive_challan_details.cod_id = cutting_receive.cod_id
                GROUP BY
                    cutting_receive.cod_id
                ) AS job_issue
            LEFT JOIN jobber_issue_details ON jobber_issue_details.cod_id = job_issue.cod_id
            GROUP BY
                job_issue.cod_id
            ) AS job_receive
            LEFT JOIN jobber_challan_receipt_details ON jobber_challan_receipt_details.cod_id = job_receive.cod_id
            GROUP BY
                job_receive.cod_id
            ) AS ship
            LEFT JOIN packing_shipment_detail ON packing_shipment_detail.cod_id = ship.cod_id
            GROUP BY
                ship.cod_id
                ORDER BY
                                    ship.am_id,
                                    ship.c_id
            ";
                                    
        return $res = $this->db->query($query)->result();
        
        // echo '<pre>', print_r($res), '</pre>'; die();
                                    
    }
    
    private function _custom_order_status_on_co_id($cos){
        if(empty($cos)){
            die('No details found');
        }
        $query = "
            SELECT
                ship.*,
                SUM(
                    IFNULL(
                        packing_shipment_detail.article_quantity,
                        0
                    )
                ) AS packing_shipment_quantity
            FROM
                (
            SELECT
                job_receive.*,
                SUM(
                    IFNULL(
                        jobber_challan_receipt_details.jobber_receive_quantity,
                        0
                    )
                ) AS jobber_receive_qnty
            FROM
                (
                SELECT
                    job_issue.*,
                    SUM(
                        IFNULL(
                            jobber_issue_details.jobber_issue_quantity,
                            0
                        )
                    ) AS jobber_issue_qnty
                FROM
                    (
                    SELECT
                        cutting_receive.*,
                        SUM(
                            IFNULL(
                                skiving_receive_challan_details.receive_quantity,
                                0
                            )
                        ) AS skiving_receive_qnty
                    FROM
                        (
                        SELECT
                            cutting_issue.*,
                            IFNULL(
                                SUM(
                                    cutting_received_challan_detail.receive_cut_quantity
                                ),
                                0
                            ) AS cutting_received_qnty,
                            IF(
                                (
                                SELECT
                                    skiving_issue_status
                                FROM
                                    cutting_received_challan
                                WHERE
                                    cutting_received_challan.cut_rcv_id = cutting_received_challan_detail.cut_rcv_id
                            ) = 0 OR cutting_issued_qnty = 0,
                            NULL,
                            'ok'
                            ) AS skiving_issued
                        FROM
                            (
                            SELECT
                                order_table.*,
                                IFNULL(SUM(cut_co_quantity),
                                0) AS cutting_issued_qnty
                            FROM
                                (
                                SELECT
                                    `customer_order`.`co_id`,
                                    `customer_order_dtl`.`cod_id`,
                                    `article_master`.`am_id`,
                                    `colors`.`c_id`,
                                    `customer_order`.`co_no`,
                                    `article_master`.`art_no`,
                                    `colors`.`color`,
                                    `customer_order_dtl`.`co_quantity`
                                FROM
                                    `customer_order`
                                LEFT JOIN `customer_order_dtl` ON `customer_order_dtl`.`co_id` = `customer_order`.`co_id`
                                LEFT JOIN `article_master` ON `customer_order_dtl`.`am_id` = `article_master`.`am_id`
                                LEFT JOIN `colors` ON `colors`.`c_id` = `customer_order_dtl`.`lc_id`
                                WHERE
                                    `customer_order`.co_id IN($cos)
                                ORDER BY
                                    article_master.am_id,
                                    colors.c_id
                            ) AS order_table
                        LEFT JOIN cutting_issue_challan_details ON cutting_issue_challan_details.cod_id = order_table.cod_id
                        GROUP BY
                            order_table.cod_id
                        ) AS cutting_issue
                    LEFT JOIN cutting_received_challan_detail ON cutting_received_challan_detail.cod_id = cutting_issue.cod_id
                    GROUP BY
                        cutting_issue.cod_id
                    ) AS cutting_receive
                LEFT JOIN skiving_receive_challan_details ON skiving_receive_challan_details.cod_id = cutting_receive.cod_id
                GROUP BY
                    cutting_receive.cod_id
                ) AS job_issue
            LEFT JOIN jobber_issue_details ON jobber_issue_details.cod_id = job_issue.cod_id
            GROUP BY
                job_issue.cod_id
            ) AS job_receive
            LEFT JOIN jobber_challan_receipt_details ON jobber_challan_receipt_details.cod_id = job_receive.cod_id
            GROUP BY
                job_receive.cod_id
            ) AS ship
            LEFT JOIN packing_shipment_detail ON packing_shipment_detail.cod_id = ship.cod_id
            GROUP BY
                ship.cod_id    
            ";

            return $this->db->query($query)->result();

    }

    private function _custom_order_status_on_co_id_sum($cos){
        if(empty($cos)){
            die('No details found');
        }
        $query = "
            SELECT
                ship.*,
                SUM(
                    IFNULL(
                        packing_shipment_detail.article_quantity,
                        0
                    )
                ) AS packing_shipment_quantity
            FROM
                (
            SELECT
                job_receive.*,
                SUM(
                    IFNULL(
                        jobber_challan_receipt_details.jobber_receive_quantity,
                        0
                    )
                ) AS jobber_receive_qnty
            FROM
                (
                SELECT
                    job_issue.*,
                    SUM(
                        IFNULL(
                            jobber_issue_details.jobber_issue_quantity,
                            0
                        )
                    ) AS jobber_issue_qnty
                FROM
                    (
                    SELECT
                        cutting_receive.*,
                        SUM(
                            IFNULL(
                                skiving_receive_challan_details.receive_quantity,
                                0
                            )
                        ) AS skiving_receive_qnty
                    FROM
                        (
                        SELECT
                            cutting_issue.*,
                            IFNULL(
                                SUM(
                                    cutting_received_challan_detail.receive_cut_quantity
                                ),
                                0
                            ) AS cutting_received_qnty,
                            IF(
                                (
                                SELECT
                                    skiving_issue_status
                                FROM
                                    cutting_received_challan
                                WHERE
                                    cutting_received_challan.cut_rcv_id = cutting_received_challan_detail.cut_rcv_id
                            ) = 0 OR cutting_issued_qnty = 0,
                            NULL,
                            'ok'
                            ) AS skiving_issued
                        FROM
                            (
                            SELECT
                                order_table.*,
                                IFNULL(SUM(cut_co_quantity),
                                0) AS cutting_issued_qnty
                            FROM
                                (
                                SELECT
                                    `customer_order`.`co_id`,
                                    `customer_order_dtl`.`cod_id`,
                                    `customer_order`.`co_no`,
                                    SUM(
                                     co_quantity
                                         ) AS co_quantity
                                FROM
                                    `customer_order`
                                LEFT JOIN `customer_order_dtl` ON `customer_order_dtl`.`co_id` = `customer_order`.`co_id`
                                WHERE
                                    `customer_order`.co_id IN($cos)
                                    GROUP BY
                            customer_order.co_id
                            ) AS order_table
                        LEFT JOIN cutting_issue_challan_details ON cutting_issue_challan_details.co_id = order_table.co_id
                        GROUP BY
                            order_table.co_id
                        ) AS cutting_issue
                    LEFT JOIN cutting_received_challan_detail ON cutting_received_challan_detail.cod_id = cutting_issue.cod_id
                    GROUP BY
                        cutting_issue.cod_id
                    ) AS cutting_receive
                LEFT JOIN skiving_receive_challan_details ON skiving_receive_challan_details.cod_id = cutting_receive.cod_id
                GROUP BY
                    cutting_receive.cod_id
                ) AS job_issue
            LEFT JOIN jobber_issue_details ON jobber_issue_details.cod_id = job_issue.cod_id
            GROUP BY
                job_issue.cod_id
            ) AS job_receive
            LEFT JOIN jobber_challan_receipt_details ON jobber_challan_receipt_details.cod_id = job_receive.cod_id
            GROUP BY
                job_receive.cod_id
            ) AS ship
            LEFT JOIN packing_shipment_detail ON packing_shipment_detail.cod_id = ship.cod_id
            GROUP BY
                ship.cod_id    
            ";

            return $this->db->query($query)->result();
    }

    private function _custom_order_summary_on_co_id($cos){
        if(empty($cos)){
            die('No details found');
        }
        $query = "
            SELECT 
              ship_table.*, 
              SUM(packing_shipment.total_quantity) AS total_quantity,
              CONCAT_WS(
                ' : ', packing_shipment.package_name, 
                packing_shipment.total_quantity
              ) AS ship 
            FROM 
              (
                SELECT 
                  ji_table.*, 
                  jobber_challan_receipt_details.jobber_challan_receipt_id, 
                  SUM(jobber_challan_receipt_details.jobber_receive_quantity) AS jobber_receive_quantity,
                  GROUP_CONCAT(
                    CONCAT_WS(
                      ' : ', jobber_challan_receipt.jobber_receipt_challan_number, 
                      jobber_challan_receipt_details.jobber_receive_quantity
                    ) SEPARATOR '<br>'
                  ) AS jobr 
                FROM 
                  (
                    SELECT 
                      sr_table.*, 
                      jobber_issue_details.jobber_issue_id, 
                      SUM(jobber_issue_details.jobber_issue_quantity) AS jobber_issue_quantity,
                      GROUP_CONCAT(
                        CONCAT_WS(
                          ' : ', jobber_issue.jobber_challan_number, 
                          jobber_issue_details.jobber_issue_quantity
                        ) SEPARATOR '<br>'
                      ) AS jobi 
                    FROM 
                      (
                        SELECT 
                          cr_table.*, 
                          SUM(skiving_receive_challan_details.receive_quantity) AS receive_quantity,
                          GROUP_CONCAT(
                            CONCAT_WS(
                              ' : ', skiving_receive_challan.skiving_receive_challan_number, 
                              skiving_receive_challan_details.receive_quantity
                            ) SEPARATOR '<br>'
                          ) AS sr 
                        FROM 
                          (
                            SELECT 
                              ci_table.*, 
                              cutting_received_challan.cut_rcv_id AS cutting_receive_id, 
                              SUM(cutting_received_challan_detail.receive_cut_quantity) AS receive_cut_quantity,
                              GROUP_CONCAT(
                                CONCAT_WS(
                                  ' : ', cutting_received_challan.cut_rcv_number, 
                                  cutting_received_challan_detail.receive_cut_quantity
                                ) SEPARATOR '<br>'
                              ) AS cr 
                            FROM 
                              (
                                SELECT 
                                  order_table.*, 
                                  cutting_issue_challan.cut_id AS cutting_issue_id, 
                                  SUM(cutting_issue_challan_details.cut_co_quantity) AS cut_co_quantity,
                                  GROUP_CONCAT(
                                    CONCAT_WS(
                                      ' : ', cutting_issue_challan.cut_number, 
                                      cutting_issue_challan_details.cut_co_quantity
                                    ) SEPARATOR '<br>'
                                  ) AS ci 
                                FROM 
                                  (
                                    SELECT 
                                      `customer_order`.`co_id`, 
                                      `customer_order_dtl`.`cod_id`, 
                                      `article_master`.`am_id`, 
                                      `colors`.`c_id`, 
                                      `customer_order`.`co_no`, 
                                      `article_master`.`art_no`, 
                                      `colors`.`color`, 
                                      `customer_order_dtl`.`co_quantity` 
                                    FROM 
                                      `customer_order` 
                                      LEFT JOIN `customer_order_dtl` ON `customer_order_dtl`.`co_id` = `customer_order`.`co_id` 
                                      LEFT JOIN `article_master` ON `customer_order_dtl`.`am_id` = `article_master`.`am_id` 
                                      LEFT JOIN `colors` ON `colors`.`c_id` = `customer_order_dtl`.`lc_id` 
                                    WHERE 
                                      `customer_order`.co_id IN($cos) 
                                    ORDER BY 
                                      article_master.am_id, 
                                      colors.c_id
                                  ) AS order_table 
                                  LEFT JOIN cutting_issue_challan_details ON cutting_issue_challan_details.cod_id = order_table.cod_id 
                                  LEFT JOIN cutting_issue_challan ON cutting_issue_challan_details.cut_id = cutting_issue_challan.cut_id 
                                GROUP BY 
                                  order_table.cod_id
                              ) AS ci_table 
                              LEFT JOIN cutting_received_challan_detail ON cutting_received_challan_detail.cod_id = ci_table.cod_id 
                              LEFT JOIN cutting_received_challan ON cutting_received_challan.cut_rcv_id = cutting_received_challan_detail.cut_rcv_id 
                            GROUP BY 
                              cod_id
                          ) AS cr_table 
                          LEFT JOIN skiving_receive_challan_details ON skiving_receive_challan_details.cod_id = cr_table.cod_id 
                          LEFT JOIN skiving_receive_challan ON skiving_receive_challan.skiving_receive_id = skiving_receive_challan_details.skiving_receive_id 
                        GROUP BY 
                          cod_id
                      ) AS sr_table 
                      LEFT JOIN jobber_issue_details ON jobber_issue_details.cod_id = sr_table.cod_id 
                      LEFT JOIN jobber_issue ON jobber_issue.jobber_issue_id = jobber_issue_details.jobber_issue_id 
                    GROUP BY 
                      cod_id
                  ) AS ji_table 
                  LEFT JOIN jobber_challan_receipt_details ON jobber_challan_receipt_details.cod_id = ji_table.cod_id 
                  LEFT JOIN jobber_challan_receipt ON jobber_challan_receipt.jobber_challan_receipt_id = jobber_challan_receipt_details.jobber_challan_receipt_id 
                GROUP BY 
                  cod_id
              ) AS ship_table 
              LEFT JOIN packing_shipment_detail ON packing_shipment_detail.cod_id = ship_table.cod_id 
              LEFT JOIN packing_shipment ON packing_shipment.packing_shipment_id = packing_shipment_detail.packing_shipment_id 
            GROUP BY 
              cod_id
  
            ";

            $res = $this->db->query($query)->result();
            // echo '<pre>', print_r($res), '</pre>'; die();
            // echo $this->db->last_query(); die();
            return $res;
    }

    private function _custom_order_status_on_co_id_buyer($cos){
        if(empty($cos)){
            die('No details found');
        }

        $query = "
            SELECT
                ship.*,
                SUM(
                    IFNULL(
                        packing_shipment_detail.article_quantity,
                        0
                    )
                ) AS packing_shipment_quantity
            FROM
                (
            SELECT
                job_receive.*,
                SUM(
                    IFNULL(
                        jobber_challan_receipt_details.jobber_receive_quantity,
                        0
                    )
                ) AS jobber_receive_qnty
            FROM
                (
                SELECT
                    job_issue.*,
                    SUM(
                        IFNULL(
                            jobber_issue_details.jobber_issue_quantity,
                            0
                        )
                    ) AS jobber_issue_qnty
                FROM
                    (
                    SELECT
                        cutting_receive.*,
                        SUM(
                            IFNULL(
                                skiving_receive_challan_details.receive_quantity,
                                0
                            )
                        ) AS skiving_receive_qnty
                    FROM
                        (
                        SELECT
                            cutting_issue.*,
                            IFNULL(
                                SUM(
                                    cutting_received_challan_detail.receive_cut_quantity
                                ),
                                0
                            ) AS cutting_received_qnty,
                            IF(
                                (
                                SELECT
                                    skiving_issue_status
                                FROM
                                    cutting_received_challan
                                WHERE
                                    cutting_received_challan.cut_rcv_id = cutting_received_challan_detail.cut_rcv_id
                            ) = 0 OR cutting_issued_qnty = 0,
                            NULL,
                            'ok'
                            ) AS skiving_issued
                        FROM
                            (
                            SELECT
                                order_table.*,
                                IFNULL(SUM(cut_co_quantity),
                                0) AS cutting_issued_qnty
                            FROM
                                (
                                SELECT
                                    `customer_order`.`co_id`,
                                    `customer_order_dtl`.`cod_id`,
                                    `article_master`.`am_id`,
                                    `colors`.`c_id`,
                                    `customer_order`.`co_no`,
                                    `article_master`.`art_no`,
                                    `colors`.`color`,
                                    `customer_order_dtl`.`co_quantity`,
                                    `acc_master`.`name`
                                FROM
                                    `customer_order`
                                LEFT JOIN `customer_order_dtl` ON `customer_order_dtl`.`co_id` = `customer_order`.`co_id`
                                LEFT JOIN `article_master` ON `customer_order_dtl`.`am_id` = `article_master`.`am_id`
                                LEFT JOIN `acc_master` ON `acc_master`.`am_id` = `customer_order`.`acc_master_id`
                                LEFT JOIN `colors` ON `colors`.`c_id` = `customer_order_dtl`.`lc_id`
                                WHERE
                                    `customer_order`.co_id IN($cos)
                                ORDER BY
                                    article_master.am_id,
                                    colors.c_id
                            ) AS order_table
                        LEFT JOIN cutting_issue_challan_details ON cutting_issue_challan_details.cod_id = order_table.cod_id
                        GROUP BY
                            order_table.cod_id
                        ) AS cutting_issue
                    LEFT JOIN cutting_received_challan_detail ON cutting_received_challan_detail.cod_id = cutting_issue.cod_id
                    GROUP BY
                        cutting_issue.cod_id
                    ) AS cutting_receive
                LEFT JOIN skiving_receive_challan_details ON skiving_receive_challan_details.cod_id = cutting_receive.cod_id
                GROUP BY
                    cutting_receive.cod_id
                ) AS job_issue
            LEFT JOIN jobber_issue_details ON jobber_issue_details.cod_id = job_issue.cod_id
            GROUP BY
                job_issue.cod_id
            ) AS job_receive
            LEFT JOIN jobber_challan_receipt_details ON jobber_challan_receipt_details.cod_id = job_receive.cod_id
            GROUP BY
                job_receive.cod_id
            ) AS ship
            LEFT JOIN packing_shipment_detail ON packing_shipment_detail.cod_id = ship.cod_id
            GROUP BY
                ship.cod_id    
            ";

            return $this->db->query($query)->result();
    }
	
public function jobber_ledger_status($job , $from, $to, $job_type) {

if($this->input->post()) {
 $buyers = implode (",", $job);
            
            $query = "
            SELECT
                GROUP_CONCAT(co_details.co_id) AS cos
                FROM
                    (
                    SELECT
                        jobber_issue_details.co_id
                    FROM
                        `jobber_issue`
                        LEFT JOIN `jobber_issue_details` ON `jobber_issue_details`.`jobber_issue_id` = `jobber_issue`.`jobber_issue_id`
                    WHERE
                        jobber_issue.am_id IN($buyers)
                    GROUP BY
                        jobber_issue_details.jobber_issue_id
                ) AS co_details
            ";

            $cos = $this->db->query($query)->result()[0]->cos;

            $data['result'] = $this->_fetch_all_jobber_report_m($job, $from, $to);
        
        if($job_type == 'zero') {
            $data['segment'] = 'jobber_ledger_status_report';
        } else {
          $data['segment'] = 'jobber_ledger_status_report_non_zero';  
        }

            return array('page'=>'reports/common_print_v', 'data'=>$data);
        }

$data['fetch_all_buyer'] = $this->db->get_where('acc_master', array('acc_type' => 'Fabricator', 'status' => 1))->result();

        return array('page'=>'reports/jobber_ledger_v', 'data'=>$data);
    }
    
    public function _fetch_all_jobber_report_m($cos, $from, $to) {
        if(empty($cos)){
            die('No details found');
        }
        
        foreach($cos as $c) {

        $query = "SELECT
                job_receive.*,
                  jobber_challan_receipt_details.jobber_challan_receipt_id, 
                  SUM(jobber_challan_receipt_details.jobber_receive_quantity) AS jobber_receive_quantity,
                  GROUP_CONCAT(
                    CONCAT_WS(
                      ' : ', jobber_challan_receipt.jobber_receipt_challan_number
                    ) SEPARATOR '<br>'
                  ) AS jobr_challan,
                  GROUP_CONCAT( DATE_FORMAT( jobber_challan_receipt.jobber_receipt_challan_date, '%d-%m-%Y' ) SEPARATOR '<br>') as jobr_challan_date,
                  GROUP_CONCAT(
                    CONCAT_WS(
                      ' : ', jobber_challan_receipt_details.jobber_receive_quantity
                    ) SEPARATOR '<br>'
                  ) AS jobr_challan_receive_quantity
            FROM
                (SELECT
                    jobber_issue.jobber_challan_number,
                    DATE_FORMAT(jobber_issue.jobber_issue_date, '%d-%m-%Y') as jobber_issue_date,
                        jobber_issue.jobber_issue_id,
                        (jobber_issue_details.jobber_issue_quantity
                ) AS jobber_issue_quantity,
                `jobber_issue_details`.`am_id`,
                `colors`.`c_id`,
                `jobber_issue_details`.`co_id`,
                `jobber_issue_details`.`skiving_receive_id`,
                `customer_order_dtl`.`cod_id`,
                `customer_order`.`co_no`,
                `article_master`.`art_no`,
                `colors`.`color`,
                `customer_order_dtl`.`co_quantity`,
                `acc_master`.`name`,
                `cutting_received_challan`.`cut_rcv_number`,
                `acc_master`.`address`
                FROM `jobber_issue_details`
            LEFT JOIN `customer_order_dtl` ON `customer_order_dtl`.`co_id` = `jobber_issue_details`.`co_id`
            LEFT JOIN `customer_order` ON `customer_order`.`co_id` = `customer_order_dtl`.`co_id`
            LEFT JOIN `article_master` ON `jobber_issue_details`.`am_id` = `article_master`.`am_id`
            LEFT JOIN `jobber_issue` ON `jobber_issue`.`jobber_issue_id` = `jobber_issue_details`.`jobber_issue_id`
            LEFT JOIN `acc_master` ON `acc_master`.`am_id` = `jobber_issue`.`am_id`
            LEFT JOIN `colors` ON `colors`.`c_id` = `jobber_issue_details`.`lc_id`
            LEFT JOIN cutting_received_challan_detail ON cutting_received_challan_detail.co_id = jobber_issue_details.co_id AND cutting_received_challan_detail.am_id = jobber_issue_details.am_id AND cutting_received_challan_detail.lc_id = jobber_issue_details.lc_id AND cutting_received_challan_detail.cod_id = jobber_issue_details.cod_id
            LEFT JOIN cutting_received_challan ON cutting_received_challan.cut_rcv_id = cutting_received_challan_detail.cut_rcv_id
            where STR_TO_DATE(jobber_issue.jobber_issue_date, '%Y-%m-%d') <= '$to' AND STR_TO_DATE(jobber_issue.jobber_issue_date, '%Y-%m-%d') >= '$from'
            AND
                                    `jobber_issue`.am_id = $c
            GROUP BY
            jobber_issue_details.jobber_issue_detail_id) AS job_receive
            LEFT JOIN jobber_challan_receipt_details ON jobber_challan_receipt_details.co_id = job_receive.co_id AND jobber_challan_receipt_details.am_id = job_receive.am_id AND jobber_challan_receipt_details.lc_id = job_receive.c_id AND jobber_challan_receipt_details.jobber_challan_number = job_receive.jobber_issue_id
            LEFT JOIN jobber_challan_receipt ON jobber_challan_receipt.jobber_challan_receipt_id = jobber_challan_receipt_details.jobber_challan_receipt_id
            GROUP BY
                 job_receive.jobber_issue_id, job_receive.co_id, job_receive.am_id, job_receive.c_id
                ORDER BY
                job_receive.jobber_challan_number,
                                    job_receive.am_id,
                                    job_receive.c_id,
                                    jobber_challan_receipt.jobber_receipt_challan_date
            ";

            $res = $this->db->query($query)->result();
            
        }
            // echo '<pre>', print_r($res), '</pre>'; die();
            // echo $this->db->last_query(); die();
            return $res;
    }
    
    public function fetch_report_leather_status() {
        $data = '';

        if($this->input->post('print') == 'Print(P.O. wise)'){
           $la =$this->input->post('leather');
           // echo $la = implode (",", $this->input->post('leather'));
           // echo $la; die;
            $data['result'] = $this->_custom_leather_status_po_summary_on_co_id($la);
            $data['item_id'] = $la;
            $data['segment'] = 'leather_status_po';
            $data['segment1'] = 'leather_status_po';

            // echo '<pre>',print_r($data['result']),'</pre>'; die(); 

            return array('page'=>'reports/common_print_v','data'=>$data);

        }

        if($this->input->post('print') == 'Print'){
           // $la =$this->input->post('leather');
           $la = implode (",", $this->input->post('leather'));
           // echo $la; die;
           // foreach($la as $l) {
            // $data['customer_order'] = $this->_custom_leather_status_summary_on_co_id();
            $data['result1'] = $this->_custom_leather_status_summary_on_co_id_for_pur_order($la);
            
            // }
            $data['item_id'] = $la;
            $data['segment'] = 'leather_status';
            $data['segment1'] = 'leather_status';

            // echo '<pre>',print_r($data['result1']),'</pre>'; die(); 

            return array('page'=>'reports/common_print_v','data'=>$data);

        }
            $data['fetch_all_leather'] = $this->db
            ->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left')
            ->join('item_groups', 'item_groups.ig_id = item_master.ig_id', 'left')
            ->join('colors', 'colors.c_id = item_dtl.c_id', 'left')
            ->order_by('item_master.item, colors.color')
            ->get_where('item_dtl', array('item_dtl.status' => 1, 'item_groups.ig_id' => 1))->result();

        return array('page'=>'reports/leather_status_v', 'data'=>$data);
    }

    public function fetch_report_item_status() {
        $data = '';

        if($this->input->post('print') == 'Print(P.O. wise)'){
           $la =$this->input->post('leather');
           // echo $la = implode (",", $this->input->post('leather'));
           // echo $la; die;
            $data['result'] = $this->_custom_leather_status_po_summary_on_co_id($la);
            $data['item_id'] = $la;
            $data['segment'] = 'leather_status_po';
            $data['segment1'] = 'item_status_po';

            // echo '<pre>',print_r($data['result']),'</pre>'; die(); 

            return array('page'=>'reports/common_print_v','data'=>$data);

        }

        if($this->input->post('print') == 'Print'){
           // $la =$this->input->post('leather');
           $la = implode (",", $this->input->post('leather'));
           // echo $la; die;
           // foreach($la as $l) {
            $data['customer_order'] = $this->_custom_leather_status_summary_on_co_id_item_status($la);
            $data['result1'] = $this->_custom_leather_status_summary_on_co_id_for_pur_order($la);
            
            // }
            $data['item_id'] = $la;
            $data['segment'] = 'item_status';
            $data['segment1'] = 'item_status';

            // echo '<pre>',print_r($data['result1']),'</pre>'; die(); 

            return array('page'=>'reports/common_print_v','data'=>$data);
        }
            $data['fetch_all_group'] = $this->db->get_where('item_groups', array('status' => 1, 'ig_id !=' => 1))->result();
        return array('page'=>'reports/item_status_v', 'data'=>$data);
    }
    private function  _custom_leather_status_po_summary_on_co_id($la){
        if(empty($la)){
            die('No details found');
        }
        $result = $this->db->select('item_dtl.*, item_master.item, colors.color, purchase_order.po_id')
            ->join('purchase_order_details', 'purchase_order_details.po_id = purchase_order.po_id', 'left')
             ->join('item_dtl', 'item_dtl.id_id = purchase_order_details.id_id', 'left')
             ->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left')
             ->join('colors', 'colors.c_id = item_dtl.c_id', 'left')
             ->where_in('purchase_order_details.id_id', $la)
             ->where('purchase_order.status', '1')
             ->group_by('item_dtl.id_id')
             ->get_where('purchase_order')->result();

             return $result;
    }

    public function  _custom_leather_status_summary_on_co_id(){

$query = "SELECT
                customer_order.co_no,
                customer_order.co_date,
                customer_order.buyer_reference_no,
                customer_order.co_reference_date,
                item_master.item AS item_name,
                colors.color,
                colors.c_id as color_id,
                customer_order_dtl.cod_id,
                customer_order_dtl.co_id,
                article_costing.ac_id AS costing_id,
                article_costing_details.id_id AS item_dtl,
                article_costing_details.quantity AS item_dtl_quantity,
                item_dtl.id_id,
                item_master.im_id,
                article_master.am_id,
                article_master.art_no,
                article_dtl.lth_color_id,
                item_dtl.opening_stock AS final_opening_stock,
                item_dtl.opn_qnty_for_leather_status AS final_opn_qnty_for_leather_status,
                co_quantity,
                (
                   article_costing_details.quantity * co_quantity
                ) AS temp_qnty,
                SUM(
                   article_costing_details.quantity * co_quantity
                ) AS final_qnty
            FROM
                `customer_order`
            LEFT JOIN customer_order_dtl ON customer_order.co_id = customer_order_dtl.co_id
            LEFT JOIN article_master ON article_master.am_id = customer_order_dtl.am_id
            LEFT JOIN article_dtl ON article_dtl.am_id = article_master.am_id
            LEFT JOIN article_costing ON article_costing.am_id = article_master.am_id
            LEFT JOIN article_costing_details ON article_costing.ac_id = article_costing_details.ac_id
            LEFT JOIN acc_master ON acc_master.am_id = customer_order.acc_master_id
            LEFT JOIN item_dtl ON article_costing_details.id_id = item_dtl.id_id
            LEFT JOIN colors ON customer_order_dtl.lc_id = colors.c_id
            LEFT JOIN item_master ON item_master.im_id = item_dtl.im_id
            LEFT JOIN item_groups ON item_master.ig_id = item_groups.ig_id
            LEFT JOIN units ON item_groups.u_id = units.u_id
            WHERE
                customer_order.status = 1
            GROUP BY
                customer_order_dtl.co_id, customer_order_dtl.lc_id, item_dtl.im_id
                ";
        return $this->db->query($query)->result();

       // return  $customer_order_id; 
            
    }
    
    public function  _custom_leather_status_summary_on_co_id_item_status($la){

$query = "SELECT
                customer_order.co_no,
                customer_order.co_date,
                customer_order.buyer_reference_no,
                customer_order.co_reference_date,
                item_master.item AS item_name,
                colors.color,
                colors.c_id as color_id,
                customer_order_dtl.cod_id,
                customer_order_dtl.co_id,
                customer_order_dtl.lc_id,
                article_costing.ac_id AS costing_id,
                article_costing_details.id_id AS item_dtl,
                article_costing_details.quantity AS item_dtl_quantity,
                item_dtl.id_id,
                item_master.im_id,
                article_master.am_id,
                article_master.art_no,
                article_dtl.lth_color_id,
                item_dtl.opening_stock AS final_opening_stock,
                item_dtl.opn_qnty_for_leather_status AS final_opn_qnty_for_leather_status,
                co_quantity
                FROM
                `item_dtl`
                LEFT JOIN article_costing_details ON article_costing_details.id_id = item_dtl.id_id
                LEFT JOIN article_costing ON article_costing.ac_id = article_costing_details.ac_id
                LEFT JOIN article_master ON article_master.am_id = article_costing.am_id
                LEFT JOIN article_dtl ON article_dtl.am_id = article_master.am_id
                LEFT JOIN customer_order_dtl ON customer_order_dtl.am_id = article_master.am_id
                LEFT JOIN customer_order ON customer_order.co_id = customer_order_dtl.co_id
                LEFT JOIN acc_master ON acc_master.am_id = customer_order.acc_master_id
                LEFT JOIN colors ON colors.c_id = item_dtl.c_id
            LEFT JOIN item_master ON item_master.im_id = item_dtl.im_id
            LEFT JOIN item_groups ON item_master.ig_id = item_groups.ig_id
            LEFT JOIN units ON item_groups.u_id = units.u_id
            WHERE
                customer_order.status = 1 AND item_dtl.id_id IN ($la)
            GROUP BY
                customer_order_dtl.co_id, item_dtl.im_id, item_dtl.c_id 
                ";
        return $this->db->query($query)->result();

       // return  $customer_order_id; 
            
    }

    private function  _custom_leather_status_summary_on_co_id_for_pur_order($la){
        if(empty($la)){
            die('No details found');
        }

$query = "SELECT
    pur_order_details.*,
    IFNULL(
        SUM(
            supp_purchase_order_detail.item_qty
        ),
        0
    ) AS final_sup_pur_order_qnty
FROM
    (
    SELECT
        stock_in_details.*,
        IFNULL(
            SUM(
                purchase_order_details.pod_quantity
            ),
            0
        ) AS final_pur_issue_qnty
    FROM
        (
        SELECT
            mat_issue_details.*,
            IFNULL(
                SUM(
                    stock_in_detail.item_quantity
                ),
                0
            ) AS final_stock_in_qnty
        FROM
            (
            SELECT
                pur_rcv_details.*,
                IFNULL(
                    SUM(
                        material_issue_detail.issue_quantity
                    ),
                    0
                ) AS final_mat_issue_qnty
            FROM
                (
                SELECT
                    item_details.*,
                    IFNULL(
                        SUM(
                            purchase_order_receive_detail.item_quantity
                        ),
                        0
                    ) AS final_pur_rcv_qnty
                FROM
                    (
                    SELECT
                        item_master.item AS item_name,
                        colors.color,
                        article_costing.ac_id AS costing_id,
                        article_costing_details.id_id AS item_dtl,
                        article_costing_details.quantity AS item_dtl_quantity,
                        item_dtl.id_id,
                        item_master.im_id,
                        item_dtl.c_id,
                        article_costing.am_id,
                        customer_order_dtl.lc_id,
                        customer_order_dtl.co_id,
                        article_dtl.lth_color_id,
                        item_dtl.opening_stock AS final_opening_stock,
                        item_dtl.opn_qnty_for_leather_status AS final_opn_qnty_for_leather_status
                    FROM
                        `item_dtl`
                    LEFT JOIN article_costing_details ON item_dtl.id_id = article_costing_details.id_id
                    LEFT JOIN article_costing ON article_costing_details.id_id = article_costing.ac_id
                    LEFT JOIN article_master ON article_costing.am_id = article_master.am_id
                    LEFT JOIN customer_order_dtl ON customer_order_dtl.am_id = article_master.am_id
                    LEFT JOIN article_dtl ON article_master.am_id = article_dtl.am_id
                    LEFT JOIN colors ON item_dtl.c_id = colors.c_id
                    LEFT JOIN item_master ON item_dtl.im_id = item_master.im_id
                    WHERE
                        item_dtl.`id_id` IN($la)
                    GROUP BY
                        item_dtl.id_id
                ) AS item_details
            LEFT JOIN purchase_order_receive_detail ON item_details.id_id = purchase_order_receive_detail.id_id
            GROUP BY
                item_details.id_id
            ) AS pur_rcv_details
        LEFT JOIN material_issue_detail ON pur_rcv_details.id_id = material_issue_detail.id_id
        GROUP BY
            pur_rcv_details.id_id
        ) AS mat_issue_details
    LEFT JOIN stock_in_detail ON mat_issue_details.id_id = stock_in_detail.id_id
    GROUP BY
        mat_issue_details.id_id
    ) AS stock_in_details
LEFT JOIN purchase_order_details ON stock_in_details.id_id = purchase_order_details.id_id
GROUP BY
    stock_in_details.id_id
) AS pur_order_details
LEFT JOIN supp_purchase_order_detail ON pur_order_details.id_id = supp_purchase_order_detail.id_id
GROUP BY
    pur_order_details.id_id
ORDER BY
    pur_order_details.item_name, pur_order_details.color
                ";
        return $this->db->query($query)->result();

       // return  $customer_order_id; 
            
    }

    

    public function fetch_checking_summary_status_v() {
        $data = '';

        if($this->input->post('check_summary')){
            $order = $this->input->post('co[]');
                $emp = $this->input->post('emp[]');
                $from = $this->input->post('from');
                $to = $this->input->post('to');
                $category = $this->input->post('group');
                
                $data['category'] = $this->input->post('group');
          

            $data['result'] = $this->_fetch_all_checking_summary($order, $emp, $from, $to, $category);
            $data['segment'] = 'checking_summary_status';

            // echo '<pre>',print_r($result),'</pre>';

            return array('page'=>'reports/common_print_v','data'=>$data);

        }
        $data['co_ids'] = $this->db->get_where('customer_order', array('status' => 1))->result();
        $data['all_emp'] = $this->db->get_where('employees', array('status' => 1))->result();
        return array('page'=>'reports/checking_summary_v', 'data'=>$data);
    }

    private function _fetch_all_checking_summary($order, $emp, $from, $to, $category) {
       $this->db->select('checking.*,checking_details.*, article_master.art_no, colors.color as lc, colors.c_code, employees.name as emp_name, customer_order.co_no, customer_order.co_id, customer_order.buyer_reference_no, customer_order.co_total_quantity')
                ->join('checking_details', 'checking_details.checking_id=checking.checking_id', 'left')
                    ->join('employees', 'checking.e_id=employees.e_id', 'left')
                    ->join('customer_order', 'checking_details.co_id=customer_order.co_id', 'left')
                    ->join('article_master', 'checking_details.am_id=article_master.am_id', 'left')
                    ->join('article_dtl', 'article_master.am_id = article_dtl.am_id', 'left')
                    ->join('colors', 'article_dtl.lth_color_id = colors.c_id', 'left');
                    if($category == 'emp') {
                        $this->db->order_by('employees.name');
                    } else {
                        $this->db->order_by('customer_order.co_no, article_master.art_no, lc');
                    }
                    $this->db->where_in('customer_order.co_id', $order)
                             ->where_in('checking.e_id', $emp);
                    if($from != '' or $to != '') {
                        $this->db->where('checking.checking_start_date_time >=', $from)
                                ->where('checking.checking_end_date_time <=', $to);
                    }
                    $res = $this->db->get('checking')->result();
        // echo '<pre>', print_r($res), '</pre>'; die;           
        return $res;
    }

    public function fetch_checking_entry_sheet() {
        $data = '';

        if($this->input->post('check_entry_sheet')){
                $order = implode (",", $this->input->post('co[]'));
             // $order = $this->input->post($cos);
                $from = $this->input->post('from');
                $to = $this->input->post('to');
                
            $data['from'] = $this->input->post('from');
            $data['to'] = $this->input->post('to');
            $data['result'] = $this->_fetch_checking_entry_sheet_details($order, $from, $to);
            $data['segment'] = 'checking_entry_sheet_status';

            // echo '<pre>',print_r($result),'</pre>';

            return array('page'=>'reports/common_print_v','data'=>$data);

        }
// fetch department-wisemodule permission
            $session_user_id = $this->session->user_id;
            # if id is returned then filter else show all
            $module_permission = $this->_dept_wise_module_permission(1, $session_user_id); #1 = costing module_id

            if($module_permission == 'show'){
    $data['order_details'] = $this->db->select('co_id, co_no')->order_by('co_no')->get_where('customer_order', array('customer_order.status => 1'))->result();
            } else {
                #module_permission contains the dept id now
    $data['order_details'] = $this->db->select('co_id, co_no')
                    ->join('user_details','user_details.user_id = customer_order.user_id','left')
                    ->order_by('co_no')
                    ->get_where('customer_order', array('user_details.user_dept' => $module_permission, 'customer_order.status' => '1'))->result();
            }        return array('page'=>'reports/check_entry_sheet_v', 'data'=>$data);
    }

    public function _fetch_checking_entry_sheet_details($order, $from, $to){

     if(empty($order)){
            die('No details found');
        }


        $query = "SELECT
                customer_order.co_no,
                customer_order.co_date,
                customer_order.buyer_reference_no,
                customer_order.co_reference_date,
                acc_master.name,
                article_master.art_no,
                article_master.info,
                article_master.am_id,
                article_master.alt_art_no,
                acc_master.short_name,
                article_master.ag_id,
                c1.color as leather_color,
                c2.color as fitting_color,
                c3.color as aricle_color,
                customer_order_dtl.cod_id,
                customer_order_dtl.co_id,
                customer_order_dtl.am_id,
                co_quantity,
                (
                    co_quantity
                ) AS temp_qnty,
                SUM(
                    co_quantity
                ) AS final_qnty
            FROM
                `customer_order`
            LEFT JOIN customer_order_dtl ON customer_order.co_id = customer_order_dtl.co_id
            LEFT JOIN article_master ON article_master.am_id = customer_order_dtl.am_id
            LEFT JOIN article_dtl ON article_dtl.am_id = article_master.am_id
            LEFT JOIN acc_master ON acc_master.am_id = customer_order.acc_master_id
            LEFT JOIN colors c1 ON customer_order_dtl.lc_id = c1.c_id
            LEFT JOIN colors c2 ON customer_order_dtl.fc_id = c2.c_id
            LEFT JOIN colors c3 ON article_dtl.lth_color_id = c3.c_id
            LEFT JOIN article_groups ON article_groups.ag_id = article_master.ag_id

            WHERE
                customer_order.`co_id`IN ($order) AND customer_order.status = 1
            GROUP BY
                article_master.am_id, customer_order_dtl.lc_id
            ORDER BY
            customer_order.co_no";
        return $this->db->query($query)->result();

    }

    public function fetch_stock_summary_status() {
        $data = '';

        if($this->input->post('check_stock_summary')){
            $gr = $this->input->post('group');
                $it_arr = $this->input->post('items[]');
                $from = $this->input->post('fromdate');
                $to = $this->input->post('todate');
            $data['result'] = $this->_fetch_all_checking_stock_summary_details($it_arr, $from, $to);
            $data['segment'] = 'checking_stock_summary_status';

            // echo '<pre>',print_r($result),'</pre>';

            return array('page'=>'reports/common_print_v','data'=>$data);

        }
        $data['fetch_all_group'] = $this->db->get_where('item_groups', array('status' => 1))->result();
        return array('page'=>'reports/stock_summary_v', 'data'=>$data);
    }

    public function items_on_item_group_m($par){
        $result = $this->db
            ->join('item_dtl', 'item_dtl.im_id = item_master.im_id', 'left')
            ->join('colors', 'item_dtl.c_id = colors.c_id', 'left')
            ->order_by('item_master.item, colors.color')
            ->get_where('item_master', array('ig_id' => $par))->result();
       // echo '<pre>',print_r($result),'</pre>'; die();
       return $result;   
    }

    public function _fetch_all_checking_stock_summary_details($it_arr, $from, $to){
        $from = date('Y-m-d', strtotime($from));
        $to = date('Y-m-d', strtotime($to));
        $data_array = array();
        // echo $from; die();
        // echo '<pre>',print_r($it_arr),'</pre>'; die();
      foreach($it_arr as $id_id) {
if($from == '2021-04-01') {
    
    $this->db->where('item_dtl.id_id', $id_id);
                $row_opn = $this->db->get('item_dtl')->row();
                if(count($row_opn) == 0) continue;
    
       $opening_row = $this->db->select('item_dtl.id_id, item_dtl.opening_stock as opening_qty, item_master.item, colors.color, item_dtl.opening_rate')
                ->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left')
                ->join('colors', 'colors.c_id = item_dtl.c_id', 'left')
                ->where('item_dtl.id_id', $id_id)
                ->get('item_dtl')->row();

                // echo '<pre>',print_r($opening_row),'</pre>';
         
        $purchase_row = $this->db->select('SUM(item_quantity) as purch_qty, SUM(item_quantity * item_rate) as purch_rate')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->where('STR_TO_DATE(purchase_order_receive.purchase_order_receive_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($from)) . '" and "' . date('Y-m-d', strtotime($to)) . '"')
                ->where('purchase_order_receive_detail.id_id', $id_id)
                ->group_by('purchase_order_receive_detail.id_id')
                ->get('purchase_order_receive_detail')->row();

                if(count($purchase_row) != 0) {
                    $purchase_qnty = $purchase_row->purch_qty;
                    $purchase_val = $purchase_row->purch_rate;
                } else {
                    $purchase_qnty = 0;
                    $purchase_val = 0;
                }

        $issue_row = $this->db->select('SUM(material_issue_detail.issue_quantity) as issue_qnty, SUM(material_issue_detail.issue_quantity * material_issue_detail.issue_rate) as issue_rate')
                ->join('material_issue', 'material_issue.material_issue_id = material_issue_detail.material_issue_id', 'left')
                ->where('STR_TO_DATE(material_issue.material_issue_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($from)) . '" and "' . date('Y-m-d', strtotime($to)) . '"')
                ->where('material_issue_detail.id_id', $id_id)
                ->group_by('material_issue_detail.id_id')
                ->get('material_issue_detail')->row();

                if(count($issue_row) != 0) {
                    $issue_qnty = $issue_row->issue_qnty;
                    $issue_val = $issue_row->issue_rate;
                } else {
                    $issue_qnty = 0;
                    $issue_val = 0;
                }

        $stockin_row = $this->db->select('SUM(stock_in_detail.item_quantity) as stock_qnty, SUM(stock_in_detail.item_quantity * stock_in_detail.item_rate) as stock_rate')
                ->where('stock_in_detail.id_id', $id_id)
                ->group_by('stock_in_detail.id_id')
                ->get('stock_in_detail')->row();

                if(count($stockin_row) != 0) {
                    $stock_in_qnty = $stockin_row->stock_qnty;
                    $stock_in_val = $stockin_row->stock_rate;
                } else {
                    $stock_in_qnty = 0;
                    $stock_in_val = 0;
                }


                $arr = array(
                    'id_id'=>$opening_row->id_id,
                    'item' =>$opening_row->item,
                    'color'=>$opening_row->color,
                    'opening_qnty'=>$opening_row->opening_qty,
                    'opening_val'=>$opening_row->opening_qty * $opening_row->opening_rate,
                    'purchase_qnty'=> $purchase_qnty,
                    'purchase_val'=>$purchase_val,
                    'issue_qnty'=>$issue_qnty,
                    'issue_val'=>$issue_val,
                    'stock_in_qnty'=>$stock_in_qnty,
                    'stock_in_val'=>$stock_in_val,
                );
                array_push($data_array, $arr);
                
            } else {
                
                $this->db->where('item_dtl.id_id', $id_id);
                $row_opn = $this->db->get('item_dtl')->row();
                if(count($row_opn) == 0) continue;
                
        $df_new = date('Y-m-d', strtotime('2021/04/01'));

       $opening_row = $this->db->select('item_dtl.id_id, item_dtl.opening_stock as opening_qty, item_master.item, colors.color, item_dtl.opening_rate')
                ->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left')
                ->join('colors', 'colors.c_id = item_dtl.c_id', 'left')
                ->where('item_dtl.id_id', $id_id)
                ->get('item_dtl')->row();

                // echo '<pre>',print_r($opening_row),'</pre>';
         
        $purchase_row = $this->db->select('SUM(item_quantity) as purch_qty, SUM(item_quantity * item_rate) as purch_total')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->where('STR_TO_DATE(purchase_order_receive.purchase_order_receive_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df_new)) . '" and "' . date('Y-m-d', strtotime($from)) . '"')
                ->where('purchase_order_receive_detail.id_id', $id_id)
                ->group_by('purchase_order_receive_detail.id_id')
                ->get('purchase_order_receive_detail')->row();

                if(count($purchase_row) != 0) {
                    $purchase_qnty = $purchase_row->purch_qty;
                    $purchase_val = $purchase_row->purch_total;
                } else {
                    $purchase_qnty = 0;
                    $purchase_val = 0;
                }

        $issue_row = $this->db->select('SUM(material_issue_detail.issue_quantity) as issue_qnty, SUM(material_issue_detail.issue_quantity * material_issue_detail.issue_rate) as issue_rate')
                ->join('material_issue', 'material_issue.material_issue_id = material_issue_detail.material_issue_id', 'left')
                ->where('STR_TO_DATE(material_issue.material_issue_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df_new)) . '" and "' . date('Y-m-d', strtotime($from)) . '"')
                ->where('material_issue_detail.id_id', $id_id)
                ->group_by('material_issue_detail.id_id')
                ->get('material_issue_detail')->row();

                if(count($issue_row) != 0) {
                    $issue_qnty = $issue_row->issue_qnty;
                    $issue_val = $issue_row->issue_rate;
                } else {
                    $issue_qnty = 0;
                    $issue_val = 0;
                }

                $stockin_row = $this->db->select('SUM(stock_in_detail.item_quantity) as stock_qnty, SUM(stock_in_detail.item_quantity * stock_in_detail.item_rate) as stock_rate')
                ->where('stock_in_detail.id_id', $id_id)
                ->group_by('stock_in_detail.id_id')
                ->get('stock_in_detail')->row();

                if(count($stockin_row) != 0) {
                    $stock_in_qnty = $stockin_row->stock_qnty;
                    $stock_in_val = $stockin_row->stock_rate;
                } else {
                    $stock_in_qnty = 0;
                    $stock_in_val = 0;
                }

                $opng_qnty = $opening_row->opening_qty + $purchase_qnty - $issue_qnty + $stock_in_qnty;
                $opng_val = ($opening_row->opening_qty * $opening_row->opening_rate) + $purchase_val - $issue_val + $stock_in_val;

            $purchase_row = $this->db->select('SUM(item_quantity) as purch_qty, SUM(item_quantity * item_rate) as purch_total')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->where('STR_TO_DATE(purchase_order_receive.purchase_order_receive_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($from)) . '" and "' . date('Y-m-d', strtotime($to)) . '"')
                ->where('purchase_order_receive_detail.id_id', $id_id)
                ->group_by('purchase_order_receive_detail.id_id')
                ->get('purchase_order_receive_detail')->row();

                if(count($purchase_row) != 0) {
                    $purchase_qnty = $purchase_row->purch_qty;
                    $purchase_val = $purchase_row->purch_total;
                } else {
                    $purchase_qnty = 0;
                    $purchase_val = 0;
                }

        $issue_row = $this->db->select('SUM(material_issue_detail.issue_quantity) as issue_qnty, SUM(material_issue_detail.total_amount) as issue_total')
                ->join('material_issue', 'material_issue.material_issue_id = material_issue_detail.material_issue_id', 'left')
                ->where('STR_TO_DATE(material_issue.material_issue_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($from)) . '" and "' . date('Y-m-d', strtotime($to)) . '"')
                ->where('material_issue_detail.id_id', $id_id)
                ->group_by('material_issue_detail.id_id')
                ->get('material_issue_detail')->row();

                if(count($issue_row) != 0) {
                    $issue_qnty = $issue_row->issue_qnty;
                    $issue_val = $issue_row->issue_total;
                } else {
                    $issue_qnty = 0;
                    $issue_val = 0;
                }

                $arr = array(
                    'id_id'=>$opening_row->id_id,
                    'item' =>$opening_row->item,
                    'color'=>$opening_row->color,
                    'opening_qnty'=>$opng_qnty,
                    'opening_val'=>$opng_val,
                    'purchase_qnty'=> $purchase_qnty,
                    'purchase_val'=>$purchase_val,
                    'issue_qnty'=>$issue_qnty,
                    'issue_val'=>$issue_val,
                    'stock_in_qnty'=>$stock_in_qnty,
                    'stock_in_val'=>$stock_in_val,
                );
                array_push($data_array, $arr);
                
            }
          }
          return $data_array;
    }
    
    public function fetch_stock_summary_ledger() {
        $data = '';
        if($this->input->post('check_stock_detail_ledger')){
            $gr = $this->input->post('group');
                $it_arr = $this->input->post('items[]');
                $from = $this->input->post('fromdate');
                $to = $this->input->post('todate');
            $data['result'] = $this->_fetch_stock_summary_ledger_details($it_arr, $from, $to);
            $data['segment'] = 'checking_stock_detail_ledger';
            // echo '<pre>',print_r($result),'</pre>';
            return array('page'=>'reports/common_print_v','data'=>$data);
        }
        $data['fetch_all_group'] = $this->db->get_where('item_groups', array('status' => 1))->result();
        return array('page'=>'reports/stock_detail_ledger_v', 'data'=>$data);
    }

    public function _fetch_stock_summary_ledger_details($it_arr, $from, $to) {
        $from = date('Y-m-d', strtotime($from));
        $to = date('Y-m-d', strtotime($to));
        $df_new = date('Y-m-d', strtotime('01-04-2020'));
        $this->db->empty_table('temp_table'); 
        // echo $this->db->last_query(); die();
      foreach($it_arr as $id_id) {
         $bal_qnty = 0; $bal_val = 0;
if($from == '2020-04-01') {


    $this->db->where('item_dtl.id_id', $id_id);
                $row_opn = $this->db->get('item_dtl')->row();
                if(count($row_opn) == 0) continue;

       $rs_opn = $this->db->select('item_dtl.id_id, item_dtl.opening_stock as opening_qty, item_master.item, colors.color, item_dtl.opening_rate')
                ->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left')
                ->join('colors', 'colors.c_id = item_dtl.c_id', 'left')
                ->where('item_dtl.id_id', $id_id)
                ->get('item_dtl')->result_array();

                // echo '<pre>',print_r($opening_row),'</pre>';
         
        $rs_pur = $this->db->select('item_master.item, colors.color, purchase_order_receive.purchase_order_receive_bill_no, purchase_order_receive.purchase_order_receive_date, purchase_order_receive_detail.item_quantity, purchase_order_receive_detail.item_rate, purchase_order_receive_detail.pod_total')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->join('item_dtl', 'item_dtl.id_id = purchase_order_receive_detail.id_id', 'left')
                ->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left')
                ->join('colors', 'colors.c_id = item_dtl.c_id', 'left')
                ->where('STR_TO_DATE(purchase_order_receive.purchase_order_receive_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($from)) . '" and "' . date('Y-m-d', strtotime($to)) . '"')
                ->where('purchase_order_receive_detail.id_id', $id_id)
                ->order_by("str_to_date(purchase_order_receive.purchase_order_receive_date, '%d-%m-%Y') ASC")
                ->get('purchase_order_receive_detail')->result_array();

        $rs_issue = $this->db->select('item_master.item, colors.color, material_issue.material_issue_slip_number, material_issue.material_issue_date, material_issue_detail.issue_quantity, material_issue_detail.issue_rate,
            material_issue_detail.total_amount')
                ->join('material_issue', 'material_issue.material_issue_id = material_issue_detail.material_issue_id', 'left')
                ->join('item_dtl', 'item_dtl.id_id = material_issue_detail.id_id', 'left')
                 ->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left')
                ->join('colors', 'colors.c_id = item_dtl.c_id', 'left')
                ->where('STR_TO_DATE(material_issue.material_issue_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($from)) . '" and "' . date('Y-m-d', strtotime($to)) . '"')
                ->where('material_issue_detail.id_id', $id_id)
                ->order_by("str_to_date(material_issue.material_issue_date, '%d-%m-%Y') ASC")
                ->get('material_issue_detail')->result_array();

        foreach ($rs_opn as $val) {
                    $this->db->where('id_id', $val['id_id']);
                    $this->db->where("str_to_date(`effective_date`, '%d-%m-%Y') <=", $df_new);
                    $this->db->order_by("str_to_date(`effective_date`, '%d-%m-%Y') DESC");
                    $row_opn_rate = $this->db->get('item_rates')->row();
                    if(count($row_opn_rate) != 0) {
                        $opn_rate = $row_opn_rate->purchase_rate;
                    } else {
                        $opn_rate = 0;
                    }

                    $data_insert['item'] = $val['item'];
                    $data_insert['color'] = $val['color'];
                    $data_insert['remark'] = 'Opening';
                    $data_insert['seq'] = '1';
                    $data_insert['sl_no'] = '';
                    $data_insert['date'] = '2019-04-01';
                    $data_insert['qnty'] = $val['opening_qty'];
                    $data_insert['rate'] = $val['opening_rate'];
                    $data_insert['val'] = $val['opening_qty'] * $val['opening_rate'];
                    $this->db->insert('temp_table', $data_insert);
                }

                foreach ($rs_pur as $val) {
                    $data_insert['item'] = $val['item'];
                    $data_insert['color'] = $val['color'];
                    $data_insert['remark'] = 'Purchase';
                    $data_insert['seq'] = '2';
                    $data_insert['sl_no'] = $val['purchase_order_receive_bill_no'];
                    $data_insert['date'] = date('Y-m-d', strtotime($val['purchase_order_receive_date']));
                    $data_insert['qnty'] = $val['item_quantity'];
                    $data_insert['rate'] = $val['item_rate'];
                    $data_insert['val'] = $val['pod_total'];
                    $this->db->insert('temp_table', $data_insert);
                }

                foreach ($rs_issue as $val) {
                    $data_insert['item'] = $val['item'];
                    $data_insert['color'] = $val['color'];
                    $data_insert['remark'] = 'Issue';
                    $data_insert['seq'] = '3';
                    $data_insert['sl_no'] = $val['material_issue_slip_number'];
                    $data_insert['date'] = date('Y-m-d', strtotime($val['material_issue_date']));
                    $data_insert['qnty'] = $val['issue_quantity'];
                    $data_insert['rate'] = $val['issue_rate'];
                    $data_insert['val'] = $val['total_amount'];
                    $this->db->insert('temp_table', $data_insert);
                }


                
                
            } else {
        $df_open = date('Y-m-d', strtotime('2020/04/01'));

        $this->db->where('item_dtl.id_id', $id_id);
                $row_opn = $this->db->get('item_dtl')->row();
                if(count($row_opn) == 0) continue;

       $rs_opn = $this->db->select('item_dtl.id_id, item_dtl.opening_stock as opening_qty, item_master.item, colors.color, item_dtl.opening_rate')
                ->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left')
                ->join('colors', 'colors.c_id = item_dtl.c_id', 'left')
                ->where('item_dtl.id_id', $id_id)
                ->get('item_dtl')->result_array();

                    // $this->db->where('id_id', $id_id);
                    // $this->db->where("str_to_date(`effective_date`, '%d-%m-%Y') <=", $df_new);
                    // $this->db->order_by("str_to_date(`effective_date`, '%d-%m-%Y') DESC");
                    // $row_opn_rate = $this->db->get('item_rates')->row();
                    // if(count($row_opn_rate) != 0) {
                    //     $opn_rate = $row_opn_rate->purchase_rate;
                    // } else {
                    //     $opn_rate = 0;
                    // }
                // echo '<pre>',print_r($opening_row),'</pre>';
         
        $row_pur = $this->db->select('SUM(item_quantity) as purch_qty, SUM(item_quantity * item_rate) as purch_total')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->where('STR_TO_DATE(purchase_order_receive.purchase_order_receive_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df_open)) . '" and "' . date('Y-m-d', strtotime($from)) . '"')
                ->where('purchase_order_receive_detail.id_id', $id_id)
                ->group_by('purchase_order_receive_detail.id_id')
                ->get('purchase_order_receive_detail')->row();

                if(count($row_pur) != 0) {
                    $pur_qty = $purchase_row->purch_qty;
                    $pur_val = $purchase_row->purch_total;
                } else {
                    $pur_qty = 0;
                    $pur_val = 0;
                }

        $row_issue = $this->db->select('SUM(material_issue_detail.issue_quantity) as issue_qnty, SUM(material_issue_detail.issue_quantity * material_issue_detail.issue_rate) as issue_rate')
                ->join('material_issue', 'material_issue.material_issue_id = material_issue_detail.material_issue_id', 'left')
                ->where('STR_TO_DATE(material_issue.material_issue_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df_open)) . '" and "' . date('Y-m-d', strtotime($from)) . '"')
                ->where('material_issue_detail.id_id', $id_id)
                ->group_by('material_issue_detail.id_id')
                ->get('material_issue_detail')->row();

                if(count($row_issue) != 0) {
                    $issue_qty = $issue_row->issue_qnty;
                    $issue_val = $issue_row->issue_rate;
                } else {
                    $issue_qty = 0;
                    $issue_val = 0;
                }

                $stockin_row = $this->db->select('SUM(stock_in_detail.item_quantity) as stock_qnty, SUM(stock_in_detail.item_quantity * stock_in_detail.item_rate) as stock_rate')
                ->where('stock_in_detail.id_id', $id_id)
                ->group_by('stock_in_detail.id_id')
                ->get('stock_in_detail')->row();

                if(count($stockin_row) != 0) {
                    $stock_in_qnty = $stockin_row->stock_qnty;
                    $stock_in_val = $stockin_row->stock_rate;
                } else {
                    $stock_in_qnty = 0;
                    $stock_in_val = 0;
                }

                $opn_qnty = $rs_opn[0]['opening_qty'] + $pur_qty - $issue_qty + $stock_in_qnty;
                $opn_val = ($rs_opn[0]['opening_qty'] * $rs_opn[0]['opening_rate']) + $pur_val - $issue_val + $stock_in_val;

            $rs_pur = $this->db->select('item_master.item, colors.color, purchase_order_receive.purchase_order_receive_bill_no, purchase_order_receive.purchase_order_receive_date, purchase_order_receive_detail.item_quantity, purchase_order_receive_detail.item_rate, purchase_order_receive_detail.pod_total')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->join('item_dtl', 'item_dtl.id_id = purchase_order_receive_detail.id_id', 'left')
                ->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left')
                ->join('colors', 'colors.c_id = item_dtl.c_id', 'left')
                ->where('STR_TO_DATE(purchase_order_receive.purchase_order_receive_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($from)) . '" and "' . date('Y-m-d', strtotime($to)) . '"')
                ->where('purchase_order_receive_detail.id_id', $id_id)
                ->order_by("str_to_date(purchase_order_receive.purchase_order_receive_date, '%d-%m-%Y') ASC")
                ->get('purchase_order_receive_detail')->result_array();

        $rs_issue = $this->db->select('item_master.item, colors.color, material_issue.material_issue_slip_number, material_issue.material_issue_date, material_issue_detail.issue_quantity, material_issue_detail.issue_rate,
            material_issue_detail.total_amount')
                ->join('material_issue', 'material_issue.material_issue_id = material_issue_detail.material_issue_id', 'left')
                ->join('item_dtl', 'item_dtl.id_id = material_issue_detail.id_id', 'left')
                 ->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left')
                ->join('colors', 'colors.c_id = item_dtl.c_id', 'left')
                ->where('STR_TO_DATE(material_issue.material_issue_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($from)) . '" and "' . date('Y-m-d', strtotime($to)) . '"')
                ->where('material_issue_detail.id_id', $id_id)
                ->order_by("str_to_date(material_issue.material_issue_date, '%d-%m-%Y') ASC")
                ->get('material_issue_detail')->result_array();

                foreach ($rs_opn as $val) {
                    if($opn_qnty == 0) $avg_rate = 0; else $avg_rate = $opn_val / $opn_qnty;

                    $data_insert['item'] = $val['item'];
                    $data_insert['color'] = $val['color'];
                    $data_insert['remark'] = 'Opening';
                    $data_insert['seq'] = '1';
                    $data_insert['sl_no'] = '';
                    $data_insert['date'] = '2019-04-01';
                    $data_insert['qnty'] = $opn_qnty;
                    $data_insert['rate'] = $avg_rate;
                    $data_insert['val'] = $opn_val;
                    $this->db->insert('temp_table', $data_insert);
                }

                foreach ($rs_pur as $val) {
                    $data_insert['item'] = $val['item'];
                    $data_insert['color'] = $val['color'];
                    $data_insert['remark'] = 'Purchase';
                    $data_insert['seq'] = '2';
                    $data_insert['sl_no'] = $val['purchase_order_receive_bill_no'];
                    $data_insert['date'] = date('Y-m-d', strtotime($val['purchase_order_receive_date']));
                    $data_insert['qnty'] = $val['item_quantity'];
                    $data_insert['rate'] = $val['item_rate'];
                    $data_insert['val'] = $val['pod_total'];
                    $this->db->insert('temp_table', $data_insert);
                }

                foreach ($rs_issue as $val) {
                    $data_insert['item'] = $val['item'];
                    $data_insert['color'] = $val['color'];
                    $data_insert['remark'] = 'Issue';
                    $data_insert['seq'] = '3';
                    $data_insert['sl_no'] = $val['material_issue_slip_number'];
                    $data_insert['date'] = date('Y-m-d', strtotime($val['material_issue_date']));
                    $data_insert['qnty'] = $val['issue_quantity'];
                    $data_insert['rate'] = $val['issue_rate'];
                    $data_insert['val'] = $val['total_amount'];
                    $this->db->insert('temp_table', $data_insert);
                }
            }
          }
         $this->db->order_by("item,color,date,seq");
        $temp_table = $this->db->get('temp_table')->result_array();

        return $temp_table;
    }

    
    public function fetch_supplier_wise_item_position() {
        $data = '';
        if($this->input->post('supplier_wise_item_position')) {
            $gr = $this->input->post('group');
            $it_arr = $this->input->post('items[]');
            $data['result'] = $this->_fetch_supplier_wise_item_position_details($it_arr);
            $data['segment'] = 'supplier_wise_item_position';
            // echo '<pre>',print_r($result),'</pre>';
            return array('page'=>'reports/common_print_v','data'=>$data);
        }
        $data['fetch_all_group'] = $this->db->get_where('item_groups', array('status' => 1))->result();
        return array('page'=>'reports/supplier_wise_item_position_v', 'data'=>$data);
    }

    
public function _fetch_supplier_wise_item_position_details($it_arr) {
    
  $opening_row = $this->db->select('item_dtl.id_id, item_dtl.opening_stock as opening_qty, item_master.item, colors.color')
                ->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left')
                ->join('colors', 'colors.c_id = item_dtl.c_id', 'left')
                ->where_in('item_dtl.id_id', $it_arr)
                ->get('item_dtl')->result();

  return $opening_row; 

 // $purchase_row = $this->db->select('purchase_order.po_id, purchase_order.po_number, acc_master.name, po_date, pod_quantity')
 //                ->join('purchase_order', 'purchase_order.po_id = purchase_order_details.po_id', 'left')
 //                ->join('acc_master', 'acc_master.am_id = purchase_order.am_id', 'left')
 //                ->where('purchase_order_details.id_id', $id_id)
 //                ->group_by('purchase_order_details.id_id')
 //                ->get('purchase_order_details')->row();

 // $supplier_row = $this->db->select('supp_po_number, pur_order_date, supp_po_total');
 //                ->join('supp_purchase_order_detail', 'supp_purchase_order_detail.sup_id = supp_purchase_order.sup_id', 'left')
 //                ->where('supp_purchase_order_detail.id_id', $id_id)
 //                ->get('supp_purchase_order')->row();               

    }
    public function fetch_supplier_purchase_ledger() {
        $data = '';
        if($this->input->post('supplier_wise_item_position')) {
            $it_arr = $this->input->post('items[]');
            $data['from'] = $this->input->post('fromdate');
            $data['to'] = $this->input->post('todate');
            $data['result'] = $this->_fetch_supplier_purchase_ledger_details($it_arr);
            $data['segment'] = 'supplier_purchase_ledger';
            // echo '<pre>',print_r($result),'</pre>';
            return array('page'=>'reports/common_print_v','data'=>$data);
        }
        $data['buyers'] = $this->db->get_where('acc_master', array('status' => 1))->result();
        return array('page'=>'reports/supplier_purchase_ledger_v', 'data'=>$data);
    }

    
public function _fetch_supplier_purchase_ledger_details($it_arr) {
    
  $opening_row = $this->db->select('purchase_order_receive.*, SUM(purchase_order_receive_detail.item_quantity) AS item_quantity, acc_master.name AS acc_name')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->join('acc_master', 'acc_master.am_id = purchase_order_receive.am_id', 'left')
                ->where_in('purchase_order_receive.am_id', $it_arr)
                ->group_by('purchase_order_receive_detail.purchase_order_receive_id')
                ->get('purchase_order_receive_detail')->result();

  return $opening_row; 

 // $purchase_row = $this->db->select('purchase_order.po_id, purchase_order.po_number, acc_master.name, po_date, pod_quantity')
 //                ->join('purchase_order', 'purchase_order.po_id = purchase_order_details.po_id', 'left')
 //                ->join('acc_master', 'acc_master.am_id = purchase_order.am_id', 'left')
 //                ->where('purchase_order_details.id_id', $id_id)
 //                ->group_by('purchase_order_details.id_id')
 //                ->get('purchase_order_details')->row();

 // $supplier_row = $this->db->select('supp_po_number, pur_order_date, supp_po_total');
 //                ->join('supp_purchase_order_detail', 'supp_purchase_order_detail.sup_id = supp_purchase_order.sup_id', 'left')
 //                ->where('supp_purchase_order_detail.id_id', $id_id)
 //                ->get('supp_purchase_order')->row();               

    }
    
    public function fetch_supplier_wise_purchase_position() {
        $data = '';
        if($this->input->post('supplier_wise_item_position')) {
            $it_arr = $this->input->post('items[]');
            $data['from'] = $this->input->post('fromdate');
            $data['to'] = $this->input->post('todate');
            $from = $this->input->post('fromdate');
            $to = $this->input->post('todate'); 
            $data['result'] = $this->_fetch_supplier_wise_purchase_position($it_arr, $from, $to);
            // echo '<pre>', print_r($data['result']), '</pre>'; die();
            $data['segment'] = 'supplier_wise_purchase_position';
            // echo '<pre>',print_r($result),'</pre>';
            return array('page'=>'reports/common_print_v','data'=>$data);
        }
        $data['buyers'] = $this->db->get_where('acc_master', array('status' => 1, 'ag_id' => 1))->result();
        return array('page'=>'reports/supplier_wise_purchase_position_v', 'data'=>$data);
    }

    public function _fetch_supplier_wise_purchase_position($it_arr, $from, $to) {
   
  foreach($it_arr as $am) { 
  $query = "SELECT
                                    `purchase_order`.`po_id`,
                                    `purchase_order`.`po_number`,
                                    `purchase_order`.`am_id`,
                                    `purchase_order`.`po_date`,
                                    `acc_master`.`name`,
                                    `purchase_order_details`.`id_id`,
                                    `item_master`.`item`,
                                    `colors`.`color`,
                                    SUM(
                        IFNULL(
                            purchase_order_details.pod_quantity,
                            0
                        )
                    ) AS pod_quantity
                                FROM
                                    `purchase_order_details`
                                LEFT JOIN `purchase_order` ON `purchase_order`.`po_id` = `purchase_order_details`.`po_id`
                                LEFT JOIN `acc_master` ON `purchase_order`.`am_id` = `acc_master`.`am_id`
                                LEFT JOIN `item_dtl` ON `item_dtl`.`id_id` = `purchase_order_details`.`id_id`
                                LEFT JOIN `item_master` ON `item_master`.`im_id` = `item_dtl`.`im_id`
                                LEFT JOIN `colors` ON `colors`.`c_id` = `item_dtl`.`c_id`
                                WHERE
                                    `purchase_order`.am_id = $am AND `purchase_order`.status = 1
                                AND STR_TO_DATE(purchase_order.po_date, '%Y-%m-%d') <= '$to' AND STR_TO_DATE(purchase_order.po_date, '%Y-%m-%d') >= '$from'
                                GROUP BY
                                purchase_order.po_id, purchase_order_details.id_id
                                ORDER BY
                                purchase_order.po_number, item_master.item, colors.color";

            return $this->db->query($query)->result();  
            }              
    }
    
    public function fetch_group_stock_summary() {
        $data = '';
        if($this->input->post('supplier_wise_item_position')) {
            $it_arr = $this->input->post('items[]');
            $df = $this->input->post('fromdate');
            $dt = $this->input->post('todate');
            $data['result'] = $this->_fetch_group_stock_summary_details($it_arr, $df, $dt);
            $data['segment'] = 'group_stock_summary';
            // echo '<pre>',print_r($data['result']),'</pre>'; die();
            return array('page'=>'reports/common_print_v','data'=>$data);
        }
        $data['fetch_all_group'] = $this->db->get_where('item_groups', array('status' => 1))->result();
        return array('page'=>'reports/group_stock_summary_v', 'data'=>$data);
    } 

    public function _fetch_group_stock_summary_details($it_arr, $df, $dt) {
   
        $df = date('Y-m-d', strtotime($df));
        $dt = date('Y-m-d', strtotime($dt));
        $dt_1419 = date('Y-m-d', strtotime('2020-04-01'));

        $this->db->where_in('ig_id', $it_arr);
        // $this->db->order_by('GROUP_DESC');
        $rs_group = $this->db->get('item_groups')->result_array();


        //-------------------------------LOCAL REPORT START--------------------------
        $html = '';
        $grand_tot1 = 0;$grand_tot2 = 0;$grand_tot3 = 0;$grand_tot4 = 0;
        $grand_tot5 = 0;$grand_tot6 = 0;$grand_tot7 = 0;$grand_tot8 = 0; $grand_tot9 = 0; $grand_tot10 = 0;

        //item group loop
        foreach ($rs_group as $group) {
            $grp_tot1 = 0;$grp_tot2 = 0;$grp_tot3 = 0;$grp_tot4 = 0;
            $grp_tot5 = 0;$grp_tot6 = 0;$grp_tot7 = 0;$grp_tot8 = 0; $grp_tot9 = 0; 
            $grp_tot10 = 0;

            //individual item+color
            $this->db->join('item_dtl', 'item_dtl.im_id = item_master.im_id', 'left');
            $this->db->join('colors', 'colors.c_id = item_dtl.c_id', 'left');
            $this->db->where('ig_id', $group['ig_id']);
            $this->db->where('type', 'Local'); //local
            $rs_item = $this->db->get('item_master')->result_array();

            if(count($rs_item) == 0) continue;

            foreach ($rs_item as $item) {
                $item_dtl_seq = $item['id_id'];

                //if opening date is 01/04/2021
                if ($df == '2020-04-01') {
                    $this->db->select('item_dtl.id_id, item_dtl.opening_stock as opn_qty, item_master.item, colors.color, item_dtl.opening_rate');
                    $this->db->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left');
                    $this->db->join('colors', 'colors.c_id = item_dtl.c_id', 'left');
                    $this->db->where('item_dtl.id_id', $item_dtl_seq);
                    $row_opn = $this->db->get('item_dtl')->row();
                    if (count($row_opn) == 0) continue;

                    // $this->db->where('id_id', $row_opn->id_id);
                    // $this->db->where("str_to_date(`effective_date`, '%d-%m-%Y') <=", $dt_1419);
                    // $this->db->order_by("str_to_date(`effective_date`, '%d-%m-%Y') DESC");
                    // $row_opn_rate = $this->db->get('item_rates')->row();
                    // if (count($row_opn_rate) != 0) {
                    //     $opn_rate = $row_opn_rate->purchase_rate;
                    // } else {
                    //     $opn_rate = 0;
                    // }

            $row_pur = $this->db->select('SUM(item_quantity) as purch_qty, SUM(item_quantity * item_rate) as purch_rate')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->where('STR_TO_DATE(purchase_order_receive.purchase_order_receive_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df)) . '" and "' . date('Y-m-d', strtotime($dt)) . '"')
                ->where('purchase_order_receive_detail.id_id', $item_dtl_seq)
                ->group_by('purchase_order_receive_detail.id_id')
                ->get('purchase_order_receive_detail')->row();

                if(count($row_pur) != 0) {
                    $pur_qty = $row_pur->purch_qty;
                    $pur_rate = $row_pur->purch_rate;
                } else {
                    $pur_qty = 0;
                    $pur_rate = 0;
                }
                // echo $this->db->last_query(); die();

                $row_issue = $this->db->select('SUM(material_issue_detail.issue_quantity) as issue_qnty, SUM(material_issue_detail.issue_quantity * material_issue_detail.issue_rate) as issue_rate')
                ->join('material_issue', 'material_issue.material_issue_id = material_issue_detail.material_issue_id', 'left')
                ->where('STR_TO_DATE(material_issue.material_issue_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df)) . '" and "' . date('Y-m-d', strtotime($dt)) . '"')
                ->where('material_issue_detail.id_id', $item_dtl_seq)
                ->group_by('material_issue_detail.id_id')
                ->get('material_issue_detail')->row();

                if(count($row_issue) != 0) {
                    $issue_qty = $row_issue->issue_qnty;
                    $issue_rate = $row_issue->issue_rate;
                } else {
                    $issue_qty = 0;
                    $issue_rate = 0;
                }

                $stockin_row = $this->db->select('SUM(stock_in_detail.item_quantity) as stock_qnty, SUM(stock_in_detail.item_quantity * stock_in_detail.item_rate) as stock_rate')
                ->where('stock_in_detail.id_id', $item_dtl_seq)
                ->group_by('stock_in_detail.id_id')
                ->get('stock_in_detail')->row();

                if(count($stockin_row) != 0) {
                    $stock_in_qnty = $stockin_row->stock_qnty;
                    $stock_in_val = $stockin_row->stock_rate;
                } else {
                    $stock_in_qnty = 0;
                    $stock_in_val = 0;
                }

                    $grp_tot1 += $row_opn->opn_qty;
                    $grp_tot2 += $row_opn->opn_qty * $row_opn->opening_rate;
                    $grp_tot3 += $pur_qty;
                    $grp_tot4 += $pur_rate;
                    $grp_tot5 += $issue_qty;
                    $grp_tot6 += $issue_rate;
                    $grp_tot7 += $stock_in_qnty;
                    $grp_tot8 += $stock_in_val;
                    $grp_tot9 += $row_opn->opn_qty + $pur_qty - $issue_qty + $stock_in_qnty;
                    $grp_tot10 += $row_opn->opn_qty * $row_opn->opening_rate + $pur_rate - $issue_rate + $stock_in_val;
                }
                //if opening date is not 01/04/2021
                else {
                    $df_open = date('Y-m-d', strtotime('2020-04-01'));

                    $this->db->select('item_dtl.id_id, item_dtl.opening_stock as opn_qty, item_master.item, colors.color, item_dtl.opening_rate');
                    $this->db->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left');
                    $this->db->join('colors', 'colors.c_id = item_dtl.c_id', 'left');
                    $this->db->where('item_dtl.id_id', $item_dtl_seq);
                    $row_opn = $this->db->get('item_dtl')->row();
                    if (count($row_opn) == 0) continue;

                    // $this->db->where('id_id', $row_opn->id_id);
                    // $this->db->where("str_to_date(`effective_date`, '%d-%m-%Y') <=", $dt_1419);
                    // $this->db->order_by("str_to_date(`effective_date`, '%d-%m-%Y') DESC");
                    // $row_opn_rate = $this->db->get('item_rates')->row();
                    // if (count($row_opn_rate) != 0) {
                    //     $opn_rate = $row_opn_rate->purchase_rate;
                    // } else {
                    //     $opn_rate = 0;
                    // }

                    $row_pur = $this->db->select('SUM(item_quantity) as purch_qty, SUM(item_quantity * item_rate) as purch_rate')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->where('STR_TO_DATE(purchase_order_receive.purchase_order_receive_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df_open)) . '" and "' . date('Y-m-d', strtotime($df)) . '"')
                ->where('purchase_order_receive_detail.id_id', $item_dtl_seq)
                ->group_by('purchase_order_receive_detail.id_id')
                ->get('purchase_order_receive_detail')->row();

                if(count($row_pur) != 0) {
                    $pur_qty = $row_pur->purch_qty;
                    $pur_rate = $row_pur->purch_rate;
                } else {
                    $pur_qty = 0;
                    $pur_rate = 0;
                }

                $row_issue = $this->db->select('SUM(material_issue_detail.issue_quantity) as issue_qnty, SUM(material_issue_detail.issue_quantity * material_issue_detail.issue_rate) as issue_rate')
                ->join('material_issue', 'material_issue.material_issue_id = material_issue_detail.material_issue_id', 'left')
                ->where('STR_TO_DATE(material_issue.material_issue_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df_open)) . '" and "' . date('Y-m-d', strtotime($df)) . '"')
                ->where('material_issue_detail.id_id', $item_dtl_seq)
                ->group_by('material_issue_detail.id_id')
                ->get('material_issue_detail')->row();

                if(count($row_issue) != 0) {
                    $issue_qty = $row_issue->issue_qnty;
                    $issue_rate = $row_issue->issue_rate;
                } else {
                    $issue_qty = 0;
                    $issue_rate = 0;
                }

                $stockin_row = $this->db->select('SUM(stock_in_detail.item_quantity) as stock_qnty, SUM(stock_in_detail.item_quantity * stock_in_detail.item_rate) as stock_rate')
                ->where('stock_in_detail.id_id', $item_dtl_seq)
                ->group_by('stock_in_detail.id_id')
                ->get('stock_in_detail')->row();

                if(count($stockin_row) != 0) {
                    $stock_in_qnty = $stockin_row->stock_qnty;
                    $stock_in_val = $stockin_row->stock_rate;
                } else {
                    $stock_in_qnty = 0;
                    $stock_in_val = 0;
                }

                    $opn_qty = $row_opn->opn_qty + $pur_qty - $issue_qty + $stock_in_qnty;
                    $opn_val = $row_opn->opn_qty * $row_opn->opening_rate + $pur_rate - $issue_rate + $stock_in_val;



                    $row_pur = $this->db->select('SUM(item_quantity) as purch_qty, SUM(item_quantity * item_rate) as purch_rate')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->where('STR_TO_DATE(purchase_order_receive.purchase_order_receive_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df)) . '" and "' . date('Y-m-d', strtotime($dt)) . '"')
                ->where('purchase_order_receive_detail.id_id', $item_dtl_seq)
                ->group_by('purchase_order_receive_detail.id_id')
                ->get('purchase_order_receive_detail')->row();

                if(count($row_pur) != 0) {
                    $pur_qty = $row_pur->purch_qty;
                    $pur_rate = $row_pur->purch_rate;
                } else {
                    $pur_qty = 0;
                    $pur_rate = 0;
                }

                    $row_issue = $this->db->select('SUM(material_issue_detail.issue_quantity) as issue_qnty, SUM(material_issue_detail.issue_quantity * material_issue_detail.issue_rate) as issue_rate')
                ->join('material_issue', 'material_issue.material_issue_id = material_issue_detail.material_issue_id', 'left')
                ->where('STR_TO_DATE(material_issue.material_issue_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df)) . '" and "' . date('Y-m-d', strtotime($dt)) . '"')
                ->where('material_issue_detail.id_id', $item_dtl_seq)
                ->group_by('material_issue_detail.id_id')
                ->get('material_issue_detail')->row();

                if(count($row_issue) != 0) {
                    $issue_qty = $row_issue->issue_qnty;
                    $issue_rate = $row_issue->issue_rate;
                } else {
                    $issue_qty = 0;
                    $issue_rate = 0;
                }

                $stockin_row = $this->db->select('SUM(stock_in_detail.item_quantity) as stock_qnty, SUM(stock_in_detail.item_quantity * stock_in_detail.item_rate) as stock_rate')
                ->where('stock_in_detail.id_id', $item_dtl_seq)
                ->group_by('stock_in_detail.id_id')
                ->get('stock_in_detail')->row();

                if(count($stockin_row) != 0) {
                    $stock_in_qnty = $stockin_row->stock_qnty;
                    $stock_in_val = $stockin_row->stock_rate;
                } else {
                    $stock_in_qnty = 0;
                    $stock_in_val = 0;
                }

                    $grp_tot1 += $opn_qty;
                    $grp_tot2 += $opn_val;
                    $grp_tot3 += $pur_qty;
                    $grp_tot4 += $pur_rate;
                    $grp_tot5 += $issue_qty;
                    $grp_tot6 += $issue_rate;
                    $grp_tot7 += $stock_in_qnty;
                    $grp_tot8 += $stock_in_val;
                    $grp_tot9 += $opn_qty + $pur_qty - $issue_qty + $stock_in_qnty;
                    $grp_tot10 += $opn_val + $pur_rate - $issue_rate + $stock_in_val;
                }
            }

            $grand_tot1 += $grp_tot1;
            $grand_tot2 += $grp_tot2;
            $grand_tot3 += $grp_tot3;
            $grand_tot4 += $grp_tot4;
            $grand_tot5 += $grp_tot5;
            $grand_tot6 += $grp_tot6;
            $grand_tot7 += $grp_tot7;
            $grand_tot8 += $grp_tot8;
            $grand_tot9 += $grp_tot9;
            $grand_tot10 += $grp_tot10;
            
            $grp_tot9 = round($grp_tot9, 2);
            $grand_tot10 = round($grand_tot10, 2);
            $html .= <<<EOD
<tr>
    <td>{$group['group_name']}</td>
    <td style="text-align:right">$grp_tot1</td>
    <td style="text-align:right">$grp_tot2</td>
    <td style="text-align:right">$grp_tot3</td>
    <td style="text-align:right">$grp_tot4</td>
    <td style="text-align:right">$grp_tot5</td>
    <td style="text-align:right">$grp_tot6</td>
    <td style="text-align:right">$grp_tot7</td>
    <td style="text-align:right">$grp_tot8</td>
    <td style="text-align:right">$grp_tot9</td>
    <td style="text-align:right">$grp_tot10</td>
</tr>
EOD;
        }

        $html .= <<<EOD
<tr style="background: #d4ecea;">
    <th>Grand Total</th>
    <th style="text-align:right">$grand_tot1</th>
    <th style="text-align:right">$grand_tot2</th>
    <th style="text-align:right">$grand_tot3</th>
    <th style="text-align:right">$grand_tot4</th>
    <th style="text-align:right">$grand_tot5</th>
    <th style="text-align:right">$grand_tot6</th>
    <th style="text-align:right">$grand_tot7</th>
    <th style="text-align:right">$grand_tot8</th>
    <th style="text-align:right">$grand_tot9</th>
    <th style="text-align:right">$grand_tot10</th>
</tr>
EOD;
        //-------------------------------LOCAL REPORT END-----------------------------

        //-------------------------------IMPORT REPORT START--------------------------
        $html2 = '';
        $grand_tot1 = 0;$grand_tot2 = 0;$grand_tot3 = 0;$grand_tot4 = 0;
        $grand_tot5 = 0;$grand_tot6 = 0;$grand_tot7 = 0;$grand_tot8 = 0; $grand_tot9 = 0; $grand_tot10 = 0;

        //item group loop
        foreach ($rs_group as $group) {
            $grp_tot1 = 0;$grp_tot2 = 0;$grp_tot3 = 0;$grp_tot4 = 0;
            $grp_tot5 = 0;$grp_tot6 = 0;$grp_tot7 = 0;$grp_tot8 = 0; $grp_tot9 = 0; 
            $grp_tot10 = 0;

            //individual item+color
            $this->db->join('item_dtl', 'item_dtl.im_id = item_master.im_id', 'left');
            $this->db->join('colors', 'colors.c_id = item_dtl.c_id', 'left');
            $this->db->where('ig_id', $group['ig_id']);
            $this->db->where('type', 'Import'); //local
            $rs_item = $this->db->get('item_master')->result_array();
            if(count($rs_item) == 0) continue;

            foreach ($rs_item as $item) {
                $item_dtl_seq = $item['id_id'];

                //if opening date is 01/04/2020
                if ($df == '2020-04-01') {
                    $this->db->select('item_dtl.id_id, item_dtl.opening_stock as opn_qty, item_master.item, colors.color, item_dtl.opening_rate');
                    $this->db->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left');
                    $this->db->join('colors', 'colors.c_id = item_dtl.c_id', 'left');
                    $this->db->where('item_dtl.id_id', $item_dtl_seq);
                    $row_opn = $this->db->get('item_dtl')->row();
                    if (count($row_opn) == 0) continue;

                    // $this->db->where('id_id', $row_opn->id_id);
                    // $this->db->where("str_to_date(`effective_date`, '%d-%m-%Y') <=", $dt_1419);
                    // $this->db->order_by("str_to_date(`effective_date`, '%d-%m-%Y') DESC");
                    // $row_opn_rate = $this->db->get('item_rates')->row();
                    // if (count($row_opn_rate) != 0) {
                    //     $opn_rate = $row_opn_rate->purchase_rate;
                    // } else {
                    //     $opn_rate = 0;
                    // }

            $row_pur = $this->db->select('SUM(item_quantity) as purch_qty, SUM(item_quantity * item_rate) as purch_rate')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->where('STR_TO_DATE(purchase_order_receive.purchase_order_receive_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df)) . '" and "' . date('Y-m-d', strtotime($dt)) . '"')
                ->where('purchase_order_receive_detail.id_id', $item_dtl_seq)
                ->group_by('purchase_order_receive_detail.id_id')
                ->get('purchase_order_receive_detail')->row();

                if(count($row_pur) != 0) {
                    $pur_qty = $row_pur->purch_qty;
                    $pur_rate = $row_pur->purch_rate;
                } else {
                    $pur_qty = 0;
                    $pur_rate = 0;
                }

                $row_issue = $this->db->select('SUM(material_issue_detail.issue_quantity) as issue_qnty, SUM(material_issue_detail.issue_quantity * material_issue_detail.issue_rate) as issue_rate')
                ->join('material_issue', 'material_issue.material_issue_id = material_issue_detail.material_issue_id', 'left')
                ->where('STR_TO_DATE(material_issue.material_issue_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df)) . '" and "' . date('Y-m-d', strtotime($dt)) . '"')
                ->where('material_issue_detail.id_id', $item_dtl_seq)
                ->group_by('material_issue_detail.id_id')
                ->get('material_issue_detail')->row();

                if(count($row_issue) != 0) {
                    $issue_qty = $row_issue->issue_qnty;
                    $issue_rate = $row_issue->issue_rate;
                } else {
                    $issue_qty = 0;
                    $issue_rate = 0;
                }

                $stockin_row = $this->db->select('SUM(stock_in_detail.item_quantity) as stock_qnty, SUM(stock_in_detail.item_quantity * stock_in_detail.item_rate) as stock_rate')
                ->where('stock_in_detail.id_id', $item_dtl_seq)
                ->group_by('stock_in_detail.id_id')
                ->get('stock_in_detail')->row();

                if(count($stockin_row) != 0) {
                    $stock_in_qnty = $stockin_row->stock_qnty;
                    $stock_in_val = $stockin_row->stock_rate;
                } else {
                    $stock_in_qnty = 0;
                    $stock_in_val = 0;
                }

                    $grp_tot1 += $row_opn->opn_qty;
                    $grp_tot2 += $row_opn->opn_qty * $row_opn->opening_rate;
                    $grp_tot3 += $pur_qty;
                    $grp_tot4 += $pur_rate;
                    $grp_tot5 += $issue_qty;
                    $grp_tot6 += $issue_rate;
                    $grp_tot7 += $stock_in_qnty;
                    $grp_tot8 += $stock_in_val;
                    $grp_tot9 += $row_opn->opn_qty + $pur_qty - $issue_qty + $stock_in_qnty;
                    $grp_tot10 += $row_opn->opn_qty * $row_opn->opening_rate + $pur_rate - $issue_rate + $stock_in_val;
                }
                //if opening date is not 01/04/2020
                else {
                    $df_open = date('Y-m-d', strtotime('2020-04-01'));

                    $this->db->select('item_dtl.id_id, item_dtl.opening_stock as opn_qty, item_master.item, colors.color, item_dtl.opening_rate');
                    $this->db->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left');
                    $this->db->join('colors', 'colors.c_id = item_dtl.c_id', 'left');
                    $this->db->where('item_dtl.id_id', $item_dtl_seq);
                    $row_opn = $this->db->get('item_dtl')->row();
                    if (count($row_opn) == 0) continue;

                    // $this->db->where('id_id', $row_opn->id_id);
                    // $this->db->where("str_to_date(`effective_date`, '%d-%m-%Y') <=", $dt_1419);
                    // $this->db->order_by("str_to_date(`effective_date`, '%d-%m-%Y') DESC");
                    // $row_opn_rate = $this->db->get('item_rates')->row();
                    // if (count($row_opn_rate) != 0) {
                    //     $opn_rate = $row_opn_rate->purchase_rate;
                    // } else {
                    //     $opn_rate = 0;
                    // }

                    $row_pur = $this->db->select('SUM(item_quantity) as purch_qty, SUM(item_quantity * item_rate) as purch_rate')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->where('STR_TO_DATE(purchase_order_receive.purchase_order_receive_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df_open)) . '" and "' . date('Y-m-d', strtotime($df)) . '"')
                ->where('purchase_order_receive_detail.id_id', $item_dtl_seq)
                ->group_by('purchase_order_receive_detail.id_id')
                ->get('purchase_order_receive_detail')->row();

                if(count($row_pur) != 0) {
                    $pur_qty = $row_pur->purch_qty;
                    $pur_rate = $row_pur->purch_rate;
                } else {
                    $pur_qty = 0;
                    $pur_rate = 0;
                }

                $row_issue = $this->db->select('SUM(material_issue_detail.issue_quantity) as issue_qnty, SUM(material_issue_detail.issue_quantity * material_issue_detail.issue_rate) as issue_rate')
                ->join('material_issue', 'material_issue.material_issue_id = material_issue_detail.material_issue_id', 'left')
                ->where('STR_TO_DATE(material_issue.material_issue_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df_open)) . '" and "' . date('Y-m-d', strtotime($df)) . '"')
                ->where('material_issue_detail.id_id', $item_dtl_seq)
                ->group_by('material_issue_detail.id_id')
                ->get('material_issue_detail')->row();

                if(count($row_issue) != 0) {
                    $issue_qty = $row_issue->issue_qnty;
                    $issue_rate = $row_issue->issue_rate;
                } else {
                    $issue_qty = 0;
                    $issue_rate = 0;
                }

                $stockin_row = $this->db->select('SUM(stock_in_detail.item_quantity) as stock_qnty, SUM(stock_in_detail.item_quantity * stock_in_detail.item_rate) as stock_rate')
                ->where('stock_in_detail.id_id', $item_dtl_seq)
                ->group_by('stock_in_detail.id_id')
                ->get('stock_in_detail')->row();

                if(count($stockin_row) != 0) {
                    $stock_in_qnty = $stockin_row->stock_qnty;
                    $stock_in_val = $stockin_row->stock_rate;
                } else {
                    $stock_in_qnty = 0;
                    $stock_in_val = 0;
                }

                    $opn_qty = $row_opn->opn_qty + $pur_qty - $issue_qty + $stock_in_qnty;
                    $opn_val = $row_opn->opn_qty * $row_opn->opening_rate + $pur_rate - $issue_rate + $stock_in_val;



                    $row_pur = $this->db->select('SUM(item_quantity) as purch_qty, SUM(item_quantity * item_rate) as purch_rate')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->where('STR_TO_DATE(purchase_order_receive.purchase_order_receive_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df)) . '" and "' . date('Y-m-d', strtotime($dt)) . '"')
                ->where('purchase_order_receive_detail.id_id', $item_dtl_seq)
                ->group_by('purchase_order_receive_detail.id_id')
                ->get('purchase_order_receive_detail')->row();

                if(count($row_pur) != 0) {
                    $pur_qty = $row_pur->purch_qty;
                    $pur_rate = $row_pur->purch_rate;
                } else {
                    $pur_qty = 0;
                    $pur_rate = 0;
                }

                    $row_issue = $this->db->select('SUM(material_issue_detail.issue_quantity) as issue_qnty, SUM(material_issue_detail.issue_quantity * material_issue_detail.issue_rate) as issue_rate')
                ->join('material_issue', 'material_issue.material_issue_id = material_issue_detail.material_issue_id', 'left')
                ->where('STR_TO_DATE(material_issue.material_issue_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df)) . '" and "' . date('Y-m-d', strtotime($dt)) . '"')
                ->where('material_issue_detail.id_id', $item_dtl_seq)
                ->group_by('material_issue_detail.id_id')
                ->get('material_issue_detail')->row();

                if(count($row_issue) != 0) {
                    $issue_qty = $row_issue->issue_qnty;
                    $issue_rate = $row_issue->issue_rate;
                } else {
                    $issue_qty = 0;
                    $issue_rate = 0;
                }

                $stockin_row = $this->db->select('SUM(stock_in_detail.item_quantity) as stock_qnty, SUM(stock_in_detail.item_quantity * stock_in_detail.item_rate) as stock_rate')
                ->where('stock_in_detail.id_id', $item_dtl_seq)
                ->group_by('stock_in_detail.id_id')
                ->get('stock_in_detail')->row();

                if(count($stockin_row) != 0) {
                    $stock_in_qnty = $stockin_row->stock_qnty;
                    $stock_in_val = $stockin_row->stock_rate;
                } else {
                    $stock_in_qnty = 0;
                    $stock_in_val = 0;
                }

                    $grp_tot1 += $opn_qty;
                    $grp_tot2 += $opn_val;
                    $grp_tot3 += $pur_qty;
                    $grp_tot4 += $pur_rate;
                    $grp_tot5 += $issue_qty;
                    $grp_tot6 += $issue_rate;
                    $grp_tot7 += $stock_in_qnty;
                    $grp_tot8 += $stock_in_val;
                    $grp_tot9 += $opn_qty + $pur_qty - $issue_qty + $stock_in_qnty;
                    $grp_tot10 += $opn_val + $pur_rate - $issue_rate + $stock_in_val;
                }
            }

            $grand_tot1 += $grp_tot1;
            $grand_tot2 += $grp_tot2;
            $grand_tot3 += $grp_tot3;
            $grand_tot4 += $grp_tot4;
            $grand_tot5 += $grp_tot5;
            $grand_tot6 += $grp_tot6;
            $grand_tot7 += $grp_tot7;
            $grand_tot8 += $grp_tot8;
            $grand_tot9 += $grp_tot9;
            $grand_tot10 += $grp_tot10;
            
            $grp_tot9 = round($grp_tot9, 2);
            $grand_tot10 = round($grand_tot10, 2);
            $html2 .= <<<EOD
<tr>
    <td>{$group['group_name']}</td>
    <td style="text-align:right">$grp_tot1</td>
    <td style="text-align:right">$grp_tot2</td>
    <td style="text-align:right">$grp_tot3</td>
    <td style="text-align:right">$grp_tot4</td>
    <td style="text-align:right">$grp_tot5</td>
    <td style="text-align:right">$grp_tot6</td>
    <td style="text-align:right">$grp_tot7</td>
    <td style="text-align:right">$grp_tot8</td>
    <td style="text-align:right">$grp_tot9</td>
    <td style="text-align:right">$grp_tot10</td>
</tr>
EOD;
        }

        $html2 .= <<<EOD
<tr style="background: #d4ecea;">
    <th>Grand Total</th>
    <th style="text-align:right">$grand_tot1</th>
    <th style="text-align:right">$grand_tot2</th>
    <th style="text-align:right">$grand_tot3</th>
    <th style="text-align:right">$grand_tot4</th>
    <th style="text-align:right">$grand_tot5</th>
    <th style="text-align:right">$grand_tot6</th>
    <th style="text-align:right">$grand_tot7</th>
    <th style="text-align:right">$grand_tot8</th>
    <th style="text-align:right">$grand_tot9</th>
    <th style="text-align:right">$grand_tot10</th>
</tr>
EOD;
        //-------------------------------IMPORT REPORT END-----------------------------

        //-------------------------------NONE REPORT START--------------------------
        $html3 = '';
        $grand_tot1 = 0;$grand_tot2 = 0;$grand_tot3 = 0;$grand_tot4 = 0;
        $grand_tot5 = 0;$grand_tot6 = 0;$grand_tot7 = 0;$grand_tot8 = 0; $grand_tot9 = 0; $grand_tot10 = 0;

        //item group loop
        foreach ($rs_group as $group) {
            $grp_tot1 = 0;$grp_tot2 = 0;$grp_tot3 = 0;$grp_tot4 = 0;
            $grp_tot5 = 0;$grp_tot6 = 0;$grp_tot7 = 0;$grp_tot8 = 0; $grp_tot9 = 0; 
            $grp_tot10 = 0;

            //individual item+color
            $this->db->join('item_dtl', 'item_dtl.im_id = item_master.im_id', 'left');
            $this->db->join('colors', 'colors.c_id = item_dtl.c_id', 'left');
            $this->db->where('ig_id', $group['ig_id']);
            $this->db->where('type', 'None'); //local
            $rs_item = $this->db->get('item_master')->result_array();
            if(count($rs_item) == 0) continue;

            foreach ($rs_item as $item) {
                $item_dtl_seq = $item['id_id'];

                //if opening date is 01/04/2020
                if ($df == '2020-04-01') {
                    $this->db->select('item_dtl.id_id, item_dtl.opening_stock as opn_qty, item_master.item, colors.color, item_dtl.opening_rate');
                    $this->db->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left');
                    $this->db->join('colors', 'colors.c_id = item_dtl.c_id', 'left');
                    $this->db->where('item_dtl.id_id', $item_dtl_seq);
                    $row_opn = $this->db->get('item_dtl')->row();
                    if (count($row_opn) == 0) continue;

                    // $this->db->where('id_id', $row_opn->id_id);
                    // $this->db->where("str_to_date(`effective_date`, '%d-%m-%Y') <=", $dt_1419);
                    // $this->db->order_by("str_to_date(`effective_date`, '%d-%m-%Y') DESC");
                    // $row_opn_rate = $this->db->get('item_rates')->row();
                    // if (count($row_opn_rate) != 0) {
                    //     $opn_rate = $row_opn_rate->purchase_rate;
                    // } else {
                    //     $opn_rate = 0;
                    // }

            $row_pur = $this->db->select('SUM(item_quantity) as purch_qty, SUM(item_quantity * item_rate) as purch_rate')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->where('STR_TO_DATE(purchase_order_receive.purchase_order_receive_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df)) . '" and "' . date('Y-m-d', strtotime($dt)) . '"')
                ->where('purchase_order_receive_detail.id_id', $item_dtl_seq)
                ->group_by('purchase_order_receive_detail.id_id')
                ->get('purchase_order_receive_detail')->row();

                if(count($row_pur) != 0) {
                    $pur_qty = $row_pur->purch_qty;
                    $pur_rate = $row_pur->purch_rate;
                } else {
                    $pur_qty = 0;
                    $pur_rate = 0;
                }

                $row_issue = $this->db->select('SUM(material_issue_detail.issue_quantity) as issue_qnty, SUM(material_issue_detail.issue_quantity * material_issue_detail.issue_rate) as issue_rate')
                ->join('material_issue', 'material_issue.material_issue_id = material_issue_detail.material_issue_id', 'left')
                ->where('STR_TO_DATE(material_issue.material_issue_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df)) . '" and "' . date('Y-m-d', strtotime($dt)) . '"')
                ->where('material_issue_detail.id_id', $item_dtl_seq)
                ->group_by('material_issue_detail.id_id')
                ->get('material_issue_detail')->row();

                if(count($row_issue) != 0) {
                    $issue_qty = $row_issue->issue_qnty;
                    $issue_rate = $row_issue->issue_rate;
                } else {
                    $issue_qty = 0;
                    $issue_rate = 0;
                }

                $stockin_row = $this->db->select('SUM(stock_in_detail.item_quantity) as stock_qnty, SUM(stock_in_detail.item_quantity * stock_in_detail.item_rate) as stock_rate')
                ->where('stock_in_detail.id_id', $item_dtl_seq)
                ->group_by('stock_in_detail.id_id')
                ->get('stock_in_detail')->row();

                if(count($stockin_row) != 0) {
                    $stock_in_qnty = $stockin_row->stock_qnty;
                    $stock_in_val = $stockin_row->stock_rate;
                } else {
                    $stock_in_qnty = 0;
                    $stock_in_val = 0;
                }

                    $grp_tot1 += $row_opn->opn_qty;
                    $grp_tot2 += $row_opn->opn_qty * $row_opn->opening_rate;
                    $grp_tot3 += $pur_qty;
                    $grp_tot4 += $pur_rate;
                    $grp_tot5 += $issue_qty;
                    $grp_tot6 += $issue_rate;
                    $grp_tot7 += $stock_in_qnty;
                    $grp_tot8 += $stock_in_val;
                    $grp_tot9 += $row_opn->opn_qty + $pur_qty - $issue_qty + $stock_in_qnty;
                    $grp_tot10 += $row_opn->opn_qty * $row_opn->opening_rate + $pur_rate - $issue_rate + $stock_in_val;
                }
                //if opening date is not 01/04/2020
                else {
                    $df_open = date('Y-m-d', strtotime('2020-04-01'));

                    $this->db->select('item_dtl.id_id, item_dtl.opening_stock as opn_qty, item_master.item, colors.color, item_dtl.opening_rate');
                    $this->db->join('item_master', 'item_master.id_id = item_dtl.id_id', 'left');
                    $this->db->join('colors', 'colors.c_id = item_dtl.c_id', 'left');
                    $this->db->where('item_dtl.id_id', $item_dtl_seq);
                    $row_opn = $this->db->get('item_dtl')->row();
                    if (count($row_opn) == 0) continue;

                    // $this->db->where('id_id', $row_opn->id_id);
                    // $this->db->where("str_to_date(`effective_date`, '%d-%m-%Y') <=", $dt_1419);
                    // $this->db->order_by("str_to_date(`effective_date`, '%d-%m-%Y') DESC");
                    // $row_opn_rate = $this->db->get('item_rates')->row();
                    // if (count($row_opn_rate) != 0) {
                    //     $opn_rate = $row_opn_rate->purchase_rate;
                    // } else {
                    //     $opn_rate = 0;
                    // }

                    $row_pur = $this->db->select('SUM(item_quantity) as purch_qty, SUM(item_quantity * item_rate) as purch_rate')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->where('STR_TO_DATE(purchase_order_receive.purchase_order_receive_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df_open)) . '" and "' . date('Y-m-d', strtotime($df)) . '"')
                ->where('purchase_order_receive_detail.id_id', $item_dtl_seq)
                ->group_by('purchase_order_receive_detail.id_id')
                ->get('purchase_order_receive_detail')->row();

                if(count($row_pur) != 0) {
                    $pur_qty = $row_pur->purch_qty;
                    $pur_rate = $row_pur->purch_rate;
                } else {
                    $pur_qty = 0;
                    $pur_rate = 0;
                }

                $row_issue = $this->db->select('SUM(material_issue_detail.issue_quantity) as issue_qnty, SUM(material_issue_detail.issue_quantity * material_issue_detail.issue_rate) as issue_rate')
                ->join('material_issue', 'material_issue.material_issue_id = material_issue_detail.material_issue_id', 'left')
                ->where('STR_TO_DATE(material_issue.material_issue_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df_open)) . '" and "' . date('Y-m-d', strtotime($df)) . '"')
                ->where('material_issue_detail.id_id', $item_dtl_seq)
                ->group_by('material_issue_detail.id_id')
                ->get('material_issue_detail')->row();

                if(count($row_issue) != 0) {
                    $issue_qty = $row_issue->issue_qnty;
                    $issue_rate = $row_issue->issue_rate;
                } else {
                    $issue_qty = 0;
                    $issue_rate = 0;
                }

                $stockin_row = $this->db->select('SUM(stock_in_detail.item_quantity) as stock_qnty, SUM(stock_in_detail.item_quantity * stock_in_detail.item_rate) as stock_rate')
                ->where('stock_in_detail.id_id', $item_dtl_seq)
                ->group_by('stock_in_detail.id_id')
                ->get('stock_in_detail')->row();

                if(count($stockin_row) != 0) {
                    $stock_in_qnty = $stockin_row->stock_qnty;
                    $stock_in_val = $stockin_row->stock_rate;
                } else {
                    $stock_in_qnty = 0;
                    $stock_in_val = 0;
                }

                    $opn_qty = $row_opn->opn_qty + $pur_qty - $issue_qty + $stock_in_qnty;
                    $opn_val = $row_opn->opn_qty * $row_opn->opening_rate + $pur_rate - $issue_rate + $stock_in_val;



                    $row_pur = $this->db->select('SUM(item_quantity) as purch_qty, SUM(item_quantity * item_rate) as purch_rate')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->where('STR_TO_DATE(purchase_order_receive.purchase_order_receive_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df)) . '" and "' . date('Y-m-d', strtotime($dt)) . '"')
                ->where('purchase_order_receive_detail.id_id', $item_dtl_seq)
                ->group_by('purchase_order_receive_detail.id_id')
                ->get('purchase_order_receive_detail')->row();

                if(count($row_pur) != 0) {
                    $pur_qty = $row_pur->purch_qty;
                    $pur_rate = $row_pur->purch_rate;
                } else {
                    $pur_qty = 0;
                    $pur_rate = 0;
                }

                    $row_issue = $this->db->select('SUM(material_issue_detail.issue_quantity) as issue_qnty, SUM(material_issue_detail.issue_quantity * material_issue_detail.issue_rate) as issue_rate')
                ->join('material_issue', 'material_issue.material_issue_id = material_issue_detail.material_issue_id', 'left')
                ->where('STR_TO_DATE(material_issue.material_issue_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df)) . '" and "' . date('Y-m-d', strtotime($dt)) . '"')
                ->where('material_issue_detail.id_id', $item_dtl_seq)
                ->group_by('material_issue_detail.id_id')
                ->get('material_issue_detail')->row();

                if(count($row_issue) != 0) {
                    $issue_qty = $row_issue->issue_qnty;
                    $issue_rate = $row_issue->issue_rate;
                } else {
                    $issue_qty = 0;
                    $issue_rate = 0;
                }

                $stockin_row = $this->db->select('SUM(stock_in_detail.item_quantity) as stock_qnty, SUM(stock_in_detail.item_quantity * stock_in_detail.item_rate) as stock_rate')
                ->where('stock_in_detail.id_id', $item_dtl_seq)
                ->group_by('stock_in_detail.id_id')
                ->get('stock_in_detail')->row();

                if(count($stockin_row) != 0) {
                    $stock_in_qnty = $stockin_row->stock_qnty;
                    $stock_in_val = $stockin_row->stock_rate;
                } else {
                    $stock_in_qnty = 0;
                    $stock_in_val = 0;
                }

                    $grp_tot1 += $opn_qty;
                    $grp_tot2 += $opn_val;
                    $grp_tot3 += $pur_qty;
                    $grp_tot4 += $pur_rate;
                    $grp_tot5 += $issue_qty;
                    $grp_tot6 += $issue_rate;
                    $grp_tot7 += $stock_in_qnty;
                    $grp_tot8 += $stock_in_val;
                    $grp_tot9 += $opn_qty + $pur_qty - $issue_qty + $stock_in_qnty;
                    $grp_tot10 += $opn_val + $pur_rate - $issue_rate + $stock_in_val;
                }
            }

            $grand_tot1 += $grp_tot1;
            $grand_tot2 += $grp_tot2;
            $grand_tot3 += $grp_tot3;
            $grand_tot4 += $grp_tot4;
            $grand_tot5 += $grp_tot5;
            $grand_tot6 += $grp_tot6;
            $grand_tot7 += $grp_tot7;
            $grand_tot8 += $grp_tot8;
            $grand_tot9 += $grp_tot9;
            $grand_tot10 += $grp_tot10;
            
            $grp_tot9 = round($grp_tot9, 2);
            $grand_tot10 = round($grand_tot10, 2);
            $html3 .= <<<EOD
<tr>
    <td>{$group['group_name']}</td>
    <td style="text-align:right">$grp_tot1</td>
    <td style="text-align:right">$grp_tot2</td>
    <td style="text-align:right">$grp_tot3</td>
    <td style="text-align:right">$grp_tot4</td>
    <td style="text-align:right">$grp_tot5</td>
    <td style="text-align:right">$grp_tot6</td>
    <td style="text-align:right">$grp_tot7</td>
    <td style="text-align:right">$grp_tot8</td>
    <td style="text-align:right">$grp_tot9</td>
    <td style="text-align:right">$grp_tot10</td>
</tr>
EOD;
        }

        $html3 .= <<<EOD
<tr style="background: #d4ecea;">
    <th>Grand Total</th>
    <th style="text-align:right">$grand_tot1</th>
    <th style="text-align:right">$grand_tot2</th>
    <th style="text-align:right">$grand_tot3</th>
    <th style="text-align:right">$grand_tot4</th>
    <th style="text-align:right">$grand_tot5</th>
    <th style="text-align:right">$grand_tot6</th>
    <th style="text-align:right">$grand_tot7</th>
    <th style="text-align:right">$grand_tot8</th>
    <th style="text-align:right">$grand_tot9</th>
    <th style="text-align:right">$grand_tot10</th>
</tr>
EOD;
        //-------------------------------NONE REPORT END-----------------------------


        $array['html'] = $html;
        $array['html2'] = $html2;
        $array['html3'] = $html3;
        return $array;
    }
    
    public function fetch_jobber_bill_summary() {
        $data = '';
        if($this->input->post()) {
            $it_arr = $this->input->post('fab1[]');
            $df = $this->input->post('from');
            $dt = $this->input->post('to');
            // for ($i = 0; $i < count($it_arr); $i++) {
            $data['result'][] = $this->_fetch_jobber_bill_summary_details($it_arr, $df, $dt);
        // }
            $data['segment'] = 'jobber_bill_summary';
            // echo '<pre>',print_r($data['result']),'</pre>'; die();
            return array('page'=>'reports/common_print_v','data'=>$data);
        }
        $data['fetch_all_buyer'] = $this->db->get_where('acc_master', array('acc_type' => 'Fabricator', 'status' => 1))->result();
        return array('page'=>'reports/jobber_bill_summary_v', 'data'=>$data);
    }

    public function _fetch_jobber_bill_summary_details($code, $df, $dt) {
   
        $res = $this->db->select('jobber_bill.*, sum(jobber_bill_detail.quantity) as quantity, acc_master.name')
                 ->join('jobber_bill', 'jobber_bill.jobber_bill_id = jobber_bill_detail.jobber_bill_id', 'left')
                 ->join('acc_master', 'acc_master.am_id = jobber_bill.am_id', 'left')
                 ->where('STR_TO_DATE(jobber_bill.jobber_bill_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df)) . '" and "' . date('Y-m-d', strtotime($dt)) . '"')
                 ->where_in('jobber_bill.am_id', $code)
                 ->group_by('jobber_bill_detail.jobber_bill_id')
                 ->order_by('acc_master.name, jobber_bill.jobber_bill_date')
                 ->get_where('jobber_bill_detail', array('jobber_bill.status' => 1))
                 ->result();

        return $res;

    }
    
    public function fetch_cutter_bill_summary() {
        $data = '';
        if($this->input->post()) {
            $it_arr = $this->input->post('fab1[]');
            $df = $this->input->post('from');
            $dt = $this->input->post('to');
            // for ($i = 0; $i < count($it_arr); $i++) {
            $data['result'][] = $this->_fetch_cutter_bill_summary_details($it_arr, $df, $dt);
        // }
            $data['segment'] = 'cutter_bill_summary';
            // echo '<pre>',print_r($data['result']),'</pre>'; die();
            return array('page'=>'reports/common_print_v','data'=>$data);
        }
        $data['fetch_all_buyer'] = $this->db->get_where('acc_master', array('acc_type' => 'Cutter', 'status' => 1))->result();
        return array('page'=>'reports/cutter_bill_summary_v', 'data'=>$data);
    }

    public function _fetch_cutter_bill_summary_details($code, $df, $dt) {
   
        $res = $this->db->select('cutter_bill.*, sum(cutter_bill_dtl.original_quantity) as total_quantity, sum(cutter_bill_dtl.original_quantity * cutter_bill_dtl.parts) as total_parts, acc_master.name')
                 ->join('cutter_bill', 'cutter_bill.cb_id = cutter_bill_dtl.cb_id', 'left')
                 ->join('acc_master', 'acc_master.am_id = cutter_bill.am_id', 'left')
                 ->where('STR_TO_DATE(cutter_bill.cutter_bill_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($df)) . '" and "' . date('Y-m-d', strtotime($dt)) . '"')
                 ->where_in('cutter_bill.am_id', $code)
                 ->group_by('cutter_bill_dtl.cb_id')
                 ->order_by('acc_master.name, cutter_bill.cutter_bill_date')
                 ->get_where('cutter_bill_dtl', array('cutter_bill.status' => 1))
                 ->result();

        return $res;

    }
    
    public function fetch_monthly_production_status() {
        $data = '';
        if($this->input->post()) {
            $it_arr = implode(",", $this->input->post('fab1[]'));
            $df = $this->input->post('from');
            $dt = $this->input->post('to');
            // for ($i = 0; $i < count($it_arr); $i++) {
            $data['fetch_all_monthly_buyer_report'][] = $this->_fetch_monthly_production_status_details($it_arr, $df, $dt);
        // }
            $data['segment'] = 'monthly_production_status';
            // echo '<pre>',print_r($data['fetch_all_monthly_buyer_report']),'</pre>'; die();
            return array('page'=>'reports/common_print_v','data'=>$data);
        }
        $data['fetch_all_buyer'] = $this->db->get_where('acc_master', array('status' => 1))->result();
        return array('page'=>'reports/monthly_production_status_v', 'data'=>$data);
    }

    public function _fetch_monthly_production_status_details($code, $df, $dt) {

        $user = $this->session->user_id;

        $dept_id = $this->db->get_where('user_details', array('user_id' => $user))->result()[0]->user_dept;
   
        $res = $this->db
            ->select('acc_master.name, package_date, package_name, total_quantity, MONTHNAME(package_date) AS mname')
            ->join('packing_shipment_detail', 'packing_shipment_detail.packing_shipment_id = packing_shipment.packing_shipment_id', 'left')
            ->join('customer_order', 'packing_shipment_detail.co_id = customer_order.co_id', 'left')
            ->join('acc_master', 'acc_master.am_id = customer_order.acc_master_id', 'left')
            ->join('user_details', 'user_details.user_id = customer_order.user_id', 'left')
            // ->where_in('acc1.ACC_MASTER_CODE', $ord, false)
            ->where("acc_master.am_id IN (".$code.")",NULL, false)
            ->where('user_details.user_dept', $dept_id)
            ->order_by("str_to_date(mname,'%M')")
            // ->order_by('MNAME, ACC_MASTER_NAME, PACK_NAME')
            ->group_by('acc_master.name, package_name, mname')
            ->get('packing_shipment')
            ->result();
         // echo $this->db->last_query();  die;
        // return array_reverse($res);
        return $res;

    }
    
    public function fetch_production_register() {
        $data = '';
        if($this->input->post()) {
            $opening_quantity = $this->input->post('opening_quantity');
            $df = $this->input->post('fromdate');
            $dt = $this->input->post('todate');
            // for ($i = 0; $i < count($it_arr); $i++) {
            $data['result'] = $this->_fetch_fetch_production_register($df, $dt);
        // }
            $data['segment'] = 'fetch_production_register';
            // echo '<pre>',print_r($data['fetch_all_monthly_buyer_report']),'</pre>'; die();
            $data['closing_balance'] = $opening_quantity; 
            return array('page'=>'reports/common_print_v','data'=>$data);
        }
        $data['fetch_all_buyer'] = $this->db->get_where('acc_master', array('status' => 1))->result();
        return array('page'=>'reports/fetch_production_register_v', 'data'=>$data);
    }

    public function _fetch_fetch_production_register($df, $dt) {

        $query = "
        (SELECT
                article_master.art_no AS article_name,
                jobber_challan_receipt.jobber_receipt_challan_number AS challan_number,
                DATE_FORMAT(jobber_challan_receipt.jobber_receipt_challan_date, '%d-%m-%Y') as challan_date,
                colors.color AS article_color,
                jobber_challan_receipt_details.jobber_receive_quantity AS challan_quantity,
                MONTHNAME(jobber_challan_receipt.jobber_receipt_challan_date) AS mon,
                0 AS challan_status
                FROM
                `jobber_challan_receipt_details`
                LEFT JOIN article_master ON article_master.am_id = jobber_challan_receipt_details.am_id
                LEFT JOIN colors ON colors.c_id = jobber_challan_receipt_details.lc_id
                LEFT JOIN jobber_challan_receipt ON jobber_challan_receipt.jobber_challan_receipt_id = jobber_challan_receipt_details.jobber_challan_receipt_id
                LEFT JOIN customer_order_dtl ON customer_order_dtl.cod_id = jobber_challan_receipt_details.cod_id
                LEFT JOIN customer_order ON customer_order.co_id = customer_order_dtl.co_id
            WHERE STR_TO_DATE(jobber_challan_receipt.jobber_receipt_challan_date, '%Y-%m-%d') <= '$dt' AND STR_TO_DATE(jobber_challan_receipt.jobber_receipt_challan_date, '%Y-%m-%d') >= '$df'
            AND
                jobber_challan_receipt_details.status = 1
            ORDER BY
                jobber_challan_receipt.jobber_receipt_challan_date, jobber_challan_receipt.jobber_receipt_challan_number)
                UNION ALL(SELECT
                article_master.art_no AS article_name,
                office_invoice.office_invoice_number AS challan_number,
                DATE_FORMAT(office_invoice.office_invoice_date, '%d-%m-%Y') as challan_date,
                colors.color AS article_color,
                office_invoice_detail.quantity AS challan_quantity,
                MONTHNAME(office_invoice.office_invoice_date) AS mon,
                1 AS challan_status
                FROM
                `office_invoice_detail`
                LEFT JOIN article_master ON article_master.am_id = office_invoice_detail.am_id
                LEFT JOIN colors ON colors.c_id = office_invoice_detail.lc_id
                LEFT JOIN office_invoice ON office_invoice.office_invoice_id = office_invoice_detail.office_invoice_id
                LEFT JOIN customer_order_dtl ON customer_order_dtl.cod_id = office_invoice_detail.cod_id
                LEFT JOIN customer_order ON customer_order.co_id = customer_order_dtl.co_id
                WHERE STR_TO_DATE(office_invoice.office_invoice_date, '%Y-%m-%d') <= '$dt' AND STR_TO_DATE(office_invoice.office_invoice_date, '%Y-%m-%d') >= '$df'
                ORDER BY
                office_invoice.office_invoice_date, office_invoice.office_invoice_number)
                ORDER BY STR_TO_DATE(challan_date,'%d-%m-%Y'),challan_status 
                ";
        $res = $this->db->query($query)->result();

            // echo '<pre>', print_r($res), '</pre>'; die();

            return $res;

    }
    
    public function fetch_outstanding_report() {
        $data = '';

        if($this->input->post()) {

            $it_arr = $this->input->post('fab1[]');
            $df = $this->input->post('from');
            $dt = $this->input->post('to');
            for ($i = 0; $i < count($it_arr); $i++) {
            $data['result'][] = $this->_fetch_outstanding_report($it_arr[$i], $df, $dt);
            }
            $data['segment'] = 'outstanding_report';

            return array('page'=>'reports/common_print_v','data'=>$data);

        }
        $data['fetch_all_buyer'] = $this->db->get_where('acc_master', array('status' => 1))->result();
        return array('page'=>'reports/outstanding_report_v', 'data'=>$data);
    }

    public function _fetch_outstanding_report($code, $df, $dt) {

        $query = "SELECT
                office_proforma.proforma_number,
                office_proforma.proforma_date,
                acc_master.am_id,
                acc_master.name,
                DATE_FORMAT(customer_order.co_date, '%d-%m-%Y') as co_date,
                customer_order.co_no,
                DATE_FORMAT(customer_order.co_delivery_date, '%d-%m-%Y') as co_delivery_date,
                customer_order.co_delivery_date,
                article_master.art_no,
                article_master.alt_art_no,
                colors.color,
                office_proforma_detail.co_quantity,
                office_invoice_detail.quantity,
                office_proforma_detail.rate_foreign
                FROM
                `office_proforma`
                LEFT JOIN office_proforma_detail ON office_proforma_detail.office_proforma_id = office_proforma.office_proforma_id
                LEFT JOIN acc_master ON acc_master.am_id = office_proforma.buyer_id
                LEFT JOIN customer_order ON customer_order.co_id = office_proforma_detail.co_id
                LEFT JOIN article_master ON article_master.am_id = office_proforma_detail.am_id
                LEFT JOIN colors ON colors.c_id = office_proforma_detail.lc_id
                LEFT JOIN office_invoice_detail ON office_invoice_detail.co_id = office_proforma_detail.co_id AND office_invoice_detail.am_id = office_proforma_detail.am_id AND office_invoice_detail.lc_id = office_proforma_detail.lc_id 
            WHERE 
            office_proforma.buyer_id = $code AND
            STR_TO_DATE(office_proforma.proforma_date, '%Y-%m-%d') <= '$dt' AND STR_TO_DATE(office_proforma.proforma_date, '%Y-%m-%d') >= '$df'
            AND
                office_proforma.status = 1
            ORDER BY
                office_proforma.proforma_number, customer_order.co_no, article_master.art_no, colors.color";
        $res = $this->db->query($query)->result();

        return $res;

    }
    
    public function fetch_payroll_reports() {
        $data = '';
        if($this->input->post("adl")){
            $mon = $this->input->post('month');
            $pos = $this->input->post('position');
            $data['result'] = $this->_fetch_advance_ledger($mon,$pos);
            $data['segment'] = 'payroll_reports_advance_ledger';
            return array('page'=>'reports/common_print_v','data'=>$data);
        }
        if($this->input->post("lv")){
            $mon = $this->input->post('month');
            $pos = $this->input->post('position');
            $data['result'] = $this->_fetch_leave($mon,$pos);
            $data['segment'] = 'payroll_reports_leave';
            return array('page'=>'reports/common_print_v','data'=>$data);
        }
        if($this->input->post("esi")){
            $mon = $this->input->post('month');
            $pos = $this->input->post('position');
            $data['mont'] = $mon;
            $data['pos'] = $pos;
            $data['result'] = $this->_fetch_esi_pf($mon,$pos);
            $data['segment'] = 'payroll_esi_pf';
            return array('page'=>'reports/common_print_v','data'=>$data);
        }
        if($this->input->post("reg")){
            $mon = $this->input->post('month');
            $pos = $this->input->post('position');
            $data['mont'] = $mon;
            $data['pos'] = $pos;
            $data['result'] = $this->_fetch_register($mon,$pos);
            $data['segment'] = 'payroll_register';
            return array('page'=>'reports/common_print_v','data'=>$data);
        }
        if($this->input->post("pf")){
            $mon = $this->input->post('month');
            $pos = $this->input->post('position');
            $data['mont'] = $mon;
            $data['pos'] = $pos;
            $data['result'] = $this->_fetch_esi_pf($mon,$pos);
            $data['segment'] = 'payroll_pf';
            return array('page'=>'reports/common_print_v','data'=>$data);
        }
        return array('page'=>'reports/payroll_reports_v', 'data'=>$data);
    }

    public function _fetch_advance_ledger($mon,$pos) {

        $sql="SELECT
    f.*
        FROM
            (
                (
                    (
                    SELECT
                        e_code,
                        MONTHNAME(advance.date) AS MONNAME,
                        name,
                        amount AS ADV,
                        0 AS LN,
                        1 AS TAG
                    FROM
                        advance
                    INNER JOIN(employees)
                    ON(employees.e_id = advance.emp_id)
                    WHERE
                        employees.working_place = '".$pos."'
                )
            UNION ALL
                (
                SELECT
                    e_code,
                    MON AS MONNAME,
                    name,
                    0 AS ADV,
                    LOAN AS LN,
                    2 AS TAG
                FROM
                    salary
                INNER JOIN(employees)
                ON(employees.e_id = salary.EMPCODE)
                WHERE
                    employees.working_place = '".$pos."'
            )
                ) AS f
            )
        ORDER BY
            e_code, MONNAME,
            TAG";

        $res = $this->db->query($sql)->result();
        // echo $this->db->last_query();die;
        return $res;

    }

    public function _fetch_leave($mon,$pos) {

        $sql="SELECT salary.CODE,e_code,name,MON,salary.T4,salary.T5,salary.T6
            FROM salary
            LEFT JOIN(employees)
            ON(salary.EMPCODE=employees.e_id)
            WHERE employees.working_place='".$pos."'
            ORDER BY salary.EMPCODE,MONTH(STR_TO_DATE(MON,'%b'))";

        $res = $this->db->query($sql)->result();
        return $res;

    }

    public function _fetch_esi_pf($mon,$pos) {

        $sql="SELECT employees.name,e_code,employees.pf_acc_no,employees.esi_acc_no,salary.T2,CAST((salary.BASIC+salary.DA) AS DECIMAL(11,2)) AS TOTAL2,salary.GROSS
            FROM salary
            INNER JOIN(employees)
            ON(salary.EMPCODE=employees.e_id)
            WHERE salary.MON LIKE '".$mon."%' AND employees.working_place='".$pos."'
            ORDER BY employees.e_code";

        $res = $this->db->query($sql)->result();
        return $res;

    }

    public function _fetch_register($mon,$pos) {

        $sql="SELECT employees.name,salary.T1,salary.T2,salary.T3,(salary.T4+salary.T5+salary.T6) AS T,salary.T7,employees.basic_pay AS BASIC1,employees.da_amout AS DA1,
    CAST((employees.basic_pay+employees.da_amout) AS DECIMAL(11,2)) AS TOTAL1,salary.BASIC AS BASIC2,salary.DA AS DA2,CAST((salary.BASIC+salary.DA) AS DECIMAL(11,2)) AS TOTAL2,
    salary.HRA,salary.CONV,salary.MED,salary.OA,salary.GROSS,salary.PFAMT,salary.ESIAMT,salary.TAX,salary.INS,salary.LOAN,salary.DEDUC,salary.NET
        FROM salary
        INNER JOIN(employees)
        ON(salary.EMPCODE=employees.e_id)
        WHERE salary.MON LIKE '".$mon."%' AND employees.working_place='".$pos."'
        ORDER BY employees.e_code";

        $res = $this->db->query($sql)->result();
        // echo $this->db->last_query();die;
        return $res;

    }
    
}//end ctrl