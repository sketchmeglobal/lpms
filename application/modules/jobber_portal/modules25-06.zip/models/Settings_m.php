<?php
/**
 * Coded by: Pran Krishna Das
 * Social: www.fb.com/pran93
 * CI: 3.0.6
 * Date: 09-07-17
 * Time: 14:00
 */

class Settings_m extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function departments_permission(){
        $user_id = $this->session->user_id;
        try{

            $crud = new grocery_CRUD();
            $crud->set_theme('datatables');
            $crud->set_subject('Modulewise Departmental Permission');
            $crud->set_table('module_permission');
            $crud->order_by('module_permission_id');

            $crud->unset_add();
            $crud->unset_read();
            $crud->unset_clone();
            $crud->unset_delete();

            $crud->columns('module_name','dept_id');
            $crud->fields('module_name','dept_id');
            
            $results = $this->db->select('d_id, department')->get_where('departments',array('status' => 1))->result();

            foreach ($results as $result) {
                $module_array[$result->d_id] = $result->department;
            }


            $crud->field_type('dept_id', 'multiselect',$module_array);
            $crud->callback_field('module_name',array($this,'custom_readonly_dept'));

            $output = $crud->render();
            //rending extra value to $output
            $output->tab_title = 'Modulewise Departmental Permission';
            $output->section_heading = 'If selected then corresponding module will be filtered according to the department';
            $output->menu_name = 'Department Permission';
            $output->add_button = '';

            return array('page'=>'common_v', 'data'=>$output); //loading common view page

        } catch(Exception $e) {
            show_error($e->getMessage().'<br>'.$e->getTraceAsString());
        }
    }

    function custom_readonly_dept($value = '', $primary_key = null){
        return $value . '<input type="hidden" value="'.$value.'" name="module_name">';
    }

    public function menu_permission(){
        $user_id = $this->session->user_id;
        try{

            $crud = new grocery_CRUD();
            $crud->set_theme('datatables');
            $crud->set_subject('Menu Permission');
            $crud->set_table('menu');

            $crud->unset_add();
            $crud->unset_edit();
            $crud->unset_read();
            $crud->unset_clone();
            $crud->unset_delete();
            $crud->unset_export();
            $crud->unset_print();

            $crud->columns('module_id','menu_name');
            $crud->columns('module_id','menu_name');

            $crud->set_relation('module_id', 'module_permission', 'module_name');
            
            // $crud->add_action('Permission', '', 'admin/user-permission','fa fa-add');

            $output = $crud->render();
            //rending extra value to $output
            $output->tab_title = 'Menu Permission';
            $output->section_heading = 'Menu Wise User Permission';
            $output->menu_name = 'Menu Permission';
            $output->add_button = '';

            return array('page'=>'common_v', 'data'=>$output); //loading common view page

        } catch(Exception $e) {
            show_error($e->getMessage().'<br>'.$e->getTraceAsString());
        }
    }
    
    public function user_management(){
        $user_id = $this->session->user_id;
        try{

            $crud = new grocery_CRUD();
            $crud->set_theme('datatables');
            $crud->set_subject('User Management');
            $crud->where('usertype !=', 1);
            $crud->set_table('users');

            $crud->unset_read();
            // $crud->unset_add();
            $crud->unset_clone();
            $crud->unset_delete();
            $crud->unset_export();
            $crud->unset_print();

            $crud->columns('registration_date','username', 'email', 'verified', 'blocked');
            $crud->unset_fields('registration_date');
            $crud->add_fields('usertype','username','pass', 'email', 'verified', 'blocked');
            $crud->required_fields('username', 'pass');
            $crud->unique_fields('username');

            $crud->display_as('pass', 'Password');
            $crud->display_as('registration_date', 'Department');
            
            // # forcing registration_date to behave as user department
            $crud->field_type('pass', 'password');
            // $results = $this->db->select('d_id, department')->get_where('departments',array('status' => 1))->result();
            // // echo '<pre>', print_r($results), '</pre>';
            
            // foreach ($results as $row) {
            //     # code...
            //     $ra[$row->d_id] = $row->department;
            // }
            // $crud->field_type('department','dropdown', $ra);

            $crud->callback_field('usertype',array($this,'custom_readonly_usertype'));
            $crud->callback_column('registration_date',array($this,'_callback_user_dept'));

            $crud->callback_before_insert(array($this,'encrypt_password_callback'));
            $crud->callback_before_update(array($this,'encrypt_password_callback'));

            $crud->callback_edit_field('pass',array($this,'decrypt_password_callback'));

            $crud->add_action('Add department', '', 'admin/user-add-department','ui-icon-plus');

            $output = $crud->render();    
            
            //rending extra value to $output
            $output->tab_title = 'User Management';
            $output->section_heading = 'Edit User';
            $output->menu_name = 'User Management';
            $output->add_button = '';

            return array('page'=>'common_v', 'data'=>$output); //loading common view page

        } catch(Exception $e) {
            show_error($e->getMessage().'<br>'.$e->getTraceAsString());
        }
    }

    public function user_add_department(){
        $user_id = $this->uri->segment(3);

        $data['user_department_details'] = $this->db->select('users.username, user_details.user_dept')
        ->join('user_details', 'user_details.user_id = users.user_id', 'left')
        ->join('departments', 'departments.d_id = user_details.user_dept', 'left')
        ->get_where('users', array('users.user_id' => $user_id))->row();

        $data['department_details'] = $this->db->get_where('departments', array('status => 1'))->result();

        if($this->input->post()) {
            $insert_array = array(
                'user_id' => $user_id,
                'user_dept' => $this->input->post('department_add')
            );

        $num_rows = $this->db->get_where('user_details', array('user_id' => $user_id))->num_rows();
        
        if($num_rows == 0) {
            $this->db->insert('user_details', $insert_array);
            if($this->db->insert_id() != '') {
                $this->session->set_flashdata('msg', 'Department has been added successfully.');
                redirect(base_url('admin/user-management'));
            }
        } else {
           $this->db->update('user_details', $insert_array, array('user_id' => $user_id));
           $this->session->set_flashdata('msg', 'Department has been updated successfully.');
           redirect(base_url('admin/user-management')); 
        }
        }

        return array('page'=>'department_v', 'data'=>$data);

    }

    function custom_readonly_usertype($value = '', $primary_key = null){
       return '<b><em>Normal User</em></b>' . '<input type="hidden" value="2" name="usertype">'; 
        }

    function encrypt_password_callback($post_array, $primary_key = null){
        // unset($post_array['department']);
        $post_array['pass'] = hash('sha256', $post_array['pass']);
        return $post_array;
    }

    function decrypt_password_callback($value){
        return "<input type='password' name='pass' value='' placeholder='Enter new password' />";
    }

    public function _callback_user_dept($value, $row){
        $uid = $row->user_id;
        $num_rows = $this->db->get_where('user_details', array('user_id' => $uid))->num_rows();
        if($num_rows > 0) {
        $dept = $this->db->select('department')
            ->join('departments', 'user_details.user_dept = departments.d_id', 'left')
            ->get_where('user_details', array('user_details.user_id' => $uid))->result()[0]->department;
        } else {
          $dept = '';  
        }
        
        return $dept;
    }

    public function user_permission(){
        $user_id = $this->session->user_id;
        try{

            $crud = new grocery_CRUD();
            $crud->set_theme('datatables');
            $crud->set_subject('User Permission');
            // $crud->where('user_permission.user_id !=', 1);
            $crud->set_table('user_permission');

            // $crud->unset_add();
            // $crud->unset_edit();
            $crud->unset_read();
            $crud->unset_clone();
            // $crud->unset_delete();
            $crud->unset_export();
            $crud->unset_print();

            $results = $this->db->select('user_id, username')->get_where('users',array('verified' => 1, 'blocked' => 0, 'usertype' => 2))->result();

            $crud->columns('user_id', 'm_id', 'block_permission','view_permission');
            $crud->fields('user_id', 'm_id', 'block_permission','view_permission');
            $crud->required_fields('m_id', 'user_id');

            $crud->set_relation('m_id', 'menu', 'menu_name');
            $crud->set_relation('user_id', 'users', 'username');
            
            $crud->display_as('m_id', 'menu');
            $crud->display_as('user_id', 'username');
            $crud->display_as('view_permission', 'Add/View detailed list');

            if($this->input->post('user_permission')){
                $uid = $this->input->post('username');
                $output = $this->db->get_where('user_permission',array('status' => 1))->result();
            }else{
                $output = $crud->render();    
            }

            
            //rending extra value to $output
            $output->tab_title = 'User Permission';
            $output->section_heading = 'Menu Wise User Permission';
            $output->menu_name = 'User Permission';
            $output->add_button = '';
            $output->active_users = $results;

            return array('page'=>'common_v', 'data'=>$output); //loading common view page

        } catch(Exception $e) {
            show_error($e->getMessage().'<br>'.$e->getTraceAsString());
        }
    }
        

} // /