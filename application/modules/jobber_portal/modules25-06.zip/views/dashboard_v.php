<?php
/**
 * Coded by: Pran Krishna Das
 * Social: www.fb.com/pran93
 * CI: 3.0.6
 * Date: 09-07-17
 * Time: 12:00
 */
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard | <?=WEBSITE_NAME;?></title>
    <meta name="keyword" content="user dashboard">
    <meta name="description" content="account statistic">

<!--      common head 
 -->    <?php $this->load->view('components/_common_head'); ?>
 <link href="<?=base_url();?>assets/admin_panel/css/select2.css" rel="stylesheet">
    <link href="<?=base_url();?>assets/admin_panel/css/select2-bootstrap.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/admin_panel/css/multi-select.css" media="screen" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdn.datatables.net/rowgroup/1.0.4/css/rowGroup.dataTables.min.css" />
<!--      /common head 
 -->
 </head>

<body class="sticky-header">

<section>
<!--      sidebar left start (Menu)
 -->    <?php $this->load->view('components/left_sidebar'); //left side menu ?>
<!--      sidebar left end (Menu)
 -->    <style>
        .p-1{padding: 1%;}
        .pt-0{padding-top: 0}
        .px-1{padding: 1rem 0;}
        .mb-1{margin-bottom: 0.5rem;}
        .mt-1{margin-top: 0.5rem;}
        .mb-2{margin-bottom: 2rem;}
        .panel{min-height: 400px;}
        .panel-footer {background-color: rgb(0 0 0 / 15%);position: absolute;bottom: 0;width: 100%;}
        .text-white{color:#fff;}
        .text-dark{color:#000;}
        .border-bottom{border-bottom: 1px solid #787878;}
        ul {
         padding-right: 0;
         padding-left: 18px;
        }
        .panel {
        min-height: 360px;
        }
        footer {
            position: relative;
        }
    </style>
<!--      body content start
 -->    <div class="body-content" style="min-height: 1500px;">

<!--          header section start
 -->        <?php $this->load->view('components/top_menu'); ?>
<!--          header section end
 -->
<!--          page head start
 -->        <div class="page-head">
            <h3>Dashboard</h3>
            <span class="sub-title">Welcome to <?=WEBSITE_NAME;?> dashboard</span>
        </div>
<!--          page head end
 -->
<!--         body wrapper start
 -->        <div class="wrapper">
     <div class="row">
            <?php if($lastest_costings != '') { ?>
            <div class="col-md-6 col-lg-3">
                <div class="panel">
                    <?php // print_r($lastest_costings) ?>
                    <div class="panel-header bg-success text-white text-center p-1"><h4>Costing</h4>
                    </div>
                    <div class="panel-body pt-0">
                        <p class="text-muted border-bottom px-1">Last 5 transactions</p>
                        <ul>
                            <?php
                            foreach($lastest_costings as $lc){
                                ?>
                                <li class="mb-1"><a href="<?=base_url();?>admin/edit_article_costing/<?= $lc->ac_id ?>" class=""><?= $lc->art_no ?></a> (<?= date('d/m/Y H:i:s', strtotime($lc->modify_date)) ?>)
                            <?php if($lc->show_name == 1) { ?>
                                 by <?= $lc->username ?>
                            <?php } ?>
                             </li>
                                <?php
                            }
                            ?>
                            
                        </ul>
                    </div>
                    <div class="panel-footer text-center">
                        <a href="<?= base_url('admin/article_costing') ?>" class="text-dark">Segment List</a>
                    </div>
                </div>
            </div>
            <?php } ?>
            <?php 
            if($lastest_orders != '') { ?>
            <div class="col-md-6 col-lg-3">
                <div class="panel">
                    <?php // print_r($lastest_costings) ?>
                    <div class="panel-header bg-success text-white text-center p-1"><h4>Customer Order</h4></div>
                    <div class="panel-body pt-0">
                        <p class="text-muted border-bottom px-1">Last 5 transactions</p>
                        <ul>
                            <?php
                            foreach($lastest_orders as $lo){
                                ?>
                                <li class="mb-1"><a href="<?=base_url();?>admin/edit-customer-order/<?= $lo->co_id ?>" class=""><?= $lo->co_no ?></a> (<?= date('d/m/Y H:i:s', strtotime($lo->modify_date)) ?>)
                                <?php if($lo->show_name == 1) { ?>
                                 by <?= $lo->username ?>
                            <?php } ?>
                            </li>
                                <?php
                            }
                            ?>
                            
                        </ul>
                    </div>
                    <div class="panel-footer text-center">
                       <a href="<?= base_url('admin/customer-order') ?>" class="text-dark">Segment List</a>
                    </div>
                </div>
           </div>
       <?php } ?>
       <?php if($lastest_cutting_issues!= '') { ?>
            <div class="col-md-6 col-lg-3">
                <div class="panel">
                    <?php //print_r($lastest_costings) ?>
                    <div class="panel-header bg-success text-white text-center p-1"><h4>Cutting Issue</h4></div>
                    <div class="panel-body pt-0">
                        <p class="text-muted border-bottom px-1">Last 5 transactions</p>
                        <ul>
                            <?php
                            foreach($lastest_cutting_issues as $lci){
                                ?>
                                <li class="mb-1"><a href="<?=base_url();?>admin/edit-cutting-issue-challan/<?= $lci->cut_id ?>" class=""><?= $lci->co_no ?></a> (<?= date('d/m/Y H:i:s', strtotime($lci->modify_date)) ?>)
                                <?php if($lci->show_name == 1) { ?>
                                 by <?= $lci->username ?>
                            <?php } ?>
                            </li>
                                <?php
                            }
                            ?>
                            
                        </ul>
                    </div>
                    <div class="panel-footer text-center">
                        <a href="<?= base_url('admin/cutting-issue-challan') ?>" class="text-dark">Segment List</a>
                    </div>
                </div>
            </div>
        <?php } ?>
        <?php if($lastest_cutting_receive != '') { ?>
            <div class="col-md-6 col-lg-3">
                <div class="panel">
                    <?php //print_r($lastest_costings) ?>
                    <div class="panel-header bg-success text-white text-center p-1"><h4>Cutting Receive</h4></div>
                    <div class="panel-body pt-0">
                        <p class="text-muted border-bottom px-1">Last 5 transactions</p>
                        <ul>
                            <?php
                            foreach($lastest_cutting_receive as $lcr){
                                ?>
                                <li class="mb-1"><a href="<?=base_url();?>admin/edit-cutting-receive/<?= $lcr->cut_rcv_id ?>" class=""><?= $lcr->co_no ?></a> (<?= date('d/m/Y H:i:s', strtotime($lcr->modify_date)) ?>)
                                <?php if($lcr->show_name == 1) { ?>
                                 by <?= $lcr->username ?>
                            <?php } ?>
                            </li>
                                <?php
                            }
                            ?>
                            
                        </ul>
                    </div>
                    <div class="panel-footer text-center">
                        <a href="<?= base_url('admin/cutting-receive') ?>" class="text-dark">Segment List</a>
                    </div>
                </div>
            </div>
        <?php } ?>
        </div>
        <div class="row">
        <?php if($lastest_skiving_receive != '') { ?>
            <div class="col-md-6 col-lg-3">
                <div class="panel">
                    <?php //print_r($lastest_costings) ?>
                    <div class="panel-header bg-success text-white text-center p-1"><h4>Skiving Receive</h4></div>
                    <div class="panel-body pt-0">
                        <p class="text-muted border-bottom px-1">Last 5 transactions</p>
                        <ul>
                            <?php
                            foreach($lastest_skiving_receive as $lsr){
                                ?>
                                <li class="mb-1"><a href="<?=base_url();?>admin/skiving-receive-edit/<?= $lsr->skiving_receive_id ?>" class=""><?= $lsr->skiving_receive_challan_number ?></a> (<?= date('d/m/Y H:i:s', strtotime($lsr->modified_date)) ?>)
                            <?php if($lsr->show_name == 1) { ?>
                                 by <?= $lsr->username ?>
                            <?php } ?>
                            </li>
                                <?php
                            }
                            ?>
                            
                        </ul>
                    </div>
                    <div class="panel-footer text-center">
                        <a href="<?= base_url('admin/skiving-receive') ?>" class="text-dark">Segment List</a>
                    </div>
                </div>
            </div>
        <?php } ?>
        <?php if($lastest_jobber_issues != '') { ?>
            <div class="col-md-6 col-lg-3">
                <div class="panel">
                    <?php //print_r($lastest_costings) ?>
                    <div class="panel-header bg-success text-white text-center p-1"><h4>Jobber Issue</h4></div>
                    <div class="panel-body pt-0">
                        <p class="text-muted border-bottom px-1">Last 5 transactions</p>
                        <ul>
                            <?php
                            foreach($lastest_jobber_issues as $ljr){
                                ?>
                                <li class="mb-1"><a href="<?=base_url();?>admin/jobber-challan-issue-edit/<?= $ljr->jobber_issue_id ?>" class=""><?= $ljr->jobber_challan_number ?></a> (<?= date('d/m/Y H:i:s', strtotime($ljr->modified_date)) ?>)
                            <?php if($ljr->show_name == 1) { ?>
                                 by <?= $ljr->username ?>
                            <?php } ?>
                            </li>
                                <?php
                            }
                            ?>
                            
                        </ul>
                    </div>
                    <div class="panel-footer text-center">
                        <a href="<?= base_url('admin/jobber-challan-issue') ?>" class="text-dark">Segment List</a>
                    </div>
                </div>
            </div>
        <?php } ?>
        <?php if($lastest_jobber_issues != '') { ?>
            <div class="col-md-6 col-lg-3">
                <div class="panel">
                    <?php //print_r($lastest_costings) ?>
                    <div class="panel-header bg-success text-white text-center p-1"><h4>Jobber Receive</h4></div>
                    <div class="panel-body pt-0">
                        <p class="text-muted border-bottom px-1">Last 5 transactions</p>
                        <ul>
                            <?php
                            foreach($lastest_jobber_receive as $ljrc){
                                ?>
                                <li class="mb-1"><a href="<?=base_url();?>admin/jobber-challan-receipt-edit/<?= $ljrc->jobber_challan_receipt_id ?>" class=""><?= $ljrc->jobber_receipt_challan_number ?></a> (<?= date('d/m/Y H:i:s', strtotime($ljrc->modify_date)) ?>)
                            <?php if($ljrc->show_name == 1) { ?>
                                 by <?= $ljrc->username ?>
                            <?php } ?>
                            </li>
                                <?php
                            }
                            ?>
                            
                        </ul>
                    </div>
                    <div class="panel-footer text-center">
                        <a href="<?= base_url('admin/jobber-challan-receipt') ?>" class="text-dark">Segment List</a>
                    </div>
                </div>
            </div>
        <?php } ?>
        <?php if($lastest_shipment != '') { ?>
            <div class="col-md-6 col-lg-3">
                <div class="panel">
                    <?php //print_r($lastest_costings) ?>
                    <div class="panel-header bg-success text-white text-center p-1"><h4>Packing List/Shipment List</h4></div>
                    <div class="panel-body pt-0">
                        <p class="text-muted border-bottom px-1">Last 5 transactions</p>
                        <ul>
                            <?php
                            foreach($lastest_shipment as $ls){
                                ?>
                                <li class="mb-1"><a href="<?=base_url();?>admin/edit-packing-shipment/<?= $ls->packing_shipment_id ?>" class=""><?= $ls->package_name ?></a> (<?= date('d/m/Y H:i:s', strtotime($ls->modify_date)) ?>)
                            <?php if($ls->show_name == 1) { ?>
                                 by <?= $ls->username ?>
                            <?php } ?>
                            </li>
                                <?php
                            }
                            ?>
                            
                        </ul>
                    </div>
                    <div class="panel-footer text-center">
                        <a href="<?= base_url('admin/packing-shipment-list') ?>" class="text-dark">Segment List</a>
                    </div>
                </div>
            </div>
        <?php } ?>
        </div>
        <div class="col-md-12 col-lg-5">
                <div class="panel" style="min-height: 200px;">
                    <?php //print_r($lastest_costings) ?>
                    <div class="panel-header bg-success text-white text-center p-1"><h4>Order Status Report</h4></div>
                    <div class="panel-body pt-0">
                        <br/>
                        <form id="form_customer_order" method="post" action="<?= base_url('admin/report-order-status-details') ?>" class="cmxform form-horizontal tasi-form" novalidate="novalidate" target="_blank">
                                <div class="form-group">
                                    <div class="row">
                                    <label class="control-label col-lg-5 text-danger">Select Customer Order*</label>
                                    <div class="col-lg-6">
                                        <select id="customer_order" multiple="" name="customer_order[]" class="form-control select2">
                                            <option value="">Select Customer Order</option>
                                            <?php foreach ($co_ids as $co_id) {
                                                ?>
                                                <option value="<?= $co_id->co_id ?>"><?= $co_id->co_no ?></option>
                                                <?php
                                            } ?>
                                         </select>
                                    </div>
                                    </div>
                                    
                                    <div class="row">
                                    <div class="col-lg-3 mt-1"></div>
                                    <div class="col-lg-9 mt-1">
                                        <button name="submit" value="order_details" class="btn btn-success" type="submit"><i class="fa fa-search"> Order Details</i></button>
                                        <!--<button name="submit" id="consumption_btn" value="consumption_details" class="btn btn-success" type="submit"><i class="fa fa-search"> Consumption Details</i></button>-->
                                        <button name="submit" value="order_summary" class="btn btn-success" type="submit"><i class="fa fa-search"> Order Summary</i></button>
                                    </div>
                                    </div>
                                </div>
                            </form>
                    </div>
                </div>
            </div>
            <div class="col-md-12 col-lg-7">
                    <?php //print_r($lastest_costings) ?>
                    <div class="panel-header bg-success text-white text-center p-1"><h4>Leather Status Report</h4></div>
                    <div class="panel-body pt-0">
                        <br/>
                        <form method="post" action="<?= base_url('admin/report-leather-status') ?>" class="cmxform form-horizontal tasi-form" novalidate="novalidate" target="_blank">
                                <div class="col-sm-3">
                    <label>Select Group </label><br />
                    <select id="group" name="group" class="form-control" required >
                            <option value="1" selected>Leather</option>
                    </select>
                </div>
                <div class="col-sm-4">
                    <label>Select Item From The List</label><br />
                    <a id="select-all" href="#">Select All</a>
                 /
                <a id="deselect-all" href="#">Deselect All</a>
                <select id="leather_status" name="leather[]" multiple="multiple" style="width: 100%">
                    </select>
                </div>
                <input type="submit" name="print" value="Print(P.O. wise)" class="btn btn-sm btn-success" />
                <input type="submit" name="print" value="Print" class="btn btn-sm btn-success" />
            </form>
                    </div>
                </div>
            </div>
        </div>
<!--         body wrapper end
 -->
<!--         footer section start
 -->        <?php $this->load->view('components/footer'); ?>
<!--         footer section end
 -->
    </div>
<!--      body content end
 --></section>

<!--  Placed js at the end of the document so the pages load faster 
 --><script src="<?=base_url()?>assets/admin_panel/js/jquery-1.10.2.min.js"></script>
<script src="<?//=base_url();?>assets/admin_panel/js/jquery-migrate.js"></script>
<script src="<?=base_url();?>assets/admin_panel/js/select2.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/rowgroup/1.0.4/js/dataTables.rowGroup.min.js"></script>
<script src="<?=base_url()?>assets/admin_panel/js/jquery.multi-select.js" type="text/javascript"></script>
<script type="text/javascript" src="<?=base_url()?>assets/admin_panel/js/jquery.quicksearch.js"></script>

<!--  common js 
 --><?php $this->load->view('components/_common_js'); //left side menu ?>

 <script>
    $('.select2').select2();
</script>

<script>
  $(document).ready(function(){
                   $gr_id = ($(this).find(':selected').val());
                   
                   $.ajax({
                       method: 'post',
                       dataType: 'json',
                       url: "<?= base_url('items-on-item-group') ?>",
                       data: {gr_id:$gr_id},
                       success: function(items){
                           // console.log(items);
                           $.each(items, function(index, itemData){
                               $apnd_val = '<option value="'+ itemData.id_id +'">'+ itemData.item + ' [' + itemData.color + ']' +'</option>';
                               $("#leather_status").append($apnd_val);
                           });
                           $('#leather_status').multiSelect('refresh');
                       },
                       error: function(e){
                           console.log(e);
                       }
                   });
                   });
</script>

<script>
           $(document).ready(function(){
              $(function () {
            $(".date").datepicker({dateFormat: 'dd-mm-yy'});
        });
        $('#leather_status').multiSelect({
            selectableHeader: "<input type='text' class='search-input' autocomplete='off' placeholder='Search item'>",
            selectionHeader: "<input type='text' class='search-input' autocomplete='off' placeholder='Search item'>",
            afterInit: function(ms){
                var that = this,
                    $selectableSearch = that.$selectableUl.prev(),
                    $selectionSearch = that.$selectionUl.prev(),
                    selectableSearchString = '#'+that.$container.attr('id')+' .ms-elem-selectable:not(.ms-selected)',
                    selectionSearchString = '#'+that.$container.attr('id')+' .ms-elem-selection.ms-selected';

                that.qs1 = $selectableSearch.quicksearch(selectableSearchString)
                    .on('keydown', function(e){
                        if (e.which === 40){
                            that.$selectableUl.focus();
                            return false;
                        }
                    });

                that.qs2 = $selectionSearch.quicksearch(selectionSearchString)
                    .on('keydown', function(e){
                        if (e.which == 40){
                            that.$selectionUl.focus();
                            return false;
                        }
                    });
            },
            afterSelect: function(){
                this.qs1.cache();
                this.qs2.cache();
            },
            afterDeselect: function(){
                this.qs1.cache();
                this.qs2.cache();
            }
        });  
           });
           $('#select-all').click(function(){
               $('#leather_status').multiSelect('select_all');
               return false;
           });
           $('#deselect-all').click(function(){
               $('#leather_status').multiSelect('deselect_all');
               return false;
           });
       </script>

</body>
</html>