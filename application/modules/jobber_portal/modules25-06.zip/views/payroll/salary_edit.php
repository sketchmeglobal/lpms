<?php
/**
 * Coded by: Pran Krishna Das
 * Social: www.fb.com/pran93
 * CI: 3.0.6
 * Date: 21-02-2020
 * Time: 11:30 am
 * Last updated on 25-Feb-2021 at 11:30 am
 */
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Salary Edit | <?=WEBSITE_NAME;?></title>
    <meta name="description" content="Order Status">

    <!--Data Table-->
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/admin_panel/js/DataTables/DataTables-1.10.18/css/dataTables.bootstrap.min.css"/>
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/admin_panel/js/DataTables/Buttons-1.5.6/css/buttons.bootstrap.min.css"/>
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/admin_panel/js/DataTables/Responsive-2.2.2/css/responsive.bootstrap.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
    <!-- common head -->
    <?php $this->load->view('components/_common_head'); ?>
    <!-- /common head -->
    <!--Select2-->
    <link href="<?=base_url();?>assets/admin_panel/css/select2.css" rel="stylesheet">
    <link href="<?=base_url();?>assets/admin_panel/css/select2-bootstrap.css" rel="stylesheet">
<style>
    .jobber_type {
    border: 1px solid #cac8c8;
    padding: 6px;
    }
    input[type="submit"] {
        margin-top: 26px;
    }
    .hidden {
        display: none;
    }
</style>
</head>

<body class="sticky-header">

<section>
    <!-- sidebar left start (Menu)-->
    <?php $this->load->view('components/left_sidebar'); //left side menu ?>
    <!-- sidebar left end (Menu)-->

    <!-- body content start-->
    <div class="body-content" style="min-height: 1500px;">

        <!-- header section start-->
        <?php $this->load->view('components/top_menu'); ?>
        <!-- header section end-->

        <!-- page head start-->
        <div class="page-head">
            <h3 class="m-b-less">Salary Edit</h3>
            <div class="state-information">
                <ol class="breadcrumb m-b-less bg-less">
                    <li><a href="<?=base_url('admin/dashboard');?>">Transaction</a></li>
                    <li class="active">Salary Edit</li>
                </ol>
            </div>
        </div>
        <!-- page head end-->

        <!--body wrapper start-->
        <div class="wrapper">

            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <div class="panel-body">
                            <div class="row">
                <form method="post" class="container" id="insert_form">
               <div class="col-sm-11">
                   <div class="col-sm-8" style="border: 1px solid #000; border-radius: 2%;height:275px">
                       <div class="row">
                           <div class="col-sm-4">
                               <label>Month/Year</label>
                               <?php
                               echo $fetch_all_sal_details[0]->MON;
                               ?>
                               <select name="month" class="form-control">
                                   <?php
                                   for ($mon = 1; $mon <= 12; $mon++) {
                                   ?>
                                    <option <?= ($fetch_all_sal_details[0]->MON == date('F', mktime(0, 0, 0, $mon, 1)) .'~'. cal_days_in_month(CAL_GREGORIAN,$mon,date('Y'))  .'~'. $mon) ? 'selected' : 'disabled' ?>><?= date('F', mktime(0, 0, 0, $mon, 1)) .'~'. cal_days_in_month(CAL_GREGORIAN,$mon,date('Y'))  .'~'. $mon ?></option>
                                   <?php
                                   }
                                   ?>
                               </select>
                           </div>
                           <div class="col-sm-8">
                               <label>Select Employee</label>
                               <select class="form-control" name="emp_id" id="emp_select"  style="width: 100%">
                                   <option>Select from the list</option>
                                   <?php
                                   foreach($fetch_all_employee as $emps){
                                       ?>
                                       <option <?= ($fetch_all_sal_details[0]->EMPCODE == $emps->e_id) ? 'selected' : 'disabled' ?> value="<?= $emps->e_id ?>"><?= $emps->name . ' ['. $emps->e_code .']' ?></option>
                                       <?php
                                   }
                                   ?>
                               </select>
                           </div>
                           </div>
                           <div class="row">
                               <div class="col-sm-8">
                                   <div class="row">
                                        <div class="col-sm-6">
                                           <label>Department:</label>
                                           <span class="dept"><?= $fetch_all_sal_details[0]->working_place ?></span>
                                       </div>
                                       <div class="col-sm-6">
                                           <label>Date of Birth:</label>
                                           <span class="dob"><?= $fetch_all_sal_details[0]->dob ?></span>
                                       </div>
                                       
                                       <div class="col-sm-6">
                                           <label>Date of Joining:</label>
                                           <span class="doj"><?= $fetch_all_sal_details[0]->doj ?></span>
                                       </div>
                                       <div class="col-sm-6">
                                            <label>ESI Applicable?:</label>
                                           <span class="esiapp">
                                           <?php 
                                  if($fetch_all_sal_details[0]->esi = 1) {
                                    echo 'Yes';
                                  } else {
                                    echo 'No';
                                  }
                                            ?>
                                           </span>
                                       </div>
                                       <div class="col-sm-6">
                                            <label>PF Applicable?:</label>
                                           <span class="pfapp">
                                             <?php 
                                  if($fetch_all_sal_details[0]->PF_APPLICABLE = 1) {
                                    echo 'Yes';
                                  } else {
                                    echo 'No';
                                  }
                                            ?>
                                           </span>
                                       </div>
                                       
                                       <div class="col-sm-6">
                                            <label>Actual Basic:</label>
                                           <span class="acbsc"><?= $fetch_all_sal_details[0]->basic_pay ?></span>
                                       </div>
                                       <div class="col-sm-6">
                                            <label>Actual D.A.:</label>
                                           <span class="acda"><?= $fetch_all_sal_details[0]->da_amout ?></span>
                                       </div>
                                       <div class="col-sm-6">
                                            <label>Actual HRA:</label>
                                           <span class="achra"><?= $fetch_all_sal_details[0]->hra_amount ?></span>
                                       </div>
                                       <div class="col-sm-6">
                                            <label>Conveyance:</label>
                                           <span class="convey"><?= $fetch_all_sal_details[0]->convenience ?></span>
                                       </div>
                                       <!--<div class="col-sm-6">-->
                                       <!--     <label>CL Taken (so far):</label>-->
                                       <!--    <span class="cl_taken"></span>-->
                                       <!--</div>-->
                                       <!--<div class="col-sm-6">-->
                                       <!--     <label>EL Taken (so far):</label>-->
                                       <!--    <span class="el_taken"></span>-->
                                       <!--</div>-->
                                       
                                   </div>
                               </div>
                               <div class="col-sm-4">
                                   <?php
                                        $gender = $fetch_all_sal_details[0]->gender;
                                        if($gender == "Male" && $fetch_all_sal_details[0]->picture == ''){
                                            $emp_img = "assets/admin_panel/img/employee_img/nopic.png";    
                                        }else if($gender == "Female" && $fetch_all_sal_details[0]->picture == ''){
                                            $emp_img = "assets/admin_panel/img/employee_img/nopicf.png";    
                                        }else{
                                            $emp_img = "assets/admin_panel/img/employee_img/" . $fetch_all_sal_details[0]->picture;
                                        }
                                   ?>
                                   <img style="height:100px;border:1px solid tomato" src="<?= base_url() . $emp_img ?>" class="img-responsive emp_img" src="" alt="" />
                               </div>
                          
                       </div>
                   </div>
                   <div class="col-sm-4" style="border: 1px solid #000; border-radius: 2%;">
                       <div class="col-sm-8"><label>Working Days</label></div>
                       <div class="col-sm-4"><input value="<?= $fetch_all_sal_details[0]->T1 ?>" step="0.01" min="0" type="number" id="wd" name="wd" class="form-control" /></div>
                       
                        <div class="col-sm-8"><label>Actual Days Worked</label></div>
                       <div class="col-sm-4"><input value="<?= $fetch_all_sal_details[0]->T2 ?>" step="0.01" min="0" type="number" id="adw" name="adw" class="form-control" /></div>
                       
                        <div class="col-sm-8"><label>Holidays</label></div>
                       <div class="col-sm-4"><input value="<?= $fetch_all_sal_details[0]->T3 ?>" step="0.01" min="0" type="number" id="hol" name="hol" class="form-control" /></div>
                       
                        <div class="col-sm-8"><label>Casual Leave</label></div>
                       <div class="col-sm-4"><input value="<?= $fetch_all_sal_details[0]->T4 ?>" step="0.01" min="0" type="number" id="cl" name="cl" class="form-control" /></div>
                       
                        <div class="col-sm-8"><label>Earn Leave</label></div>
                       <div class="col-sm-4"><input value="<?= $fetch_all_sal_details[0]->T5 ?>" step="0.01" min="0" type="number" id="el" name="el" class="form-control" /></div>
                       
                        <div class="col-sm-8"><label>E.S.I Leave</label></div>
                       <div class="col-sm-4"><input value="<?= $fetch_all_sal_details[0]->T6 ?>" step="0.01" min="0" type="number" id="esil" name="esil" class="form-control" /></div>
                       
                       <div class="col-sm-8"><label>Absent</label></div>
                       <div class="col-sm-4"><input value="<?= $fetch_all_sal_details[0]->T7 ?>" step="0.01" min="0" type="number" id="abs" name="abs" class="form-control" /></div>
                       
                        <div class="col-sm-8"><label>Total Days</label></div>
                       <div class="col-sm-4"><input value="<?= $fetch_all_sal_details[0]->T8 ?>" step="0.01" min="0" type="number" id="td" name="td" class="form-control" /></div>
                   </div>
               </div>
               
               <div class="row"><div class="clearfix"></div></div>
               
               <div class="col-sm-11">
                   <div class="col-sm-6" style="border: 1px solid #000; border-radius: 2%;">
                       <h5>Income</h5>
                       
                       <div class="col-sm-8"><label>Actual Basic</label></div>
                       <div class="col-sm-4"><input value="<?= $fetch_all_sal_details[0]->BASIC ?>" step="0.01" min="0" type="number" id="abasic" name="abasic" class="form-control" /></div>
                       
                       <div class="col-sm-8"><label>Actual D.A.</label></div>
                       <div class="col-sm-4"><input value="<?= $fetch_all_sal_details[0]->DA ?>" step="0.01" min="0" type="number" id="ada" name="ada" class="form-control" /></div>
                       
                       <div class="col-sm-8"><label>Actual HRA</label></div>
                       <div class="col-sm-4"><input value="<?= $fetch_all_sal_details[0]->HRA ?>" step="0.01" min="0" type="number" id="ahra" name="ahra" class="form-control" /></div>
                       
                       <div class="col-sm-8"><label>Conveyance</label></div>
                       <div class="col-sm-4"><input value="<?= $fetch_all_sal_details[0]->CONV ?>" step="0.01" min="0" type="number" id="con" name="con" class="form-control" /></div>
                       
                       <div class="col-sm-8"><label>Medical Allowance</label></div>
                       <div class="col-sm-4"><input value="<?= $fetch_all_sal_details[0]->MED ?>" step="0.01" min="0" type="number" id="ma" name="ma" class="form-control" /></div>
                       
                       <div class="col-sm-8"><label>Other Allowance</label></div>
                       <div class="col-sm-4"><input value="<?= $fetch_all_sal_details[0]->OA ?>" step="0.01" min="0" type="number" id="oa" name="oa" class="form-control" /></div>
                       
                       <div class="col-sm-8"><label>Other Hour</label></div>
                       <div class="col-sm-4"><input value="<?= $fetch_all_sal_details[0]->OT ?>" step="0.01" min="0" type="number" id="oh" name="oh" class="form-control" /></div>
                       
                       <div class="col-sm-8"><label>Other Amount</label></div>
                       <div class="col-sm-4"><input  value="<?= $fetch_all_sal_details[0]->OTAMT ?>" step="0.01" min="0" type="number" id="oam" name="oam" class="form-control" /></div>
                       
                       
                   </div>
                   <div class="col-sm-6" style="border: 1px solid #000; border-radius: 2%;">
                        <h5>Deductions and Final</h5>
                        
                       
                        <div class="col-sm-6"><label>P.F. % & Amount</label></div>
                        <div class="col-sm-6">
                            <input type="number" name="pfper" value="<?= $fetch_all_sal_details[0]->PFPER ?>" step="0.01" min="0" id="pfper" style="width:35%;float:left" class="form-controls" />
                            <input type="number" name="pfamnt" value="<?= $fetch_all_sal_details[0]->PFAMT ?>" step="0.01" min="0" id="pfamnt" style="width:65%;float:right" class="form-controls" />
                        </div>
                        <div class="row"></div>
                        <div class="col-sm-6"><label>E.S.I. % & Amount</label></div>
                        <div class="col-sm-6">
                            <input type="number" name="esiper"  value="<?= $fetch_all_sal_details[0]->ESIPER ?>" step="0.01" min="0" id="esiper" style="width:35%;float:left" class="form-controls" />
                            <input type="number" name="esiamnt"  value="<?= $fetch_all_sal_details[0]->ESIAMT ?>" step="0.01" min="0" id="esiamnt" style="width:65%;float:right" class="form-controls" />
                        </div>
                        <div class="row"></div>
                        
                       <div class="col-sm-8"><label>Professional Tax</label></div>
                       <div class="col-sm-4"><input type="number"  value="<?= $fetch_all_sal_details[0]->TAX ?>" step="0.01" min="0" id="ptax" name="ptax" class="form-control" /></div>
                       
                       <div class="col-sm-8"><label>Insurance</label></div>
                       <div class="col-sm-4"><input type="number"  value="<?= $fetch_all_sal_details[0]->INS ?>" step="0.01" min="0" id="insur" name="insur" class="form-control" /></div>
                       
                       <div class="col-sm-8 hiddenX"><label>Loan/Advance Taken</label></div>
                       <div class="col-sm-4 hiddenX">
                           <input type="number" readonly="" name="loan_taken" value="0" step="0.01" min="0" id="loan_taken" class="form-control" />
                        </div>
                       
                       <div class="col-sm-8"><label>Loan/Advance Adjusted So Far</label></div>
                       <div class="col-sm-4">
                           <input type="number" readonly="" name="loan_adj_till" value="0" step="0.01" min="0" id="loan_adj_till" class="form-control" />
                        </div>
                        
                       <div class="col-sm-8 hiddenX"><label>Loan/Advance Monthly Installment</label></div>
                       <div class="col-sm-4 hiddenX">
                           <input type="number" readonly="" value="0" step="0.01" min="0" id="loan_mon_adj" name="loan_mon_adj" class="form-control" />
                        </div>
                        
                        <div class="col-sm-8"><label>Loan/Advance Adjusted (This month)</label></div>
                        <div class="col-sm-4">
                           <input type="number" readonly="" name="loan_adj" value="<?= $fetch_all_sal_details[0]->LOAN ?>" step="0.01" min="0" id="loan_adj" class="form-control" />
                        </div>
                        
                       <hr />
                       
                   </div>
               </div>
               
               
               <div class="row"><div class="clearfix"><br /></div></div>
               <div class="row"><div class="clearfix"><br /></div></div>
               
               <div class="">
                    <div class="col-sm-11" style="border: 1px solid #000; border-radius: 2%;">
                       <div class="col-sm-2"><label>Gross Salary</label></div>
                       <div class="col-sm-2"><input type="number"value="<?= $fetch_all_sal_details[0]->GROSS ?>" step="0.01" min="0" id="gross" name="gross" class="form-control" /></div>
                       
                       <div class="col-sm-2"><label>Total Deductions</label></div>
                       <div class="col-sm-2"><input type="number" value="<?= $fetch_all_sal_details[0]->DEDUC ?>" step="0.01" min="0" id="ded" name="ded" class="form-control" /></div>
                       
                       <div class="col-sm-2"><label>Net Salary</label></div>
                       <div class="col-sm-2"><input type="number" value="<?= $fetch_all_sal_details[0]->NET ?>" step="0.01" min="0" name="net" id="net" class="form-control" /></div>
                    </div>
               </div>
                
               
               <div class="row"><br /></div><div class="row"><br /></div>
               <input type="submit"  class="final_sub btn btn-sm btn-success" value="Update" name="save" />
               <input type="submit"  class="final_sub btn btn-sm btn-success" value="Update & Go Back To List" name="savengo" />
               
               
           </form>    
            </div>
                        </div>
                    </section>
                </div>
            </div>

        </div>
        <!--body wrapper end-->

        <!--footer section start-->
        <?php $this->load->view('components/footer'); ?>
        <!--footer section end-->

    </div>
    <!-- body content end-->
</section>

<!-- Placed js at the end of the document so the pages load faster -->
<script src="<?=base_url()?>assets/admin_panel/js/jquery-1.10.2.min.js"></script>

<!-- common js -->
<?php $this->load->view('components/_common_js'); //left side menu ?>

<!--Data Table-->
<script type="text/javascript" src="<?=base_url()?>assets/admin_panel/js/DataTables/JSZip-2.5.0/jszip.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/admin_panel/js/DataTables/pdfmake-0.1.36/pdfmake.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/admin_panel/js/DataTables/pdfmake-0.1.36/vfs_fonts.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/admin_panel/js/DataTables/DataTables-1.10.18/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/admin_panel/js/DataTables/DataTables-1.10.18/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/admin_panel/js/DataTables/Buttons-1.5.6/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/admin_panel/js/DataTables/Buttons-1.5.6/js/buttons.bootstrap.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/admin_panel/js/DataTables/Buttons-1.5.6/js/buttons.colVis.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/admin_panel/js/DataTables/Buttons-1.5.6/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/admin_panel/js/DataTables/Buttons-1.5.6/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/admin_panel/js/DataTables/Buttons-1.5.6/js/buttons.print.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/admin_panel/js/DataTables/Responsive-2.2.2/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/admin_panel/js/DataTables/Responsive-2.2.2/js/responsive.bootstrap.min.js"></script>
<!--data table init-->
<script src="<?=base_url()?>assets/admin_panel/js/data-table-init.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
<!--Select2-->
<script src="<?=base_url();?>assets/admin_panel/js/select2.js" type="text/javascript"></script>

<script>
    $('#cut_rcpt_challan').select2();   
</script>

<script>
    document.getElementById("myDate1").defaultValue = "2020-04-01"; 
    // document.getElementById("myDate2").defaultValue = date('y-m-d');  
</script>

<script>
                $("#emp_select").change(function(){
                    $emp_id = $(this).val();
                    var emp_img = '';
                    
                    $.ajax({
                        
                        url: "<?= base_url('payroll-emp-search-on-id') ?>",
                        method: 'post',
                        dataType: 'json',
                        data:{id: $emp_id},
                        success: function(emp_details){
                            // console.log(emp_details);
                            $gender = emp_details[0].gender;
                            
                            if($gender == "Male" && emp_details[0].picture == ''){
                                emp_img = "<?= base_url() ?>assets/uploads/employee_pictures/nopic.png";    
                            }else if($gender == "Female" && emp_details[0].picture == ''){
                                emp_img = "<?= base_url() ?>assets/uploads/employee_pictures/nopicf.png";    
                            }else{
                                emp_img = "<?= base_url() ?>assets/uploads/employee_pictures/" + emp_details[0].picture;
                            }
                            
                            
                            // alert(emp_details[0].NAME);
                            $('.dept').text(emp_details[0].name);
                            $('.dob').text(emp_details[0].dob);
                            $('.doj').text(emp_details[0].doj);
                            $('.esiapp').text(emp_details[0].esi);
                            $('.pfapp').text(emp_details[0].pf);
                            $('.emp_img').attr('src', emp_img);
                            
                            $('.acbsc').text(Math.round(emp_details[0].basic_pay));
                            $('.acda').text(Math.round(emp_details[0].da_amout));
                            $('.achra').text(Math.round(emp_details[0].hra_amount));
                            $('.convey').text(Math.round(emp_details[0].convenience));
                            
                            $('.dept').text(emp_details[0].name);
                            
                            $('#abasic').val(Math.round(emp_details[0].basic_pay));
                            $('#ada').val(Math.round(emp_details[0].da_amout));
                            $('#ahra').val(Math.round(emp_details[0].hra_amount));
                            $('#con').val(Math.round(emp_details[0].convenience));
                            
                            $('#ma').val(emp_details[0].medical_allowance);
                            $('#oa').val(emp_details[0].special_allowance);
                            
                            $('#oh').val('0');
                            $('#oam').val('0');
                            
                            $('#pfper').val(emp_details[0].pf_percentage);
                            $('#pfamnt').val('0');
                            
                            $('#esiper').val(emp_details[0].esi_percentage);
                            $('#esiamnt').val('0');
                            
                            
                        },
                        error: function(e){
                            console.log(e);
                        }
                        
                    });
                    
                    $.ajax({
                        
                        url: "<?= base_url('payroll-emp-leave-on-id') ?>",
                        method: 'post',
                        dataType: 'json',
                        data:{id: $emp_id},
                        success: function(emp_leave_details){
                            console.log(emp_leave_details);
                            if(emp_leave_details.length == 0){
                                $('.cl_taken').text('0');   
                                $('.el_taken').text('0');   
                            }else{
                                if(emp_leave_details[0].all_cl == '' || emp_leave_details[0].all_cl == null){
                                    $('.cl_taken').text('0');    
                                }else{
                                    $('.cl_taken').text(emp_leave_details[0].all_cl);    
                                }
                                
                                if(emp_leave_details[0].all_el == '' || emp_leave_details[0].all_el == null){
                                    $('.el_taken').text('0');    
                                }else{
                                    $('.el_taken').text(emp_leave_details[0].all_el);    
                                }    
                            }
                        },
                        error: function(e){
                            console.log(e);
                        }
                        
                    });
                    
                     $.ajax({
                        
                        url: "<?= base_url('payroll-emp-advance-on-id') ?>",
                        method: 'post',
                        dataType: 'json',
                        data:{id: $emp_id},
                        success: function(emp_advance_taken){
                            console.log(emp_advance_taken);
                            if(emp_advance_taken.length == 0){
                                $('#loan_taken').val('0'); 
                                $('#loan_mon_adj').val('0'); 
                            }else{
                                $('#loan_taken').val(emp_advance_taken[0].AMT);    
                                $('#loan_mon_adj').val(emp_advance_taken[0].MONTHLY_ADVANCE_ADJUSTMENT); 
                            }
                        },
                        error: function(e){
                            console.log(e);
                        }
                        
                    });
                    
                     $.ajax({
                        
                        url: "<?= base_url('payroll-emp-advance-paid-on-id') ?>",
                        method: 'post',
                        dataType: 'json',
                        data:{id: $emp_id},
                        success: function(emp_advance_paid){
                            console.log(emp_advance_paid);
                            if(emp_advance_paid.length == 0){
                                $('#loan_adj_till').val(0);    
                                $paid = 0;
                            }else{
                                $('#loan_adj_till').val(emp_advance_paid[0].loan_paid);    
                                $paid = emp_advance_paid[0].loan_paid;
                            }
                            
                             
                        },
                        error: function(e){
                            console.log(e);
                        }
                        
                    });
                    
                   $(document).ajaxStop(function () {
                      // 0 === $.active
                      // adjustment calc
                    
                            $loan_taken = $("#loan_taken").val();
                            $loan_adj_till = $("#loan_adj_till").val();
                            
                            // alert($loan_taken + '...' + $loan_adj_till);
        
                            if(+$loan_taken == +$loan_adj_till){
                                $("#loan_adj").val('0');
                                $("#loan_mon_adj").val('0');
                                $("#loan_taken").val('0');
                                $("#loan_adj_till").val('0');
                            }else{
                                $loan_pending = parseFloat($loan_taken) - parseFloat($loan_adj_till);
                                $instl_amnt = parseFloat($("#loan_mon_adj").val());
                
                                // alert($loan_pending + '...' + $instl_amnt);
                                    
                                if($loan_pending > $instl_amnt){
                                    $("#loan_adj").val($instl_amnt);
                                }else if($loan_pending < $instl_amnt){
                                    $("#loan_adj").val($loan_pending);
                                }else{
                                    $("#loan_adj").val('0');
                                }
                            }
                            
                  });
                    
                });
            </script>

            <script>
                $(document).ready(function(){
                    var mday = $("#month").find(":selected").text().split('~')[1];
                    $("#wd").val(mday);
                    $("#month").change(function(){
                        mday = $("#month").find(":selected").text().split('~')[1];
                        $("#wd").val(mday);
                        
                        var d = new Date();
                        var year = parseInt(d.getFullYear());
                        var month = parseInt($("#month").find(":selected").text().split('~')[2]) - 1;
                        var day = 1;
                        // alert(year + 'vv' + month);
                        var c= 0;
                        var date = new Date(year, month, day);
                        while(date.getMonth() === month) {
                            if(date.getDay() === 6) {
                                c++;
                            }
                            day++;
                            date = new Date(year, month, day);
                        }
                        // alert(c);
                        $("#hol").val(c);
                        
                    });
                   
                //   days calculation
                
                $("#adw, #hol, #cl, #el, #esil, #abs, #esiper, #pfper, #abasic, #ada, #ahra, #con, #ma, #oa, #oh, #oam, #ptax, #insur, #adad, #loan_adj").blur(function(){
                    $val = parseInt($("#adw").val()) + parseInt($("#hol").val()) + parseInt($("#cl").val()) + parseInt($("#el").val()) + parseInt($("#esil").val()) + parseInt($("#abs").val());
                    $("#td").val($val);
                    
                    // CL area -- fetch already taken cl for the current session
                    
                    var cl = $("#cl").val();
                    var cl_taken = $(".cl_taken").text();
                    var tot_cl = parseInt(cl) + parseInt(cl_taken);
                    var cl_pending = (3 - parseInt(cl_taken));
                    
                    if(tot_cl > 3){     // 3 is static here should come from db
                        alert("Casual Leave exceeds Maximum Alloted. CL Pending " + cl_pending);
                        $("#cl").val('0');
                        return false;
                    }
                    
                    // EL area -- fetch already taken el for the current session
                    
                    var el = $("#cl").val();
                    var el_taken = $(".cl_taken").text();
                    var tot_el = parseInt(el) + parseInt(el_taken);
                    var el_pending = (16 - parseInt(el_taken));
                    
                    if(tot_el > 16){     // 16 is static here should come from db
                        alert("Earned Leave exceeds Maximum Alloted. EL Pending " + el_pending);
                        $("#el").val('0');
                        return false;
                    }
                    
                    // ESI CALCULATION and D.A. Calculation
                    if($("#esil").val() > 0){
                        var esi_leave_day = parseInt($('#esil').val());
                        var abasic = parseFloat($('.acbsc').text()) - ((parseFloat($('.acbsc').text()) / 30) * esi_leave_day);
                        var ada = parseFloat($('.acda').text()) - ((parseFloat($('.acda').text()) / 30) * esi_leave_day);
                        
                        $("#abasic").val(Math.round(abasic));
                        $("#ada").val(Math.round(ada));
                    }
                    
                    // HRA calc
                    
                    var ahra = (parseFloat($("#abasic").val()) + parseFloat($("#ada").val())) * 0.15; // 15% is static here should come from db
                    $("#ahra").val(Math.round(ahra));
                    
                    // PF ded. calc
                    
                    var pfamnt = (parseFloat($("#abasic").val()) + parseFloat($("#ada").val()) + + parseFloat($("#con").val())) * (parseFloat($("#pfper").val())/100); 
                    $("#pfamnt").val(Math.round(pfamnt));
                    
                    // ESI ded calc
                    
                    var esiamnt = (parseFloat($("#abasic").val()) + parseFloat($("#ada").val()) + + parseFloat($("#con").val()) + + parseFloat($("#ahra").val())) * (parseFloat($("#esiper").val())/100); 
                    $("#esiamnt").val(Math.round(esiamnt));
                    
                    // gross salary and ded and net
                    var gross = +$("#abasic").val() + +$("#ada").val() + +$("#ahra").val() + +$("#con").val();
                    var ded = +$("#pfamnt").val() + +$("#esiamnt").val() + +$("#ptax").val() + +$("#insur").val() + +$("#loan_adj").val();
                    var net = +gross - +ded;
                    
                    // alert(gross);
                    
                    $("#gross").val(Math.round(gross));
                    $("#ded").val(Math.round(ded));
                    $("#net").val(Math.round(net));
                    
                    
                });
                   
               $("#ded").on('blur', function(){
                //   alert();
                    $g = $("#gross").val();
                    $d = $("#ded").val();
                    $res = +$g - +$d;
                    $("#net").val(Math.round($res));
               });
                    
                });
            </script>
            <script>
        $(document).on('keyup keypress', 'input[type="text"]', function(e) {
          if(e.which == 13) {
          e.preventDefault();
          return false;
          }
        });
        $(document).on('keyup keypress', 'input[type="number"]', function(e) {
          if(e.which == 13) {
          e.preventDefault();
          return false;
          }
        });
      </script>

</body>
</html>