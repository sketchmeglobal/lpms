<?php
/**
 * Coded by: Pran Krishna Das
 * Social: www.fb.com/pran93
 * CI: 3.0.6
 * Date: 21-02-2020
 * Time: 11:30 am
 * Last updated on 16-Apr-2021 at 09:02 pm
 */
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<?php if($segment == 'leather_status') { ?>
		<?php if($segment1 == 'leather_status') { ?>
	<title>LEATHER STATUS</title>
	<?php } else { ?>
	<title>ITEM STATUS</title> 
	<?php } ?>
	<?php } else if($segment == 'leather_status_po') { ?>
		<?php if($segment1 == 'leather_status') { ?>
	<title>LEATHER STATUS</title>
	<?php } else { ?>
	<title>ITEM STATUS</title> 
	<?php } ?>
    <?php } else if($segment == 'checking_stock_summary_status') { ?>
    <title>STOCK SUMMARY STATUS</title>
    <?php } else if($segment == 'checking_stock_detail_ledger') { ?>
    <title>STOCK DETAIL LEDGER</title>
	<?php } else { ?>
    <title>ORDER STATUS</title>
	<?php } ?>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- Normalize or reset CSS with your favorite library -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/7.0.0/normalize.min.css">
	<!-- Load paper.css for happy printing -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/paper-css/0.4.1/paper.css">
	<link href="https://fonts.googleapis.com/css?family=Chivo|Signika" rel="stylesheet">
	<!-- Set page size here: A5, A4 or A3 -->
	<!-- Set also "landscape" if you need -->
	<style>
		body{
		                font-family: 'Signika', sans-serif;
		                /*font-size: 12.5px;*/
		                font-family: Calibri;
		            }
		            p {
		                margin: 0 0 5px;
		            }
		            .padding-5mm{padding: 5mm;}
		            table{ border: 1px solid #777; }
		            .table{
		                margin-bottom: 3px;
		            }
		            .head_font{
		                font-family: 'Signika', sans-serif;
		                font-family: Calibri;
		            }
		            .container{width: 100%}
		            .border_all{
		                border: 1px solid #000;
		            }
		            .border_bottom{
		                border-bottom: 1px solid #000;
		            }
		            .mar_0{
		                margin: 0
		            }
		            .mar_bot_3{
		                margin-bottom: 3px
		            }
		
		            .header_left, .header_right{
		                height: 75px
		            }
		
		            .width-100{width: 100%}
		
		            .height_60{ height: 60px }
		            .height_42{ height: 42px }
		            .height_135{height: 150px}
		            .height_90{height: 90px}
		            .height_100{height: 100px}
		            .height_110{height: 110px}
		            .height_41{ height: 41px }
		            .height_23{ height: 23px }
		            .height_63{ height: 63px }
		            .height_21{ height: 21px }
		
		            .table-bordered, .table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>td, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>thead>tr>th { border: 1px solid #000!important;  text-align: center;}
		            .table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {padding: 5px; text-align: left; font-size: 13px}
		
		            .border-bottom{border-bottom:  1px solid #000}.text-center{text-align: center!important;}.text-right{text-align: right!important;}
		        
		            @page { size: A4 }
		
		            @media print{
		                .table-bordered, .table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>td, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>thead>tr>th { border: 1px solid black!important;}
		                .table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {padding: 5px; text-align: left; font-size: 13px}
		                .col-sm-6{ width: 50%!important;float:left; }.col-sm-5 { width: 41.66666667%;float:left; }.col-sm-7 { width: 58.33333333%;float:left; }
		                .text-center{text-align: center!important;}.text-right{text-align: right!important;}
		            }
		table.order-summary td {position: relative;}		            
		table.order-summary span{left: 0;background: #d4ecea;position: absolute;bottom: 0;width: 100%;text-align: right;border-top: 1px solid;color: #000;font-size: 10px;}
	</style>
</head>
<!-- Set "A5", "A4" or "A3" for class name -->
<!-- Set also "landscape" if you need -->

<body>
	<div class="A4" id="page-content">
	<?php 
		
		// print_r($temp_co_name_array);die;
	?>

	<?php if($segment == 'order_details'){
		// echo '<pre>',print_r($result),'</pre>';
		$temp_co_name_array = array();
		foreach($result as $co_name) {
			if(!in_array($co_name->co_no, $temp_co_name_array)){
				array_push($temp_co_name_array, $co_name->co_no);
			}
		}
		?>
		<section class="sheet padding-5mm" style="height: auto">
			<div>
				<!--<header class="pull-right">-->
				<!--    <small>Page No. </small>-->
				<!--</header>-->
				<div class="clearfix"></div>
				<div class="container">
					<div class="row border_all text-center text-uppercase mar_bot_3">
						<h3 class="mar_0 head_font">Order Status Details</h3>
					</div>
					<div class="row mar_bot_3">
						<div class="col-sm-6 border_all header_left">
							<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
							<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
						</div>
						<div class="col-sm-6 border_all header_right">Customer Order Number :
							<br />
							<?= implode(', ', $temp_co_name_array) ?>
						</div>
					</div>
					<!--table data-->
					<div class="row">
						<div class="container">
							<div class="row">
								<div class="table-responsive">
									<!--<h5>Retrieve Table</h5>-->
									<table id="all_det" class="table table-bordered">
										<thead>
											<tr>
												<th rowspan="2">Order No.</th>
												<th rowspan="2">Article</th>
												<th rowspan="2">Ord Qnty</th>
												<th colspan="3" class="text-center">Cutting Information</th>
												<th colspan="3" class="text-center">Skiving Information</th>
												<th colspan="3" class="text-center">Fabricator Information</th>
												<th colspan="3" class="text-center">Shipping Information</th>
											</tr>
											<tr>
												<th>Cut Issue</th>
												<th>Cut Rcv.</th>
												<th>Cut Bal.</th>
												<th>Skiv Issue</th>
												<th>Skiv Rcv.</th>
												<th>Skiv Bal.</th>
												<th>Fab Issue</th>
												<th>Fab Rcv.</th>
												<th>Fab Bal.</th>
												<th>Qnt. Shpd</th>
												<th>Qnt. Rem</th>
												<th>Qnt. Stock-in-hand</th>
											</tr>
										</thead>
										<tbody>
											<?php
											$co_array[] = '';
											// echo $array_size = count($result);
											$order_sum = 0;
											$order_iter = 1;
											$ord_qnty_sum = 0;
											$grand_total_co_qnty = array();
											$grand_total1_co_qnty = array();
											$grand_total_cut_issue = array();
											$grand_total1_cut_issue = array();
											$grand_total_cut_rcv = array();
											$grand_total1_cut_rcv = array();
											$grand_total_cut_balc = array();
											$grand_total1_cut_balc = array();
											$cut_balc = 0;
											$grand_total_skv_isu = array();
											$grand_total1_skv_isu = array();
											$grand_total_skv_rcv = array();
											$grand_total1_skv_rcv = array();
											$skv_balc = 0;
											$grand_total_skv_balc = array();
											$grand_total1_skv_balc = array();
											$grand_total_fab_isu = array();
											$grand_total1_fab_isu = array();
											$grand_total_fab_rcv = array();
											$grand_total1_fab_rcv = array();
											$fab_balc = 0;
											$grand_total_fab_balc = array();
											$grand_total1_fab_balc = array();
											$grand_total_qnty_shpd = array();
											$grand_total1_qnty_shpd = array();
										    $qnty_remn= 0;
											$grand_total_qnty_remn = array();
											$grand_total1_qnty_remn = array();
											$qnty_stck= 0;
											$grand_total_qnty_stck = array();
											$grand_total1_qnty_stck = array();
											 foreach ($result as $res) {
												if(!in_array($res->co_no,$co_array)){
													array_push($co_array, $res->co_no);
													if($order_iter++ == 1){
														// continue;
													}else{
														
														?>
														<tr style="background-color: #d9e2ea;">
															<th colspan="2">Total</th>
															<th class="text-right"><?=array_sum($grand_total1_co_qnty)?></th>
															<th class="text-right"><?=array_sum($grand_total1_cut_issue)?></th>
															<th class="text-right"><?=array_sum($grand_total1_cut_rcv)?></th>
															<th class="text-right"><?=array_sum($grand_total1_cut_balc)?></th>
															<th class="text-right"><?=array_sum($grand_total1_skv_isu)?></th>
															<th class="text-right"><?=array_sum($grand_total1_skv_rcv)?></th>
															<th class="text-right"><?=array_sum($grand_total1_skv_balc)?></th>
															<th class="text-right"><?=array_sum($grand_total1_fab_isu)?></th>
															<th class="text-right"><?=array_sum($grand_total1_fab_rcv)?></th>
															<th class="text-right"><?=array_sum($grand_total1_fab_balc)?></th>
															<th class="text-right"><?=array_sum($grand_total1_qnty_shpd)?></th>
															<th class="text-right"><?=array_sum($grand_total1_qnty_remn)?></th>
															<th class="text-right"><?=array_sum($grand_total1_qnty_stck)?></th>
														</tr>
														<?php
														$grand_total1_co_qnty = array();
														$grand_total1_cut_issue = array();
														$grand_total1_cut_rcv = array();
														$grand_total1_cut_balc = array();
														$grand_total1_skv_isu = array();
														$grand_total1_skv_rcv = array();
														$grand_total1_skv_balc = array();
														$grand_total1_fab_isu = array();
														$grand_total1_fab_rcv = array();
														$grand_total1_fab_balc = array();
														$grand_total1_qnty_shpd = array();
														$grand_total1_qnty_remn = array();
														$grand_total1_qnty_stck = array();
													}
												}

												?>
												<tr>
													<th nowrap style="font-size: 12px"><?= $res->co_no ?></th>
													<td nowrap style="font-size: 12px"><?= $res->art_no .' ['.$res->color.']' ?></td>
													<td class="text-right">
														<?php 
														$ord_qnty_sum += $res->co_quantity;
														echo $res->co_quantity; 
														array_push($grand_total_co_qnty, $res->co_quantity);
														array_push($grand_total1_co_qnty, $res->co_quantity);
														?>
													</td>
													<td class="text-right">
														<?php 
														echo $res->cutting_issued_qnty; 
														array_push($grand_total_cut_issue, $res->cutting_issued_qnty);
														array_push($grand_total1_cut_issue, $res->cutting_issued_qnty);
														?>
													</td>
													<td class="text-right">
													<?php 
														echo $res->cutting_received_qnty; 
														array_push($grand_total_cut_rcv, $res->cutting_received_qnty);
														array_push($grand_total1_cut_rcv, $res->cutting_received_qnty);
														?>
													</td>
													<td class="text-right">
														<?php 
														$cut_balc = $res->cutting_issued_qnty - $res->cutting_received_qnty;
														echo $cut_balc; 
														array_push($grand_total_cut_balc, $cut_balc);
														array_push($grand_total1_cut_balc, $cut_balc);
														?>
													</td>

													<td class="text-right">
														<?php 
														echo $res->cutting_received_qnty; 
														array_push($grand_total_skv_isu, $res->cutting_received_qnty);
														array_push($grand_total1_skv_isu, $res->cutting_received_qnty);
														?>
													</td>
													<td class="text-right">
														<?php 
														echo $res->skiving_receive_qnty; 
														array_push($grand_total_skv_rcv, $res->skiving_receive_qnty);
														array_push($grand_total1_skv_rcv, $res->skiving_receive_qnty);
														?>
													</td>
													<td class="text-right">
														<?php 
														$skv_balc = $res->cutting_received_qnty - $res->skiving_receive_qnty;
														echo $skv_balc; 
														array_push($grand_total_skv_balc, $skv_balc);
														array_push($grand_total1_skv_balc, $skv_balc);
														?>
													</td>

													<td class="text-right">
														<?php 
														echo $res->jobber_issue_qnty; 
														array_push($grand_total_fab_isu, $res->jobber_issue_qnty);
														array_push($grand_total1_fab_isu, $res->jobber_issue_qnty);
														?>
													</td>
													<td class="text-right">
														<?php 
														echo $res->jobber_receive_qnty; 
														array_push($grand_total_fab_rcv, $res->jobber_receive_qnty);
														array_push($grand_total1_fab_rcv, $res->jobber_receive_qnty);
														?>
													</td>
													<td class="text-right">
														<?php 
														$fab_balc = $res->jobber_issue_qnty - $res->jobber_receive_qnty;
														echo $fab_balc; 
														array_push($grand_total_fab_balc, $fab_balc);
														array_push($grand_total1_fab_balc, $fab_balc);
														?>
													</td>

													<td class="text-right">
														<?php 
														echo $res->packing_shipment_quantity; 
														array_push($grand_total_qnty_shpd, $res->packing_shipment_quantity);
														array_push($grand_total1_qnty_shpd, $res->packing_shipment_quantity);
														?>
													</td>
													<td class="text-right">
														<?php 
												        $qnty_remn= $res->co_quantity - $res->packing_shipment_quantity;
														echo $qnty_remn; 
														array_push($grand_total_qnty_remn, $qnty_remn);
														array_push($grand_total1_qnty_remn, $qnty_remn);
														?>
													</td>
													<td class="text-right">
														<?php 
												        $qnty_stck= $res->jobber_receive_qnty - $res->packing_shipment_quantity;
														echo $qnty_stck; 
														array_push($grand_total_qnty_stck, $qnty_stck);
														array_push($grand_total1_qnty_stck, $qnty_stck);
														?>
													</td>
												</tr>
												<?php
											} 
											if(end($result)){
													?>
													<tr style="background-color: #d9e2ea;">
														<th colspan="2">Total</th>
														<th class="text-right"><?=array_sum($grand_total1_co_qnty)?></th>
														<th class="text-right"><?=array_sum($grand_total1_cut_issue)?></th>
														<th class="text-right"><?=array_sum($grand_total1_cut_rcv)?></th>
														<th class="text-right"><?=array_sum($grand_total1_cut_balc)?></th>
														<th class="text-right"><?=array_sum($grand_total1_skv_isu)?></th>
														<th class="text-right"><?=array_sum($grand_total1_skv_rcv)?></th>
														<th class="text-right"><?=array_sum($grand_total1_skv_balc)?></th>
														<th class="text-right"><?=array_sum($grand_total1_fab_isu)?></th>
														<th class="text-right"><?=array_sum($grand_total1_fab_rcv)?></th>
														<th class="text-right"><?=array_sum($grand_total1_fab_balc)?></th>
														<th class="text-right"><?=array_sum($grand_total1_qnty_shpd)?></th>
														<th class="text-right"><?=array_sum($grand_total1_qnty_remn)?></th>
														<th class="text-right"><?=array_sum($grand_total1_qnty_stck)?></th>
													</tr>
													<tr style="background-color: #445767;
													color: white;">
														<th colspan="2">Grand Total</th>
														<th class="text-right"><?=array_sum($grand_total_co_qnty)?></th>
														<th class="text-right"><?=array_sum($grand_total_cut_issue)?></th>
														<th class="text-right"><?=array_sum($grand_total_cut_rcv)?></th>
														<th class="text-right"><?=array_sum($grand_total_cut_balc)?></th>
														<th class="text-right"><?=array_sum($grand_total_skv_isu)?></th>
														<th class="text-right"><?=array_sum($grand_total_skv_rcv)?></th>
														<th class="text-right"><?=array_sum($grand_total_skv_balc)?></th>
														<th class="text-right"><?=array_sum($grand_total_fab_isu)?></th>
														<th class="text-right"><?=array_sum($grand_total_fab_rcv)?></th>
														<th class="text-right"><?=array_sum($grand_total_fab_balc)?></th>
														<th class="text-right"><?=array_sum($grand_total_qnty_shpd)?></th>
														<th class="text-right"><?=array_sum($grand_total_qnty_remn)?></th>
														<th class="text-right"><?=array_sum($grand_total_qnty_stck)?></th>
													</tr>
													<?php
												}
											?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<?php
	} ?>

	<?php if($segment == 'article_wise_order_details'){
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">Order Status Details</h3>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
										<tr>
											<th rowspan="2">Article</th>
											<th rowspan="2">Order No.</th>
											<th rowspan="2">Ord Qnty</th>
											<th colspan="3" class="text-center">Cutting Information</th>
											<th colspan="3" class="text-center">Skiving Information</th>
											<th colspan="3" class="text-center">Fabricator Information</th>
											<th colspan="3" class="text-center">Shipping Information</th>
										</tr>
										<tr>
											<th>Cut Issue</th>
											<th>Cut Rcv.</th>
											<th>Cut Bal.</th>
											<th>Skiv Issue</th>
											<th>Skiv Rcv.</th>
											<th>Skiv Bal.</th>
											<th>Fab Issue</th>
											<th>Fab Rcv.</th>
											<th>Fab Bal.</th>
											<th>Qnt. Shpd</th>
											<th>Qnt. Rem</th>
											<th>Qnt. Stock-in-hand</th>
										</tr>
									</thead>
									<tbody>
										<?php foreach ($result as $rest) {
										    foreach ($rest as $res) {
											?>
											<tr>
												<td nowrap style="font-size: 12px"><?= $res->art_no .' ['.$res->color.']' ?></td>
												<th nowrap style="font-size: 12px"><?= $res->co_no ?></th>
												<td class="text-right"><?= $res->co_quantity ?></td>
												<td class="text-right"><?= $res->cutting_issued_qnty ?></td>
												<td class="text-right"><?= $res->cutting_received_qnty ?></td>
												<td class="text-right"><?= $res->cutting_issued_qnty - $res->cutting_received_qnty ?></td>

												<td class="text-right"><?= $res->cutting_received_qnty ?></td>
												<td class="text-right"><?= $res->skiving_receive_qnty ?></td>
												<td class="text-right"><?= $res->cutting_received_qnty - $res->skiving_receive_qnty ?></td>

												<td class="text-right"><?= $res->jobber_issue_qnty ?></td>
												<td class="text-right"><?= $res->jobber_receive_qnty ?></td>
												<td class="text-right"><?= $res->jobber_issue_qnty - $res->jobber_receive_qnty ?></td>

												<td class="text-right"><?= $res->packing_shipment_quantity ?></td>
												<td class="text-right"><?= $res->jobber_receive_qnty - $res->packing_shipment_quantity ?></td>
												<td class="text-right"><?= $res->co_quantity - $res->packing_shipment_quantity ?></td>
											</tr>
											<?php
										}} ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>

	<?php if($segment == 'buyer_wise_order_details'){
		// echo '<pre>',print_r($result),'</pre>';
		$temp_co_name_array = array();
		foreach($result as $co_name) {
			if(!in_array($co_name->co_no, $temp_co_name_array)){
				array_push($temp_co_name_array, $co_name->co_no);
			}
		}
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">Order Status Details</h3>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">Customer Order Number :
						<br />
						<?= implode(', ', $temp_co_name_array) ?>
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
										<tr>
											<th rowspan="2">Buyer Name</th>
											<th rowspan="2">Order No.</th>
											<th rowspan="2">Article</th>
											<th rowspan="2">Ord Qnty</th>
											<th colspan="3" class="text-center">Cutting Information</th>
											<th colspan="3" class="text-center">Skiving Information</th>
											<th colspan="3" class="text-center">Fabricator Information</th>
											<th colspan="3" class="text-center">Shipping Information</th>
										</tr>
										<tr>
											<th>Cut Issue</th>
											<th>Cut Rcv.</th>
											<th>Cut Bal.</th>
											<th>Skiv Issue</th>
											<th>Skiv Rcv.</th>
											<th>Skiv Bal.</th>
											<th>Fab Issue</th>
											<th>Fab Rcv.</th>
											<th>Fab Bal.</th>
											<th>Qnt. Shpd</th>
											<th>Qnt. Rem</th>
											<th>Qnt. Stock-in-hand</th>
										</tr>
									</thead>
									<tbody>
										<?php foreach ($result as $res) {
											?>
											<tr>
												<th nowrap style="font-size: 12px"><?= $res->name ?></th>
												<th nowrap style="font-size: 12px"><?= $res->co_no ?></th>
												<td nowrap style="font-size: 12px"><?= $res->art_no .' ['.$res->color.']' ?></td>
												<td class="text-right"><?= $res->co_quantity ?></td>
												<td class="text-right"><?= $res->cutting_issued_qnty ?></td>
												<td class="text-right"><?= $res->cutting_received_qnty ?></td>
												<td class="text-right"><?= $res->cutting_issued_qnty - $res->cutting_received_qnty ?></td>

												<td class="text-right"><?= $res->cutting_received_qnty ?></td>
												<td class="text-right"><?= $res->skiving_receive_qnty ?></td>
												<td class="text-right"><?= $res->cutting_issued_qnty - $res->skiving_receive_qnty ?></td>

												<td class="text-right"><?= $res->jobber_issue_qnty ?></td>
												<td class="text-right"><?= $res->jobber_receive_qnty ?></td>
												<td class="text-right"><?= $res->jobber_issue_qnty - $res->jobber_receive_qnty ?></td>

												<td class="text-right"><?= $res->packing_shipment_quantity ?></td>
												<td class="text-right"><?= $res->jobber_receive_qnty - $res->packing_shipment_quantity ?></td>
												<td class="text-right"><?= $res->co_quantity - $res->packing_shipment_quantity ?></td>
											</tr>
											<?php
										} ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>

	<?php if($segment == 'leather_status'){
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
		<?php if($segment1 == 'leather_status') { ?>
	    <h3 class="mar_0 head_font">Leather Status Details</h3>
	    <?php } else { ?>
	    <h3 class="mar_0 head_font">Item Status Details</h3> 
	    <?php } ?>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
										<tr>
											<th>Item Name</th>
											<th>Order No.</th>
											<th class="text-center">Opn. Qty.</th>
											<th class="text-center">Ord Pending</th>
											<th class="text-center">Cut Issue</th>
											<th class="text-center">Cut Rcvd.</th>
											<th class="text-center">Current Stck.</th>
											<th class="text-center">P.O. Pending</th>
											<th class="text-center">Balance</th>
										</tr>
									</thead>
									<tbody>
	<?php  
	$order_quantity = 0;
	$issue_quantity = 0;
	$order_pending = 0;
	$receive_quantity = 0;
	$open_lth = 0;
	$current_stock = 0;
    $po_pending = 0;
    $balance = 0;
    $tot_order_quantity = 0;
	$tot_issue_quantity = 0;
	$tot_order_pending = 0;
	$tot_receive_quantity = 0;
	$tot_open_lth = 0;
	$tot_current_stock = 0;
    $tot_po_pending = 0;
    $tot_balance = 0;
    ?>
										<?php 
                        // echo '<pre>',print_r($result1),'</pre>';
										foreach ($result1 as $r) {
											?>
											<tr>
												<th><?= $r->item_name .' [' . $r->color .']' ?></th>
     <?php 
// $this->db->empty_table('leather_consumption');

        $data_array = array();
        $data_array1 = array();
        $data_array2 = array();
        $new_data_array = array();
        $customer_order = array();
        
        $order_query = "SELECT 
    `customer_order_dtl`.*,
    `article_costing`.`combination_or_not`,
    `item_dtl`.`im_id`
FROM
    `customer_order_dtl`
LEFT JOIN `article_costing` ON `article_costing`.`am_id` = `customer_order_dtl`.`am_id`
LEFT JOIN `article_costing_details` ON `article_costing_details`.`ac_id` = `article_costing`.`ac_id`
LEFT JOIN `item_dtl` ON `item_dtl`.`id_id` = `article_costing_details`.`id_id`
WHERE
    `item_dtl`.`im_id` = $r->im_id
GROUP BY
    `customer_order_dtl`.`co_id`,
    `customer_order_dtl`.`lc_id`,
    `item_dtl`.`im_id`
    ORDER BY
    im_id";
        $order_colour_res = $this->db->query($order_query)->result();
        
//         $order_query = "SELECT
//     `customer_order_dtl`.*,
//     `article_costing`.`combination_or_not`,
//     `item_dtl`.`im_id`
// FROM
//     `item_dtl`
//     LEFT JOIN `article_costing_details` ON `article_costing_details`.`id_id` = `item_dtl`.`id_id`
// LEFT JOIN `article_costing` ON `article_costing`.`ac_id` = `article_costing_details`.`ac_id`
// LEFT JOIN `article_master` ON `article_master`.`am_id` = `article_costing`.`am_id`
// LEFT JOIN `customer_order_dtl` ON `customer_order_dtl`.`am_id` = `article_master`.`am_id`
// LEFT JOIN `customer_order` ON `customer_order`.`co_id` = `customer_order_dtl`.`co_id`
// WHERE
//     `item_dtl`.`im_id` = $r->im_id
//     GROUP BY
//     `customer_order_dtl`.`co_id`,
//     `customer_order_dtl`.`lc_id`,
//     `item_dtl`.`im_id`
//     ";

//         $order_colour_res = $this->db->query($order_query)->result();

    // echo $this->db->last_query(); die();


        foreach($order_colour_res as $o_c_r) {
        	if($o_c_r->co_id == '') {
        		continue;
        	}
            if($o_c_r->combination_or_not == 0) {
            $query = "SELECT
                      total_table.*,
                      IFNULL(SUM(total_table.final_qnty),0) AS final_qnty_new,
                      IFNULL(SUM(total_table.final_cut_qnty),0) AS final_cut_qnty_new,
                      IFNULL(SUM(total_table.final_rcv_qnty),0) AS final_rcv_qnty_new
                      FROM
                      (SELECT
                      cut_is_table.*,
                      IFNULL(SUM(cut_is_table.item_dtl_quantity * cutting_received_challan_detail.receive_cut_quantity),0) AS final_rcv_qnty
                      FROM
                      (SELECT
                      ord_table.*,
                      IFNULL(SUM(ord_table.item_dtl_quantity * cutting_issue_challan_details.cut_co_quantity),0) AS final_cut_qnty
                      FROM
                      (SELECT
                customer_order.co_no,
                customer_order.co_date,
                customer_order.buyer_reference_no,
                customer_order.co_reference_date,
                acc_master.name,
                acc_master.short_name,
                item_master.item AS item_name,
                item_master.im_code AS item_code,
                item_groups.ig_code,
                item_groups.group_name,
                units.unit,
                c1.color as leather_color,
                c2.color as fitting_color,
                c3.color as item_color,
                c3.c_id as item_color_id,
                item_dtl.id_id,
                item_dtl.im_id,
                item_groups.ig_id,
                customer_order_dtl.cod_id,
                customer_order_dtl.co_id,
                customer_order_dtl.am_id,
                customer_order_dtl.lc_id,
                article_costing.ac_id AS costing_id,
                article_costing.combination_or_not,
                article_costing_details.id_id AS item_dtl,
                article_costing_details.quantity AS item_dtl_quantity,
                co_quantity,
                (
                    article_costing_details.quantity * co_quantity
                ) AS temp_qnty,
                    (article_costing_details.quantity * co_quantity) AS final_qnty
            FROM
                `customer_order`
            LEFT JOIN customer_order_dtl ON customer_order.co_id = customer_order_dtl.co_id
            LEFT JOIN article_master ON article_master.am_id = customer_order_dtl.am_id
            LEFT JOIN article_costing ON article_costing.am_id = article_master.am_id
            LEFT JOIN article_costing_details ON article_costing.ac_id = article_costing_details.ac_id
            LEFT JOIN acc_master ON acc_master.am_id = customer_order.acc_master_id
            LEFT JOIN item_dtl ON item_dtl.id_id = article_costing_details.id_id
            LEFT JOIN colors c1 ON customer_order_dtl.lc_id = c1.c_id
            LEFT JOIN colors c2 ON customer_order_dtl.fc_id = c2.c_id
            LEFT JOIN colors c3 ON item_dtl.c_id = c3.c_id
            LEFT JOIN item_master ON item_master.im_id = item_dtl.im_id
            LEFT JOIN item_groups ON item_master.ig_id = item_groups.ig_id
            LEFT JOIN units ON item_groups.u_id = units.u_id
            WHERE
                customer_order.`co_id` = $o_c_r->co_id AND customer_order.status = 1 AND item_dtl.`im_id` = $o_c_r->im_id AND customer_order_dtl.`lc_id` = $o_c_r->lc_id
            )AS ord_table
    LEFT JOIN cutting_issue_challan_details ON cutting_issue_challan_details.cod_id = ord_table.cod_id
    GROUP BY
   ord_table.cod_id) AS cut_is_table
   LEFT JOIN cutting_received_challan_detail ON cutting_received_challan_detail.cod_id = cut_is_table.cod_id
   GROUP BY
   cut_is_table.cod_id) AS total_table
   GROUP BY
    total_table.im_id,
    total_table.lc_id";
                $res = $this->db->query($query)->row();
                
                
                

        $arr = array(
                    'co_no'=>$res->co_no,
                    'co_date' =>$res->co_date,
                    'buyer_reference_no'=>$res->buyer_reference_no,
                    'co_reference_date'=>$res->co_reference_date,
                    'name' =>$res->name,
                    'short_name'=>$res->short_name,
                    'item_name'=>$res->item_name,
                    'item_code' =>$res->item_code,
                    'ig_code'=>$res->ig_code,
                    'group_name'=>$res->group_name,
                    'unit' =>$res->unit,
                    'leather_color'=>$res->leather_color,
                    'fitting_color'=>$res->fitting_color,
                    'item_color' =>$res->item_color,
                    'item_color_id' =>$res->item_color_id,
                    'lc_id' =>$res->lc_id,
                    'id_id'=>$res->id_id,
                    'im_id'=>$res->im_id,
                    'ig_id'=>$res->ig_id,
                    'cod_id' =>$res->cod_id,
                    'co_id'=>$res->co_id,
                    'am_id'=>$res->am_id,
                    'costing_id' =>$res->costing_id,
                    'item_dtl'=>$res->item_dtl,
                    'item_dtl_quantity'=>$res->item_dtl_quantity,
                    'co_quantity' =>$res->co_quantity,
                    'temp_qnty'=>$res->temp_qnty,
                    'final_qnty'=>$res->final_qnty_new,
                    'final_cut_qnty'=>$res->final_cut_qnty_new,
                    'final_rcv_qnty'=>$res->final_rcv_qnty_new,
                    'combination_or_not'=>$res->combination_or_not
                );
                
                // echo $this->db->last_query()."<br/>";
        // $this->db->insert('temp_consumption', $arr);
        array_push($data_array, $arr);
                // echo '<pre>', print_r($data_array1), '</pre>'; die();

            } else {
            	$query1 = "SELECT
                customer_order.co_no,
                customer_order.co_date,
                customer_order.buyer_reference_no,
                customer_order.co_reference_date,
                acc_master.name,
                acc_master.short_name,
                item_master.item AS item_name,
                item_master.im_code AS item_code,
                item_groups.ig_code,
                item_groups.group_name,
                units.unit,
                c1.color as leather_color,
                c2.color as fitting_color,
                c3.color as item_color,
                c3.c_id as item_color_id,
                item_dtl.id_id,
                item_dtl.im_id,
                item_groups.ig_id,
                customer_order_dtl.cod_id,
                customer_order_dtl.co_id,
                customer_order_dtl.am_id,
                customer_order_dtl.lc_id,
                article_costing.ac_id AS costing_id,
                article_costing.combination_or_not,
                article_costing_details.id_id AS item_dtl,
                article_costing_details.quantity AS item_dtl_quantity,
                co_quantity,
                (
                    article_costing_details.quantity * co_quantity
                ) AS temp_qnty,
                SUM(
                    article_costing_details.quantity * co_quantity
                ) AS final_qnty,
                IFNULL(SUM(article_costing_details.quantity * cutting_issue_challan_details.cut_co_quantity ),0) AS final_cut_qnty,
                IFNULL(SUM(article_costing_details.quantity * cutting_received_challan_detail.receive_cut_quantity ),0) AS final_rcv_qnty
            FROM
                `customer_order`
            LEFT JOIN customer_order_dtl ON customer_order.co_id = customer_order_dtl.co_id
            LEFT JOIN article_master ON article_master.am_id = customer_order_dtl.am_id
            LEFT JOIN article_costing ON article_costing.am_id = article_master.am_id
            LEFT JOIN article_costing_details ON article_costing.ac_id = article_costing_details.ac_id
            LEFT JOIN acc_master ON acc_master.am_id = customer_order.acc_master_id
            LEFT JOIN item_dtl ON item_dtl.id_id = article_costing_details.id_id
            LEFT JOIN colors c1 ON customer_order_dtl.lc_id = c1.c_id
            LEFT JOIN colors c2 ON customer_order_dtl.fc_id = c2.c_id
            LEFT JOIN colors c3 ON item_dtl.c_id = c3.c_id
            LEFT JOIN item_master ON item_master.im_id = item_dtl.im_id
            LEFT JOIN item_groups ON item_master.ig_id = item_groups.ig_id
            LEFT JOIN units ON item_groups.u_id = units.u_id
            LEFT JOIN cutting_issue_challan_details ON cutting_issue_challan_details.cod_id = customer_order_dtl.cod_id
            LEFT JOIN cutting_received_challan_detail ON cutting_received_challan_detail.cod_id = customer_order_dtl.cod_id
            WHERE
                customer_order.`co_id` = $o_c_r->co_id AND customer_order.status = 1 AND item_dtl.`im_id` = $o_c_r->im_id AND customer_order_dtl.`lc_id` = $o_c_r->lc_id
            GROUP BY
                item_dtl.id_id";

$result1 = $this->db->query($query1)->result();

// echo $this->db->last_query()."<br/>";

foreach($result1 as $res) {
	$arr = array(
                    'co_no'=>$res->co_no,
                    'co_date' =>$res->co_date,
                    'buyer_reference_no'=>$res->buyer_reference_no,
                    'co_reference_date'=>$res->co_reference_date,
                    'name' =>$res->name,
                    'short_name'=>$res->short_name,
                    'item_name'=>$res->item_name,
                    'item_code' =>$res->item_code,
                    'ig_code'=>$res->ig_code,
                    'group_name'=>$res->group_name,
                    'unit' =>$res->unit,
                    'leather_color'=>$res->leather_color,
                    'fitting_color'=>$res->fitting_color,
                    'item_color' =>$res->item_color,
                    'item_color_id' =>$res->item_color_id,
                    'lc_id' =>$res->lc_id,
                    'id_id'=>$res->id_id,
                    'im_id'=>$res->im_id,
                    'ig_id'=>$res->ig_id,
                    'cod_id' =>$res->cod_id,
                    'co_id'=>$res->co_id,
                    'am_id'=>$res->am_id,
                    'costing_id' =>$res->costing_id,
                    'item_dtl'=>$res->item_dtl,
                    'item_dtl_quantity'=>$res->item_dtl_quantity,
                    'co_quantity' =>$res->co_quantity,
                    'temp_qnty'=>$res->temp_qnty,
                    'final_qnty'=>$res->final_qnty,
                    'final_cut_qnty'=>$res->final_cut_qnty,
                    'final_rcv_qnty'=>$res->final_rcv_qnty,
                    'combination_or_not'=>$res->combination_or_not
                );
        array_push($data_array1, $arr);
	}

            }
            }

    if(!empty($data_array1)) {
    	$this->db->empty_table('temp_leather_consumption');
    	// echo '<pre>', print_r($data_array1), '</pre>'; die();
    	foreach($data_array as $da) {
    	$this->db->insert('temp_leather_consumption', $da);
    }
    	$consumption_list = $this->db->get('temp_leather_consumption')->result();
        foreach($consumption_list as $d_a) {
        	foreach($data_array1 as $d_a1) {
        	    if($d_a->co_id == $d_a1['co_id'] && $d_a->lc_id == $d_a1['item_color_id']) {
        	        $prev_final_qnty = $this->db->get_where('temp_leather_consumption', array('co_id' => $d_a1['co_id'], 'lc_id' => $d_a1['item_color_id']))->row()->final_qnty;
        	        $prev_cut_qnty = $this->db->get_where('temp_leather_consumption', array('co_id' => $d_a1['co_id'], 'lc_id' => $d_a1['item_color_id']))->row()->final_cut_qnty;
        	        $prev_rcv_qnty = $this->db->get_where('temp_leather_consumption', array('co_id' => $d_a1['co_id'], 'lc_id' => $d_a1['item_color_id']))->row()->final_rcv_qnty;
        			$new_final_qnty = $d_a1['final_qnty'];
        			$new_final_cut_qnty = $d_a1['final_cut_qnty'];
        			$new_final_rcv_qnty = $d_a1['final_rcv_qnty'];
        			$total_qnty = ($prev_final_qnty + $new_final_qnty);
        			$total_cut_qnty = ($prev_cut_qnty + $new_final_cut_qnty);
        			$total_rcv_qnty = ($prev_rcv_qnty + $new_final_rcv_qnty);
                     $update_array = array(
          'final_qnty' => $total_qnty,
          'final_cut_qnty' => $total_cut_qnty,
          'final_rcv_qnty' => $total_rcv_qnty 
        );

        $this->db->update('temp_leather_consumption', $update_array, array('co_id' => $d_a1['co_id'], 'lc_id' => $d_a1['item_color_id']));
        	    }
        	    
    $check_value = $this->db->get_where('temp_leather_consumption', array('co_id' => $d_a1['co_id'], 'lc_id' => $d_a1['item_color_id']))->num_rows();
        		if($check_value == 0) {
        			$consumption_list_check = $this->db->where(array('co_id'=> $d_a1['co_id'], 'item_color_id'=> $d_a1['item_color_id']))->get('temp_leather_consumption')->num_rows();
    if($consumption_list_check == 0) {
                		  //  array_push($new_data_array, $d_a1);
                     $this->db->insert('temp_leather_consumption', $d_a1);
                 } 
//                  else {
// $consumption_list_check1 = $this->db->where('item_color_id', $d_a1['item_color_id'])->get('temp_leather_consumption')->num_rows();
//                   if($consumption_list_check1 == 0) {
//                      $this->db->insert('temp_leather_consumption', $d_a1);
//                  }
//                  }
        		}
        	}
        }
     
    $get_consumption_list = $this->db->get('temp_leather_consumption')->result();
    foreach($get_consumption_list as $res) {
    	if($res->combination_or_not == 0) {
    		if($res->lc_id == $r->c_id) {
    			$arr = array(
                    'co_no'=>$res->co_no,
                    'co_date' =>$res->co_date,
                    'buyer_reference_no'=>$res->buyer_reference_no,
                    'co_reference_date'=>$res->co_reference_date,
                    'name' =>$res->name,
                    'short_name'=>$res->short_name,
                    'item_name'=>$res->item_name,
                    'item_code' =>$res->item_code,
                    'ig_code'=>$res->ig_code,
                    'group_name'=>$res->group_name,
                    'unit' =>$res->unit,
                    'leather_color'=>$res->leather_color,
                    'fitting_color'=>$res->fitting_color,
                    'item_color' =>$res->item_color,
                    'item_color_id' =>$res->item_color_id,
                    'lc_id' =>$res->lc_id,
                    'id_id'=>$res->id_id,
                    'im_id'=>$res->im_id,
                    'ig_id'=>$res->ig_id,
                    'cod_id' =>$res->cod_id,
                    'co_id'=>$res->co_id,
                    'am_id'=>$res->am_id,
                    'costing_id' =>$res->costing_id,
                    'item_dtl'=>$res->item_dtl,
                    'item_dtl_quantity'=>$res->item_dtl_quantity,
                    'co_quantity' =>$res->co_quantity,
                    'temp_qnty'=>$res->temp_qnty,
                    'final_qnty'=>$res->final_qnty,
                    'final_cut_qnty'=>$res->final_cut_qnty,
                    'final_rcv_qnty'=>$res->final_rcv_qnty,
                    'combination_or_not'=>$res->combination_or_not
                );
        array_push($customer_order, $arr);
    } 
    	} else {
    	if($res->item_color_id == $r->c_id) {
    			$arr = array(
                    'co_no'=>$res->co_no,
                    'co_date' =>$res->co_date,
                    'buyer_reference_no'=>$res->buyer_reference_no,
                    'co_reference_date'=>$res->co_reference_date,
                    'name' =>$res->name,
                    'short_name'=>$res->short_name,
                    'item_name'=>$res->item_name,
                    'item_code' =>$res->item_code,
                    'ig_code'=>$res->ig_code,
                    'group_name'=>$res->group_name,
                    'unit' =>$res->unit,
                    'leather_color'=>$res->leather_color,
                    'fitting_color'=>$res->fitting_color,
                    'item_color' =>$res->item_color,
                    'item_color_id' =>$res->item_color_id,
                    'lc_id' =>$res->lc_id,
                    'id_id'=>$res->id_id,
                    'im_id'=>$res->im_id,
                    'ig_id'=>$res->ig_id,
                    'cod_id' =>$res->cod_id,
                    'co_id'=>$res->co_id,
                    'am_id'=>$res->am_id,
                    'costing_id' =>$res->costing_id,
                    'item_dtl'=>$res->item_dtl,
                    'item_dtl_quantity'=>$res->item_dtl_quantity,
                    'co_quantity' =>$res->co_quantity,
                    'temp_qnty'=>$res->temp_qnty,
                    'final_qnty'=>$res->final_qnty,
                    'final_cut_qnty'=>$res->final_cut_qnty,
                    'final_rcv_qnty'=>$res->final_rcv_qnty,
                    'combination_or_not'=>$res->combination_or_not
                );
        array_push($customer_order, $arr);
    }	
    	}
    }
        
        } else {
        	foreach($data_array as $d_a) {
        		if($d_a['lc_id'] == $r->c_id) {
                     array_push($customer_order, $d_a);
        	}
        }
        }

           // echo '<pre>', print_r($data_array), '</pre>'; die();
      ?>
												
	 <?php
      if(count($customer_order) > 0) {
	  ?>										
      <td>
      	<?php 
        foreach($customer_order as $c_o) {
        	echo $c_o['co_no']."<br/>";
      	 ?>
              <?php } ?>
      </td>
  <?php } else { ?>
  	  <td></td>
  <?php } ?>
  <td style="text-align: right;">
      	<?= number_format($r->final_opn_qnty_for_leather_status, 2) ?>
      	<?php 
          $open_lth = $r->final_opn_qnty_for_leather_status."<br/>";
          $tot_open_lth += $open_lth;
      		  ?>
      </td>
      <?php
      if(count($customer_order) > 0) {
	  ?>
      <td style="text-align: right;">
      	<?php 
        foreach($customer_order as $c_o) {
        		
                $order_quantity = $c_o['final_qnty'];
                $co_id = $c_o['co_id'];
                $im_id = $c_o['im_id'];
                $lc_id = $c_o['lc_id'];
                 $cut_issue_quantity = $c_o['final_cut_qnty'];
            $order_peng = ($order_quantity - $cut_issue_quantity);
        	echo abs(round($order_peng, 2))."<br/>";
        	$order_pending += $order_peng;
        	$tot_order_pending += $order_peng;
        }
      	 ?>
      </td>
      <td style="text-align: right;">
      	<?php 
        foreach($customer_order as $c_o) {

                $co_id = $c_o['co_id'];
                $im_id = $c_o['im_id'];
                $lc_id = $c_o['lc_id'];
                 $cut_is_quantity = $c_o['final_cut_qnty'];
        	echo abs(round($cut_is_quantity, 2))."<br/>";
        	$issue_quantity += $cut_is_quantity;
        	$tot_issue_quantity += $cut_is_quantity; 
        }
      	 ?>
      </td>
      <td style="text-align: right;">
      	<?php 
        foreach($customer_order as $c_o) {

                $co_id = $c_o['co_id'];
                $im_id = $c_o['im_id'];
                $lc_id = $c_o['lc_id'];
                 $cut_rv_quantity = $c_o['final_rcv_qnty'];
        	echo abs(round($cut_rv_quantity, 2))."<br/>";
        	$receive_quantity += $cut_rv_quantity;
        	$tot_receive_quantity += $cut_rv_quantity;
        }
      	 ?>
      </td>
  <?php } else { ?>
  	   <td></td>
  	   <td></td>
  	   <td></td>
  <?php } ?>
      <td style="text-align: right;">
      	<?php 
      	$opening_stock = $r->final_opening_stock;
        $sum_purchase_order = $r->final_pur_rcv_qnty;
        $sum_material_issue = $r->final_mat_issue_qnty;
        $sum_stock_in = $r->final_stock_in_qnty;

    $current_stock = ($opening_stock + $sum_purchase_order - $sum_material_issue + $sum_stock_in);
    
         echo number_format($current_stock, 2)."<br/>";
         $tot_current_stock += $current_stock;
      		  ?>
      </td>
      <td style="text-align: right;">
      	<?php
        $sum_purchase_order_issue = $r->final_pur_issue_qnty;
        $sum_supp_purchase_order_issue = $r->final_sup_pur_order_qnty;
        $po_pending = ($sum_purchase_order_issue + $sum_supp_purchase_order_issue - $sum_purchase_order);
        
        echo number_format($po_pending, 2)."<br/>";
        $tot_po_pending += $po_pending;    
      		  ?>
      </td>
      <td style="text-align: right;">
      	<?php 
        $balance = $open_lth + $order_pending + $issue_quantity - $receive_quantity - $current_stock - $po_pending;

        echo number_format($balance, 2)."<br/>";
        $tot_balance += $balance;
      	 ?>
      </td>
      </tr>
      <tr style="background: #d4ecea;">
	    <th colspan="2">Total</th>
	    <td style="text-align: right;"><?php echo $open_lth;
	 	 ?></td>
	    	 	 <td style="text-align: right;"><?php echo number_format($order_pending, 2);
	 	$order_pending = 0;
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($issue_quantity, 2);
	 	$issue_quantity = 0;
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($receive_quantity, 2);
	 	$receive_quantity = 0;
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($current_stock, 2);
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($po_pending, 2);
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($balance, 2);
	 	 ?></td>
	 </tr>
   <?php }
	 ?>
	 </tr>
      <tr style="background: #445767; color: white;">
	    <th colspan="2">Grand Total</th>
	 	 <td style="text-align: right;"><?php echo number_format($tot_open_lth, 2);
	 	 ?></td>
	    <td style="text-align: right;"><?php echo number_format($tot_order_pending, 2);
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($tot_issue_quantity, 2);
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($tot_receive_quantity, 2);
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($tot_current_stock, 2);
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($tot_po_pending, 2);
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($tot_balance, 2);
	 	 ?></td>
	 </tr> 
								
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>

	<?php if($segment == 'item_status'){
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
		<?php if($segment1 == 'leather_status') { ?>
	    <h3 class="mar_0 head_font">Leather Status Details</h3>
	    <?php } else { ?>
	    <h3 class="mar_0 head_font">Item Status Details</h3> 
	    <?php } ?>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
										<tr>
											<th>Item Name</th>
											<th>Order No.</th>
											<th class="text-center">Ord Pending</th>
											<th class="text-center">Cut Issue</th>
											<th class="text-center">Cut Rcvd.</th>
											<th class="text-center">Current Stck.</th>
											<th class="text-center">P.O. Pending</th>
											<th class="text-center">Balance</th>
										</tr>
									</thead>
									<tbody>
	<?php  
	$order_quantity = 0;
	$issue_quantity = 0;
	$order_pending = 0;
	$receive_quantity = 0;
	$open_lth = 0;
	$current_stock = 0;
    $po_pending = 0;
    $balance = 0;
    $tot_order_quantity = 0;
	$tot_issue_quantity = 0;
	$tot_order_pending = 0;
	$tot_receive_quantity = 0;
	$tot_open_lth = 0;
	$tot_current_stock = 0;
    $tot_po_pending = 0;
    $tot_balance = 0;
    ?>
										<?php 
                        // echo '<pre>',print_r($result1),'</pre>';
										foreach ($result1 as $r) {
											?>
											<tr>
												<th><?= $r->item_name .' [' . $r->color .']' ?></th>
	 <?php
      if(count($customer_order) > 0) {
	  ?>										
      <td>
      	<?php 
        foreach($customer_order as $c_o) {
        	if($c_o->im_id == $r->im_id && $c_o->color_id == $r->c_id) {
        	echo $c_o->co_no."<br/>";
        	}
      	 ?>
              <?php } ?>
      </td>
      <td style="text-align: right;">
      	<?php 
        foreach($customer_order as $c_o) {
        	if($c_o->im_id == $r->im_id && $c_o->color_id == $r->c_id) {
        	   // echo '<pre>', print_r($c_o), '</pre>'; die();
        		$query = "SELECT
                co_quantity,
                (
                    article_costing_details.quantity * co_quantity
                ) AS temp_qnty,
                SUM(
                    article_costing_details.quantity * co_quantity
                ) AS final_qnty
            FROM
                `customer_order`
            LEFT JOIN customer_order_dtl ON customer_order.co_id = customer_order_dtl.co_id
            LEFT JOIN article_master ON article_master.am_id = customer_order_dtl.am_id
            LEFT JOIN article_costing ON article_costing.am_id = article_master.am_id
            LEFT JOIN article_costing_details ON article_costing.ac_id = article_costing_details.ac_id
            LEFT JOIN acc_master ON acc_master.am_id = customer_order.acc_master_id
            LEFT JOIN item_dtl ON item_dtl.id_id = article_costing_details.id_id
            LEFT JOIN colors ON item_dtl.c_id = colors.c_id
            LEFT JOIN item_master ON item_master.im_id = item_dtl.im_id
            LEFT JOIN item_groups ON item_master.ig_id = item_groups.ig_id
            LEFT JOIN units ON item_groups.u_id = units.u_id
            WHERE
                customer_order.`co_id` = $c_o->co_id AND item_master.`im_id` = $c_o->im_id
                AND item_dtl.`c_id` = $c_o->color_id AND customer_order.status = 1
            GROUP BY
               item_dtl.im_id, customer_order_dtl.lc_id";
                $order_quantity = $this->db->query($query)->row()->final_qnty;

            $query1 = "SELECT
    CUS_ORD.*,
    IFNULL(
        SUM(
           CUS_ORD.item_dtl_quantity * cutting_issue_challan_details.cut_co_quantity
        ),
        0
    ) AS final_cut_qnty
FROM
    (
    SELECT
        customer_order_dtl.cod_id,
        customer_order_dtl.co_id,
        article_master.am_id,
        colors.c_id,
        customer_order_dtl.lc_id,
        article_costing_details.quantity AS item_dtl_quantity
    FROM
        `customer_order`
    LEFT JOIN customer_order_dtl ON customer_order.co_id = customer_order_dtl.co_id
    LEFT JOIN article_master ON article_master.am_id = customer_order_dtl.am_id
    LEFT JOIN article_costing ON article_costing.am_id = article_master.am_id
    LEFT JOIN article_costing_details ON article_costing.ac_id = article_costing_details.ac_id
    LEFT JOIN acc_master ON acc_master.am_id = customer_order.acc_master_id
    LEFT JOIN item_dtl ON item_dtl.id_id = article_costing_details.id_id
    LEFT JOIN colors ON item_dtl.c_id = colors.c_id
    LEFT JOIN item_master ON item_master.im_id = item_dtl.im_id
    LEFT JOIN item_groups ON item_master.ig_id = item_groups.ig_id
    LEFT JOIN units ON item_groups.u_id = units.u_id
        WHERE
        item_dtl.`id_id` = $c_o->id_id
            GROUP BY
               item_dtl.id_id
) AS CUS_ORD
LEFT JOIN cutting_issue_challan_details ON cutting_issue_challan_details.cod_id = CUS_ORD.cod_id AND cutting_issue_challan_details.am_id = CUS_ORD.am_id AND cutting_issue_challan_details.lc_id = CUS_ORD.lc_id
WHERE
        cutting_issue_challan_details.`co_id` = $c_o->co_id AND cutting_issue_challan_details.`am_id` = $c_o->am_id AND cutting_issue_challan_details.`lc_id` = $c_o->lc_id
        GROUP BY
        cutting_issue_challan_details.co_id, cutting_issue_challan_details.am_id, cutting_issue_challan_details.lc_id";
                 $cut_issue_quantity_row = $this->db->query($query1)->row();
                 if(count($cut_issue_quantity_row) > 0) {
                    $cut_issue_quantity = $cut_issue_quantity_row->final_cut_qnty;  
                 } else {
                   $cut_issue_quantity = 0;  
                 }
            $order_peng = ($order_quantity - $cut_issue_quantity);
        	echo round($order_peng, 2)."<br/>";
        	$order_pending += $order_peng;
        	$tot_order_pending += $order_peng;
        	}
        }
      	 ?>
      </td>
      <td style="text-align: right;">
      	<?php 
        foreach($customer_order as $c_o) {
        	if($c_o->im_id == $r->im_id && $c_o->color_id == $r->c_id) {
            $query1 = "SELECT
    CUS_ORD.*,
    IFNULL(
        SUM(
           CUS_ORD.item_dtl_quantity * cutting_issue_challan_details.cut_co_quantity
        ),
        0
    ) AS final_cut_qnty
FROM
    (
    SELECT
        customer_order_dtl.cod_id,
        customer_order_dtl.co_id,
        article_master.am_id,
        colors.c_id,
        customer_order_dtl.lc_id,
        article_costing_details.quantity AS item_dtl_quantity
    FROM
        `customer_order`
    LEFT JOIN customer_order_dtl ON customer_order.co_id = customer_order_dtl.co_id
    LEFT JOIN article_master ON article_master.am_id = customer_order_dtl.am_id
    LEFT JOIN article_costing ON article_costing.am_id = article_master.am_id
    LEFT JOIN article_costing_details ON article_costing.ac_id = article_costing_details.ac_id
    LEFT JOIN acc_master ON acc_master.am_id = customer_order.acc_master_id
    LEFT JOIN item_dtl ON item_dtl.id_id = article_costing_details.id_id
    LEFT JOIN colors ON item_dtl.c_id = colors.c_id
    LEFT JOIN item_master ON item_master.im_id = item_dtl.im_id
    LEFT JOIN item_groups ON item_master.ig_id = item_groups.ig_id
    LEFT JOIN units ON item_groups.u_id = units.u_id
        WHERE
        item_dtl.`id_id` = $c_o->id_id
            GROUP BY
               item_dtl.id_id
) AS CUS_ORD
LEFT JOIN cutting_issue_challan_details ON cutting_issue_challan_details.cod_id = CUS_ORD.cod_id AND cutting_issue_challan_details.am_id = CUS_ORD.am_id AND cutting_issue_challan_details.lc_id = CUS_ORD.lc_id
WHERE
        cutting_issue_challan_details.`co_id` = $c_o->co_id AND cutting_issue_challan_details.`am_id` = $c_o->am_id AND cutting_issue_challan_details.`lc_id` = $c_o->lc_id
        GROUP BY
        cutting_issue_challan_details.co_id, cutting_issue_challan_details.am_id, cutting_issue_challan_details.lc_id";
                 $cut_is_quantity_row = $this->db->query($query1)->row();
                 if(count($cut_is_quantity_row) > 0) {
                    $cut_is_quantity = $cut_is_quantity_row->final_cut_qnty;  
                 } else {
                   $cut_is_quantity = 0;  
                 }
        	echo round($cut_is_quantity, 2)."<br/>";
        	$issue_quantity += $cut_is_quantity;
        	$tot_issue_quantity += $cut_is_quantity; 
        	}
        }
      	 ?>
      </td>
      <td style="text-align: right;">
      	<?php 
        foreach($customer_order as $c_o) {
        	if($c_o->im_id == $r->im_id && $c_o->color_id == $r->c_id) {
            $query1 = "
            SELECT
   CUS_ORD.*,
  IFNULL(SUM(CUS_ORD.item_dtl_quantity * cutting_received_challan_detail.receive_cut_quantity ),0) AS final_rcv_qnty
FROM
    (
    SELECT
        customer_order_dtl.cod_id,
        customer_order_dtl.co_id,
        article_master.am_id,
        colors.c_id,
        customer_order_dtl.lc_id,
        article_costing_details.quantity AS item_dtl_quantity
    FROM
        `customer_order`
    LEFT JOIN customer_order_dtl ON customer_order.co_id = customer_order_dtl.co_id
    LEFT JOIN article_master ON article_master.am_id = customer_order_dtl.am_id
    LEFT JOIN article_costing ON article_costing.am_id = article_master.am_id
    LEFT JOIN article_costing_details ON article_costing.ac_id = article_costing_details.ac_id
    LEFT JOIN acc_master ON acc_master.am_id = customer_order.acc_master_id
    LEFT JOIN item_dtl ON item_dtl.id_id = article_costing_details.id_id
    LEFT JOIN colors ON item_dtl.c_id = colors.c_id
    LEFT JOIN item_master ON item_master.im_id = item_dtl.im_id
    LEFT JOIN item_groups ON item_master.ig_id = item_groups.ig_id
    LEFT JOIN units ON item_groups.u_id = units.u_id
        WHERE
        item_dtl.`id_id` = $c_o->id_id
            GROUP BY
               item_dtl.id_id
) AS CUS_ORD
LEFT JOIN cutting_received_challan_detail ON cutting_received_challan_detail.cod_id = CUS_ORD.cod_id AND cutting_received_challan_detail.am_id = CUS_ORD.am_id AND cutting_received_challan_detail.lc_id = CUS_ORD.lc_id
WHERE
        cutting_received_challan_detail.`co_id` = $c_o->co_id AND cutting_received_challan_detail.`am_id` = $c_o->am_id AND cutting_received_challan_detail.`lc_id` = $c_o->lc_id
        GROUP BY
        cutting_received_challan_detail.co_id, cutting_received_challan_detail.am_id, cutting_received_challan_detail.lc_id
        ";
                 $cut_rv_quantity_row = $this->db->query($query1)->row();
                 if(count($cut_rv_quantity_row) > 0) {
                    $cut_rv_quantity = $cut_rv_quantity_row->final_rcv_qnty;  
                 } else {
                   $cut_rv_quantity = 0;  
                 }
        	echo round($cut_rv_quantity, 2)."<br/>";
        	$receive_quantity += $cut_rv_quantity;
        	$tot_receive_quantity += $cut_rv_quantity;
        	}
        }
      	 ?>
      </td>
  <?php } else { ?>
  	   <td></td>
  	   <td></td>
  	   <td></td>
  	   <td></td>
  <?php } ?>
      <td style="text-align: right;">
      	<?php 
      	$opening_stock = $r->final_opening_stock;
        $sum_purchase_order = $r->final_pur_rcv_qnty;
        $sum_material_issue = $r->final_mat_issue_qnty;
        $sum_stock_in = $r->final_stock_in_qnty;

    $current_stock = ($opening_stock + $sum_purchase_order - $sum_material_issue + $sum_stock_in);
    
         echo number_format($current_stock, 2)."<br/>";
         $tot_current_stock += $current_stock;
      		  ?>
      </td>
      <td style="text-align: right;">
      	<?php
        $sum_purchase_order_issue = $r->final_pur_issue_qnty;
        $sum_supp_purchase_order_issue = $r->final_sup_pur_order_qnty;
        $po_pending = ($sum_purchase_order_issue + $sum_supp_purchase_order_issue - $sum_purchase_order);
        
        echo number_format($po_pending, 2)."<br/>";
        $tot_po_pending += $po_pending;    
      		  ?>
      </td>
      <td style="text-align: right;">
      	<?php 
        $balance = $order_pending - $issue_quantity + $receive_quantity - $current_stock - $po_pending;

        echo number_format($balance, 2)."<br/>";
        $tot_balance += $balance;
      	 ?>
      </td>
      </tr>
      <tr style="background: #d4ecea;">
	    <th colspan="2">Total</th>
	    <td style="text-align: right;"><?php echo number_format($order_pending, 2);
	 	$order_pending = 0;
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($issue_quantity, 2);
	 	$issue_quantity = 0;
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($receive_quantity, 2);
	 	$receive_quantity = 0;
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($current_stock, 2);
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($po_pending, 2);
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($balance, 2);
	 	 ?></td>
	 </tr>
   <?php }
	 ?>
	 </tr>
      <tr style="background: #445767; color: white;">
	    <th colspan="2">Grand Total</th>
	    <td style="text-align: right;"><?php echo number_format($tot_order_pending, 2);
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($tot_issue_quantity, 2);
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($tot_receive_quantity, 2);
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($tot_current_stock, 2);
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($tot_po_pending, 2);
	 	 ?></td>
	 	 <td style="text-align: right;"><?php echo number_format($tot_balance, 2);
	 	 ?></td>
	 </tr> 
								
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>
	
	<?php if($segment == 'leather_status_po'){
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
		<?php if($segment1 == 'leather_status_po') { ?>
	    <h3 class="mar_0 head_font">Leather Status Details</h3>
	    <?php } else { ?>
	    <h3 class="mar_0 head_font">Item Status Details</h3> 
	    <?php } ?>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
										<tr>
											<th>PUR. #</th>
											<th>PUR. DT.</th>
											<th class="text-center">PUR. QNTY.</th>
											<th class="text-center">SUPP. #</th>
											<th class="text-center">SUPP. DT.</th>
											<th class="text-center">SUPP. QNTY.</th>
											<th class="text-center">RCPT. #</th>
											<th class="text-center">RCPT. DT.</th>
											<th class="text-center">RCPT. QNTY.</th>
											<th class="text-center">BAL. QNTY.</th>
										</tr>
									</thead>
									<tbody>
										<?php 
                                        if(count($result) > 0) {
										foreach ($result as $r) {
											// foreach($item_id as $l) {
											// 	if($l == $r->item_dtl) {
											// 		continue 2;
											// 	}
											// }
    $pod_quantity = 0;
    $sup_quantity = 0;
    $rcv_quantity = 0;
    $bal_quantity = 0;
    $tot_pod_quantity = 0;
    $tot_sup_quantity = 0;
    $tot_rcv_quantity = 0;
    $tot_bal_quantity = 0;
											?>
											<tr><th colspan="10" style="text-align: center;"><?= $r->item ?> (<?= $r->color ?>)</th>
											</tr>

   <?php 
   

   $result_purc = $this->db->select('purchase_order.*, item_master.item, colors.color, item_dtl.id_id')
            ->join('purchase_order_details', 'purchase_order_details.po_id = purchase_order.po_id', 'left')
             ->join('item_dtl', 'item_dtl.id_id = purchase_order_details.id_id', 'left')
             ->join('item_master', 'item_master.im_id = item_dtl.im_id', 'left')
             ->join('colors', 'colors.c_id = item_dtl.c_id', 'left')
             ->where('purchase_order_details.id_id', $r->id_id)
             ->where('purchase_order.status', '1')
             ->get_where('purchase_order')->result(); ?>
             <?php 
             if(count($result_purc) > 0) { 
             foreach($result_purc as $rc) { ?>
                <tr>                                                                        
             	<td>
             <?php  
                  echo $rc->po_number."<br />";
              ?>
             </td>
             <td>
             <?php  
                  echo date("d-m-Y", strtotime($rc->po_date))."<br />";
              ?>
             </td>
             <td style="text-align: right;">
             <?php
              $result_pu = $this->db->select_sum('purchase_order_details.pod_quantity')
            ->join('purchase_order', 'purchase_order.po_id = purchase_order_details.po_id', 'left')
             ->where('purchase_order_details.id_id', $rc->id_id)
             ->where('purchase_order_details.po_id', $rc->po_id)
             ->where('purchase_order.status', '1')
             ->group_by('purchase_order_details.po_id')
             ->get_where('purchase_order_details')->row(); ?>
            <?php
            if(count($result_pu) > 0) {
            $pod_quantity += $result_pu->pod_quantity;
            $tot_pod_quantity += $result_pu->pod_quantity;
            echo $result_pu->pod_quantity."<br />";
             } else {
            echo "<br />";  	
             }
          ?>
             </td>
             <td>
             <?php
              $result_sup = $this->db->select('supp_purchase_order.*, supp_purchase_order_detail.id_id')
            ->join('supp_purchase_order', 'supp_purchase_order.sup_id = supp_purchase_order_detail.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.po_id', $rc->po_id)
             ->where('supp_purchase_order.supp_status', '1')
             ->get_where('supp_purchase_order_detail')->result(); ?>
            <?php 
             if(count($result_sup) > 0) {
             	foreach($result_sup as $r_s) {
            echo $r_s->supp_po_number."<br />";
             }} else {
             	echo "<br />";
             }
          ?>
             </td>
             <td>
             <?php
              $result_sup = $this->db->select('supp_purchase_order.*, supp_purchase_order_detail.id_id')
            ->join('supp_purchase_order', 'supp_purchase_order.sup_id = supp_purchase_order_detail.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.po_id', $rc->po_id)
             ->where('supp_purchase_order.supp_status', '1')
             ->get_where('supp_purchase_order_detail')->result(); ?>
            <?php 
             if(count($result_sup) > 0) {
             	foreach($result_sup as $r_s) {
            echo date("d-m-Y", strtotime($r_s->pur_order_date))."<br />";
             }} else {
             	echo "<br />";
             }
          ?>
             </td>
             <td style="text-align: right;">
             <?php
             	$result_sup = $this->db->select('supp_purchase_order.*, supp_purchase_order_detail.id_id')
            ->join('supp_purchase_order_detail', 'supp_purchase_order_detail.sup_id = supp_purchase_order.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.po_id', $rc->po_id)
             ->where('supp_purchase_order.supp_status', '1')
             ->get_where('supp_purchase_order')->row();
             if(count($result_sup) > 0) {
            $result_su = $this->db->select('supp_purchase_order_detail.item_qty')
            ->join('supp_purchase_order', 'supp_purchase_order.sup_id = supp_purchase_order_detail.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.sup_id', $result_sup->sup_id)
             ->where('supp_purchase_order_detail.status', '1')
             // ->group_by('supp_purchase_order_detail.sup_id')
             ->get_where('supp_purchase_order_detail')->result();
             if(count($result_su) > 0) {
             	foreach($result_su as $r_s) {
              ?>
            <?php
            $sup_quantity += $r_s->item_qty;
            $tot_sup_quantity += $r_s->item_qty; 
            echo $r_s->item_qty."<br />";
             }}
         } else {
             	echo "<br />";
             } ?>
             </td>



             <td>
             <?php
              $result_rcv = $this->db->select('purchase_order_receive.*, purchase_order_receive_detail.id_id')
            ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
             ->where('purchase_order_receive_detail.id_id', $rc->id_id)
             ->where('purchase_order_receive_detail.po_id', $rc->po_id)
             ->where('purchase_order_receive.status', '1')
             // ->group_by('purchase_order_receive_detail.purchase_order_receive_id')
             ->get_where('purchase_order_receive_detail')->result(); ?>
            <?php if(count($result_rcv) > 0) {
                foreach($result_rcv as $r_r) {
            echo $r_r->purchase_order_receive_bill_no."<br />";
                }
             } else {
             	echo "<br />"; 
             }
         
              ?>
             </td>
             <td>
             <?php
              $result_rcv = $this->db->select('purchase_order_receive.*, purchase_order_receive_detail.id_id')
            ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
             ->where('purchase_order_receive_detail.id_id', $rc->id_id)
             ->where('purchase_order_receive_detail.po_id', $rc->po_id)
             ->where('purchase_order_receive.status', '1')
             // ->group_by('purchase_order_receive_detail.purchase_order_receive_id')
             ->get_where('purchase_order_receive_detail')->result(); ?>
            <?php if(count($result_rcv) > 0) {
                foreach($result_rcv as $r_r) {
            echo date("d-m-Y", strtotime($r_r->purchase_order_receive_date))."<br />";
            }} else {
            echo "<br />"; 	
             }
              ?>
             </td>
             <td style="text-align: right;">
             <?php
            $result_rc = $this->db->select('purchase_order_receive_detail.item_quantity')
            ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
             ->where('purchase_order_receive_detail.id_id', $rc->id_id)
             ->where('purchase_order_receive_detail.po_id', $rc->po_id)
             ->where('purchase_order_receive_detail.status', '1')
             // ->group_by('purchase_order_receive_detail.purchase_order_receive_id')
             ->get('purchase_order_receive_detail')->result();
             	?>
            <?php
            if(count($result_rc)>0) {
                foreach($result_rc as $r_r) {
            $rcv_quantity += $r_r->item_quantity;
            $tot_rcv_quantity += $r_r->item_quantity;
             echo $r_r->item_quantity."<br />";
                }} else {
             	echo "<br />";
             }
          ?>
             </td>
             <td style="text-align: right;">
             	<?php
                
                 $result_pu = $this->db->select_sum('purchase_order_details.pod_quantity')
            ->join('purchase_order', 'purchase_order.po_id = purchase_order_details.po_id', 'left')
             ->where('purchase_order_details.id_id', $rc->id_id)
             ->where('purchase_order_details.po_id', $rc->po_id)
             ->where('purchase_order.status', '1')
             ->group_by('purchase_order_details.po_id')
             ->get_where('purchase_order_details')->row(); ?>
            <?php
            if(count($result_pu) > 0) {
            $pod_quantity = $result_pu->pod_quantity;
             } else {
            $pod_quantity = 0;  	
             }
             
             $result_sup = $this->db->select('supp_purchase_order.*, supp_purchase_order_detail.id_id')
            ->join('supp_purchase_order_detail', 'supp_purchase_order_detail.sup_id = supp_purchase_order.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.po_id', $rc->po_id)
             ->where('supp_purchase_order.supp_status', '1')
             ->get_where('supp_purchase_order')->row();
             if(count($result_sup) > 0) {
            $result_su = $this->db->select_sum('supp_purchase_order_detail.item_qty')
            ->join('supp_purchase_order', 'supp_purchase_order.sup_id = supp_purchase_order_detail.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.sup_id', $result_sup->sup_id)
             ->where('supp_purchase_order_detail.status', '1')
             ->group_by('supp_purchase_order.po_id')
             ->get_where('supp_purchase_order_detail')->row();
             if(count($result_su) > 0) {
              ?>
            <?php
            $sup_quantity = $result_su->item_qty;
             }
         } else {
             	$sup_quantity = 0;
             }
             
             $result_rc = $this->db->select_sum('purchase_order_receive_detail.item_quantity')
            ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
             ->where('purchase_order_receive_detail.id_id', $rc->id_id)
             ->where('purchase_order_receive_detail.po_id', $rc->po_id)
             ->where('purchase_order_receive_detail.status', '1')
             ->group_by('purchase_order_receive_detail.po_id')
             ->get('purchase_order_receive_detail')->row();
             	?>
            <?php
            if(count($result_rc)>0) {
            $rcv_quantity = $result_rc->item_quantity;
             } else {
             	$rcv_quantity = 0;
             }
             	?>
            <?php
            $bal_quantity = (($pod_quantity + $sup_quantity) - $rcv_quantity);
            $tot_bal_quantity += $bal_quantity;
             echo $bal_quantity."<br />";
              ?>
             </td>
             </tr>
             <?php }} ?>
             <tr>
             <tr>
             	<th colspan="2">
                 Total             	
             </th>
             <td style="text-align: right;">
             	<?php echo $tot_pod_quantity;
                   $tot_pod_quantity = 0;
             	 ?>
             </td>
             <td colspan="3" style="text-align: right;">
             	<?php echo $tot_sup_quantity;
                   $tot_sup_quantity = 0;
             	 ?>
             </td>
             <td colspan="3" style="text-align: right;">
             	<?php echo $tot_rcv_quantity;
                   $tot_rcv_quantity = 0;
             	 ?>
             </td>
             <td colspan="3" style="text-align: right;">
             	<?php echo $tot_bal_quantity;
                   $tot_bal_quantity = 0;
             	 ?>
             </td>
             </tr>											

											<?php
										}} ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>

	<?php if($segment == 'checking_summary_status'){
		// echo '<pre>',print_r($result),'</pre>';

		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">Checking Summary Details</h3>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
										<tr>
									    <th >Order No.</th>
                                        <th >Article</th>
                                        <th >Order Qnty</th>
                                        <th >Checking Qnty</th>
                                        <th class="text-center">Employee</th>
                                        <th class="text-center">Start Date</th>
                                        <th class="text-center">End Date</th>
										</tr>
									</thead>
									<tbody>
										<?php foreach ($result as $res) {
											?>
											<tr>
												<td><?= $res->co_no ?></td>
                                                <td><?= $res->art_no . '(' . $res->lc . ')' ?></td>
                                                <td><?= $res->co_total_quantity ?></td>
                                                <td><?= $res->checked_quantity ?></td>
                                                <td><?= $res->emp_name ?></td>
                                                <td><?= date ("d-m-Y", strtotime($res->checking_start_date_time)) ?></td>
                                                <td><?= date ("d-m-Y", strtotime($res->checking_end_date_time)) ?></td>
											</tr>
											<?php
										} ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>

	<?php if($segment == 'checking_stock_summary_status') {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">Stock Summary Details</h3>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
                        <tr>
                            <th rowspan="2" style="text-align:center">Item</th>
                            <th colspan="2" style="text-align:center">Opening Information</th>
                            <th colspan="2" style="text-align:center">Purchase Information</th>
                            <th colspan="2" style="text-align:center">Issue Information</th>
                            <th colspan ="2" style="text-align:center">Stock In Information</th>
                            <th colspan ="2" style="text-align:center">Balance Information</th>
                            <th rowspan="2">Closing Rate</th>
                        </tr>
                        <tr>
                            <th style="text-align:center">Opn Qnty</th>
                            <th style="text-align:center">Opn Val</th>
                            <th style="text-align:center">Pur Qnty</th>
                            <th style="text-align:center">Pur Val</th>
                            <th style="text-align:center">Issue Qnty</th>
                            <th style="text-align:center">Issue Val</th>
                            <th style="text-align:center">Stock In Qnty</th>
                            <th style="text-align:center">Stock In Val</th>
                            <th style="text-align:center">Bal Qnty</th>
                            <th style="text-align:center">Bal Val</th>
                        </tr>
                        </thead>
									<tbody>
										<?php
                        $all_bal_qty = 0; $all_opn_qty =0; $all_pur_qty = 0; $all_issue_qty =0; $all_stockin_qty =0;
                        $all_bal_rate = 0; $all_opn_rate =0; $all_pur_rate = 0; $all_issue_rate =0; $all_stockin_rate =0; $closing_rate = 0;
                        foreach ($result as $f) {
                            
                            if($f['opening_qnty'] == 0 && $f['purchase_qnty'] == 0 && $f['issue_qnty'] == 0) {
                                continue;
                            }
                            
                            $bal_qty = $f['opening_qnty'] + $f['purchase_qnty'] - $f['issue_qnty'] + $f['stock_in_qnty'];
                            $bal_rate = $f['opening_val'] + $f['purchase_val'] - $f['issue_val'] + $f['stock_in_val'];

                            $all_opn_qty += $f['opening_qnty'];
                            $all_opn_rate += $f['opening_val'];
                            $all_pur_qty += $f['purchase_qnty'];
                            $all_pur_rate += $f['purchase_val'];
                            $all_issue_qty += $f['issue_qnty'];
                            $all_issue_rate += $f['issue_val'];
                            $all_stockin_qty += $f['stock_in_qnty'];
                            $all_stockin_rate += $f['stock_in_val'];
                            $all_bal_qty += $bal_qty;
                            $all_bal_rate += $bal_rate;
                            ?>
                            <tr>
                                <th><?= $f['item'] . '('. $f['color'] .')' ?></th>
                                <td style="text-align:right"><?= number_format($f['opening_qnty'],2) ?></td>
                                <td style="text-align:right"><?= number_format($f['opening_val'],2) ?></td>
                                <td style="text-align:right"><?=  number_format($f['purchase_qnty'],2) ?></td>
                                <td style="text-align:right"><?= number_format($f['purchase_val'],2) ?></td>
                                <td style="text-align:right"><?=  number_format($f['issue_qnty'],2) ?></td>
                                <td style="text-align:right"><?= number_format($f['issue_val'],2) ?></td>
                                <td style="text-align:right"><?=  number_format($f['stock_in_qnty'],2) ?></td>
                                <td style="text-align:right"><?= number_format($f['stock_in_val'],2) ?></td>
                                <td style="text-align:right"><?= number_format($bal_qty,2)?></td>
                                <td style="text-align:right"><?= number_format($bal_rate,2) ?></td>
                                <?php if($bal_qty != 0) { 
                                	$closing_rate += ($bal_rate/$bal_qty); 
                                ?>
                                <td style="text-align:right"><?= number_format(($bal_rate/$bal_qty),2) ?></td>
                            <?php } else {
                                    $closing_rate += 0;
                             ?>
                                <td style="text-align:right">0</td>
                            <?php } ?>
                            </tr>
                            <?php
                        }
                        ?>
                        <tr>
                        	<th>Total</th>
                        	<td style="text-align:right"><?= number_format($all_opn_qty, 2) ?></td>
                        	<td style="text-align:right"><?= number_format($all_opn_rate, 2) ?></td>
                        	<td style="text-align:right"><?= number_format($all_pur_qty, 2) ?></td>
                        	<td style="text-align:right"><?= number_format($all_pur_rate, 2) ?></td>
                        	<td style="text-align:right"><?= number_format($all_issue_qty, 2) ?></td>
                        	<td style="text-align:right"><?= number_format($all_issue_rate, 2) ?></td>
                        	<td style="text-align:right"><?= number_format($all_stockin_qty, 2) ?></td>
                        	<td style="text-align:right"><?= number_format($all_stockin_rate, 2) ?></td>
                        	<td style="text-align:right"><?= number_format($all_bal_qty, 2) ?></td>
                        	<td style="text-align:right"><?= number_format($all_bal_rate, 2) ?></td>
                        	<td style="text-align:right"><?= number_format($closing_rate, 2) ?></td>
                        </tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>

	<?php if($segment == 'checking_stock_detail_ledger') {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">Stock Summary Ledger</h3>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
                        <tr>
                            <th style="text-align:center">Item Name</th>
                            <th style="text-align:center">Remark</th>
                            <th style="text-align:center">Ref. No.</th>
                            <th style="text-align:center">Date</th>
                            <th style="text-align:center">Quantity</th>
                            <th style="text-align:center">Rate</th>
                            <th style="text-align:center">Value</th>
                            <th style="text-align:center">Bal. Qnty.</th>
                            <th style="text-align:center">Bal. Val.</th>
                        </tr>
                        </thead>
									<tbody>
										<?php
						$prev_item = '';
                        foreach ($result as $f) {
                            
                            $crnt_item = $f['item'].' ('.$f['color'].')';
                    if ($crnt_item != $prev_item) {
                        $bal_qnty = 0; $bal_val = 0;
                        $prev_item = $crnt_item;
                    }

                    if($f['remark'] == 'Opening') {
                        $bal_qnty += $f['qnty'];
                        $bal_val += $f['val'];
                    }
                    elseif($f['remark'] == 'Purchase') {
                        $bal_qnty += $f['qnty'];
                        $bal_val += $f['val'];
                    }
                    elseif($f['remark'] == 'Issue') {
                        $bal_qnty -= $f['qnty'];
                        $bal_val -= $f['val'];
                    }
                            ?>
                            <tr>
                        <td><?= $f['item'] . ' ('. $f['color'] .')' ?></td>
                        <td><?=$f['remark']?></td>
                        <td><?=$f['sl_no']?></td>
                        <td style="text-align:center"><?=date('d-m-Y', strtotime($f['date']))?></td>
                        <td style="text-align:right"><?=number_format($f['qnty'],2)?></td>
                        <td style="text-align:right"><?=number_format($f['rate'],2)?></td>
                        <td style="text-align:right"><?=number_format($f['val'],2)?></td>
                        <td style="text-align:right"><?=number_format($bal_qnty,2)?></td>
                        <td style="text-align:right"><?=number_format($bal_val,2)?></td>
                    </tr>
                            <?php
                        }
                        ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>

	<?php if($segment == 'supplier_purchase_ledger') {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
                <tr>
                    <th style="text-align:center">RECEIPT #</th>
                    <th style="text-align:center">DATE</th>
                    <th style="text-align:right">QUANTITY</th>
                    <th style="text-align:right">AMOUNT</th>
                    <th style="text-align:right">DELV.</th>
                    <th style="text-align:right">TAX(CGST %)</th>
                    <th style="text-align:right">TAX(CGST Rs.)</th>
                    <th style="text-align:right">(SGST %)</th>
                    <th style="text-align:right">(SGST Rs.)</th>
                    <th style="text-align:right">TAX AMOUNT</th>
                    <th style="text-align:right">TOT. AMOUNT</th>
                </tr>
                                    </thead>
									<tbody>
<?php
foreach ($result as $r) { ?>
	<tr>
    <td colspan="11" style="text-align:center"><strong><?= $r->acc_name ?></strong></td>
				<?php 
		$from = date('Y-m-d', strtotime($from));
        $to = date('Y-m-d', strtotime($to));
$opening_row = $this->db->select('purchase_order_receive.*, SUM(purchase_order_receive_detail.item_quantity) AS item_quantity')
                ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
                ->where('purchase_order_receive.am_id', $r->am_id)
                ->where('STR_TO_DATE(purchase_order_receive.purchase_order_receive_date, "%Y-%m-%d") BETWEEN "' . date('Y-m-d', strtotime($from)) . '" and "' . date('Y-m-d', strtotime($to)) . '"')
                ->group_by('purchase_order_receive_detail.purchase_order_receive_id')
                ->get('purchase_order_receive_detail')->result();

				foreach ($opening_row as $p_d) { ?>	
 <tr>	
     <td><?= $p_d->purchase_order_receive_bill_no ?></td>
     <td><?= date ("d-m-Y", strtotime($p_d->purchase_order_receive_date)) ?></td>
     <td style="text-align:right"><?= $p_d->item_quantity ?></td>
     <td style="text-align:right"><?= $p_d->total_amount ?></td>
     <td style="text-align:right"><?= $p_d->delivery_charge ?></td>
     <td style="text-align:right"><?= $p_d->cgst_percent ?></td>
     <td style="text-align:right"><?= $p_d->cgst_percentage_amount ?></td>
     <td style="text-align:right"><?= $p_d->sgst_percent ?></td>
     <td style="text-align:right"><?= $p_d->sgst_percentage_amount ?></td>
     <td style="text-align:right"><?= $p_d->delivery_sgst_cgst_amount ?></td>
     <td style="text-align:right"><?= $p_d->net_amount ?></td>
 </tr>
           <?php } ?>
           </tr>
           <?php } ?>	
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>
	
	<?php if($segment == 'group_stock_summary') {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<?php 
                            if(isset($result)) {
								 ?>
								<table id="all_det" class="table table-bordered">
									<thead>
                <tr>
                    <th colspan="11" style="text-align:center">LOCAL</th>
                </tr>
                <tr>
                    <th style="text-align:center">Group</th>
                    <th style="text-align:center">Open Qnty.</th>
                    <th style="text-align:center">Open Val.</th>
                    <th style="text-align:center">Pur. Qnty.</th>
                    <th style="text-align:center">Pur. Val.</th>
                    <th style="text-align:center">Issue Qnty.</th>
                    <th style="text-align:center">Issue Val.</th>
                    <th style="text-align:center">Stock In Qnty.</th>
                    <th style="text-align:center">Stock In Val.</th>
                    <th style="text-align:center">Bal. Qnty.</th>
                    <th style="text-align:center">Bal. Val.</th>
                </tr>
                </thead>
                <tbody>
                <?=$result['html']?>
                </tbody>
								</table>
								<br><br><br>

								<table id="all_det" class="table table-bordered">
									<thead>
                <tr>
                    <th colspan="11" style="text-align:center">IMPORT</th>
                </tr>
                <tr>
                    <th style="text-align:center">Group</th>
                    <th style="text-align:center">Open Qnty.</th>
                    <th style="text-align:center">Open Val.</th>
                    <th style="text-align:center">Pur. Qnty.</th>
                    <th style="text-align:center">Pur. Val.</th>
                    <th style="text-align:center">Issue Qnty.</th>
                    <th style="text-align:center">Issue Val.</th>
                    <th style="text-align:center">Stock In Qnty.</th>
                    <th style="text-align:center">Stock In Val.</th>
                    <th style="text-align:center">Bal. Qnty.</th>
                    <th style="text-align:center">Bal. Val.</th>
                </tr>
                </thead>
                <tbody>
                <?=$result['html2']?>
                </tbody>
								</table>
								<br><br><br>

								<table id="all_det" class="table table-bordered">
									<thead>
                <tr>
                    <th colspan="11" style="text-align:center">NONE</th>
                </tr>
                <tr>
                    <th style="text-align:center">Group</th>
                    <th style="text-align:center">Open Qnty.</th>
                    <th style="text-align:center">Open Val.</th>
                    <th style="text-align:center">Pur. Qnty.</th>
                    <th style="text-align:center">Pur. Val.</th>
                    <th style="text-align:center">Issue Qnty.</th>
                    <th style="text-align:center">Issue Val.</th>
                    <th style="text-align:center">Stock In Qnty.</th>
                    <th style="text-align:center">Stock In Val.</th>
                    <th style="text-align:center">Bal. Qnty.</th>
                    <th style="text-align:center">Bal. Val.</th>
                </tr>
                </thead>
                <tbody>
                <?=$result['html3']?>
                </tbody>
								</table>
								<?php 
                            }
								 ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>
	
	<?php if($segment == 'jobber_bill_summary') {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
                <tr>
                    <th style="text-align: center;">Jobber Name</th>
                    <th style="text-align: center;">Bill Number</th>
                    <th style="text-align: center;">Date</th>
                    <th style="text-align: right;">Total Pcs.</th>
                    <th style="text-align: right;">Issue Qnty.</th>
                    <th style="text-align: right;">Net Amount</th>
                </tr>
                </thead>
                <tbody>
                	<?php 
                	$total_bill_amount = 0;
                	$total_quantity = 0;
                	$total_net_bill = 0;
                	if(isset($result)) { 
                          foreach($result as $rs) {
                          	foreach($rs as $r) {
                		?>
                    <tr>
                    	<td><?= $r->name ?></td>
                    	<td><?= $r->jobber_bill_number ?></td>
                    	<td><?= date("d-m-Y", strtotime($r->jobber_bill_date)) ?></td>
                    	<td style="text-align: right;"><?php echo $r->bill_amount;
                         $total_bill_amount += $r->bill_amount;
                    	 ?></td>
                    	<td style="text-align: right;"><?php echo $r->quantity;
                         $total_quantity += $r->quantity;
                    	 ?></td>
                    	<td style="text-align: right;"><?php echo $r->net_bill;
                         $total_net_bill += $r->net_bill; 
                    	 ?></td>
                    </tr>
                	<?php }} ?>
                	<tr>
                		<th colspan="3">All Total</th>
                		<th style="text-align: right;"><?= $total_bill_amount ?></th>
                		<th style="text-align: right;"><?= $total_quantity ?></th>
                		<th style="text-align: right;"><?= $total_net_bill ?></th>
                	</tr>
                <?php } ?>
                </tbody>
            </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>

	<?php if($segment == 'cutter_bill_summary') {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
                <tr>
                    <th style="text-align: center;">Acc Holder</th>
                    <th style="text-align: center;">Bill#</th>
                    <th style="text-align: center;">Bill Date</th>
                    <th style="text-align: right;">Total Qnty.</th>
                    <th style="text-align: right;">Total Parts.</th>
                    <th style="text-align: right;">Total Amnt.</th>
                </tr>
                </thead>
                <tbody>
                	<?php 
                	$total_bill_amount = 0;
                	$total_quantity = 0;
                	$total_net_bill = 0;
                	if(isset($result)) { 
                          foreach($result as $rs) {
                          	foreach($rs as $r) {
                		?>
                    <tr>
                    	<td><?= $r->name ?></td>
                    	<td><?= $r->cutter_bill_name ?></td>
                    	<td><?= date("d-m-Y", strtotime($r->cutter_bill_date)) ?></td>
                    	<td style="text-align: right;"><?php echo number_format($r->total_quantity, 2);
                         $total_quantity += $r->total_quantity;
                    	 ?></td>
                    	<td style="text-align: right;"><?php echo number_format($r->total_parts, 2);
                         $total_net_bill += $r->total_parts; 
                    	 ?></td>
                    	 <td style="text-align: right;"><?php echo number_format($r->cutter_bill_total, 2);
                         $total_bill_amount += $r->cutter_bill_total;
                    	 ?></td>
                    </tr>
                	<?php }} ?>
                	<tr>
                		<th colspan="3">All Total</th>
                		<th style="text-align: right;"><?= number_format($total_bill_amount, 2) ?></th>
                		<th style="text-align: right;"><?= number_format($total_quantity, 2) ?></th>
                		<th style="text-align: right;"><?= number_format($total_net_bill, 2) ?></th>
                	</tr>
                <?php } ?>
                </tbody>
            </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>
	
	<?php if($segment == 'monthly_production_status') {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
                <tr>
                                <th>Month</th>
                                <th>Date</th>
                                <th>Buyer Name</th>
                                <th style="text-align: right;">Shipment Qnty</th>
                </tr>
                </thead>
                <tbody>
                            <?php
//                             echo '<pre>', print_r($fetch_all_monthly_buyer_report), '</pre>';die();
                            $groups = array();
                            foreach ($fetch_all_monthly_buyer_report as $fasd) {
                                foreach ($fasd as $f) {
                                    $key = $f->mname;
                                    if (!isset($groups[$key])) {
                                        $groups[$key] = array(
                                            'mname' => $f->mname,
                                            'total_quantity' => $f->total_quantity,
                                        );
                                    } else {
                                        $groups[$key]['mname'] = $f->mname;
                                        $groups[$key]['total_quantity'] += $f->total_quantity;
                                    }
                                }
                            }
//                            echo '<pre>', print_r($groups), '</pre>';die();

                            $total = 0;
                            foreach ($fetch_all_monthly_buyer_report as $fasd) {
                                foreach ($fasd as $curr_key=>$f) {

                                    $keys = array();
                                    foreach($fasd as $key=>$val) {
                                        if ($val->mname == $f->mname) {
                                            array_push($keys, $key);
                                        }
                                    }
//                                    echo '<pre>', print_r($keys), '</pre>';die();

                                    ?>
                                    <tr>
                                        <td><?= $f->mname ?></td>
                                        <td><?= date("d-m-Y", strtotime($f->package_date)) ?></td>
                                        <td><?= $f->name ?></td>
                                        <td style="text-align: right;"><?php $total += $f->total_quantity; echo $f->total_quantity; ?></td>
                                    </tr>

                                    <?php
                                    if(end($keys) == $curr_key) {
                                        ?>
                                        <tr>
                                            <th><?= $f->mname ?></th>
                                            <th colspan="2">Total for <?=$groups[$f->mname]['mname']?></th>
                                            <th style="text-align: right;"><?= number_format( $groups[$f->mname]['total_quantity'], 2)?></th>
                                        </tr>
                                        <?php
                                    }

                                }
                                ?>
                                <?php
                            }
                            ?>
                            <tr>
                                <th colspan="3">Grand Total</th>
                                <th style="text-align: right;"><?= number_format($total, 2) ?></th>
                            </tr>
                        </tbody>
            </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>
	
	<?php if($segment == 'fetch_production_register' ) {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
			    <div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">PRODUCTION REGISTER</h3>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
                <tr>
                                <th>Date</th>
                                <th>Article Name</th>
                                <th>Colour</th>
                                <th>Challan</th>
                                <th style="text-align: right;">Challan Qnty.</th>
                                <th>Invoice Name</th>
                                <th style="text-align: right;">Invoice Qnty</th>
                </tr>
                </thead>
                <tbody>
                	<tr class="bg-primary">
                                <td colspan="5">
                                    <strong>Date: <?= $result[0]->challan_date ?></strong>
                                </td>
                                <td colspan="2">
                                    <strong>Opening Balance for:  <?= $closing_balance ?></strong>
                                </td>    
                            </tr>
                            <?php
                            $total = 0;
                            $total1 = 0;
                            $inc_total = 0;
                            $exp_total = 0;
                            $iter = 1;
                            foreach ($result as $curr_key=>$f) {
                            
                                    $total_row = count($result);

                                    $date_array = array();
                                    $month_array = array();
                                    foreach($result as $key=>$val) {
                                        if ($val->challan_date == $f->challan_date) {
                                            array_push($date_array, $key);
                                        }
                                        if ($val->mon == $f->mon) {
                                            array_push($month_array, $key);
                                        }
                                    }
if($f->challan_status == 0) {

                                    ?>
                                    <tr>
                                        <td><?= $f->challan_date ?></td>
                                        <td><?= $f->article_name ?></td>
                                        <td><?= $f->article_color ?></td>
                                        <td><?= $f->challan_number ?></td>
                                        <td style="text-align: right;"><?php $total += $f->challan_quantity; $closing_balance += $f->challan_quantity; echo $f->challan_quantity; ?></td>
                                        <td></td>
                                        <td></td>
                                    </tr>

    <?php } else { ?>
              <tr>
                                        <td><?= $f->challan_date ?></td>
                                        <td><?= $f->article_name ?></td>
                                        <td><?= $f->article_color ?></td>
                                        <td></td>
                                        <td></td>
                                        <td><?= $f->challan_number ?></td>
                                        <td style="text-align: right;"><?php $total1 += $f->challan_quantity; $closing_balance -= $f->challan_quantity; echo $f->challan_quantity; ?></td>
                                    </tr>
    <?php } ?>                                

                                    <?php
                                    if(end($date_array) == $curr_key) {
                                        ?>
                                        <tr class="bg-primary">
                                            <th colspan="2"> Closing balance on <?= $f->challan_date ?><span class="pull-right"><?= $closing_balance ?></span></th>
                                            <th colspan="3"> Total income on <?=$f->challan_date?><span class="pull-right"><?php $inc_total += $total; echo $total; ?></span></th>
                                            <th colspan="2"> Total expendituree on <?=$f->challan_date?><span class="pull-right"><?php $exp_total += $total1; echo $total1; ?></span></th>
                                        </tr>
                                        <?php
                                        $total = 0;
                                        $total1 = 0;
                                    }
                                    if(end($month_array) == $curr_key) {
                                        ?>
                                        <tr class="bg-warning">
                                            <th colspan="2">For <?= $f->mon ?></th>
                                            <th colspan="3">Month-wise Income: <?= $inc_total ?></th>
                                            <th colspan="2">Month-wise Expences: <?= $exp_total ?></th>
                                        </tr>
                                        <?php
                                    $inc_total = 0;
                                    $exp_total = 0;
                                    }
                            if($iter != 1 and end($date_array) == $curr_key and $iter != $total_row) {
                                            ?>
                                            <tr class="bg-info">
                                                <td colspan="5"></td>
                                                <td colspan="2"><strong> <span class="pull-right">Opening Balance: <?= $closing_balance ?></strong></span></td>
                                            </tr>
                                            <?php
                                        }
                                        $iter++;

                                ?>
                                <?php
                            }
                            ?>
                            
                        </tbody>
            </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>
	
	<?php if($segment == 'outstanding_report' ) {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">OUTSTANDING REPORT</h3>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
                <tr>
                                <th>Buyer Name</th>
                                <th>Proforma No</th>
                                <th>Ord. Number</th>
                                <th>Order Date</th>
                                <th>Order Delivery Date</th>
                                <th>Our Style</th>
                                <th>Buyer Style</th>
                                <th>Colour</th>
                                <th style="text-align: right;">Qnty. Ordered</th>
                                <th style="text-align: right;">Qnty. Sold</th>
                                <th style="text-align: right;">Qnty. Balance</th>
                                <th style="text-align: right;">Rate</th>
                                <th style="text-align: right;">Balance Amount</th>
                                <th style="text-align: right;">Conv. Rate</th>
                                <th style="text-align: right;">INR. Balance Amount</th>
                </tr>
                </thead>
                <tbody>
                            <?php
                            $total = 0;
                            $total1 = 0;
                            $inc_total = 0;
                            $exp_total = 0;
                            $iter = 1;
                            $colspan_val = 0;

                            $groups = array();
                            // foreach($result as $key=>$res) {
                            //         foreach($res as $key=>$val) {
                            //         	$key = $iter;
                            //             if ($val->am_id == $iter) {
                            //                 $groups[$key]['am_id'] = $val->am_id;
                            //                 $groups[$key]['colspan_val'] = $colspan_val ++;
                            //             } else {
                            //             	$colspan_val = 0;
                            //             	$iter++;
                            //             }
                                        
                            //         }
                            //     }
                            $count = 0;
                            $gt1=0;$gt2=0;$gt3=0;$gt4=0;$gt5=0;
                            $gtt1=0;$gtt2=0;$gtt3=0;$gtt4=0;$gtt5=0;
                            foreach ($result as $res) {
                            	$new_iter = 1;
                                $count = count($res);
                                if($count > 0) {
                            	foreach($res as $f) {
                                    $gt1 += $f->co_quantity;
                                    $gt2 += $f->quantity;
                                    $gt3 += $f->co_quantity - $f->quantity;
                                    $gt4 += ($f->co_quantity - $f->quantity) * $f->rate_foreign;
                                    $gt5 += 0.00;
                                    $gtt1 += $f->co_quantity;
                                    $gtt2 += $f->quantity;
                                    $gtt3 += $f->co_quantity - $f->quantity;
                                    $gtt4 += ($f->co_quantity - $f->quantity) * $f->rate_foreign;
                                    $gtt5 += 0.00;
                                    ?>
                                    <tr>
                                    	<?php if($new_iter == 1) { ?>
                                        <td rowspan="<?= $count ?>"><?= $f->name ?></td>
                                    <?php } ?>
                                        <td><?= $f->proforma_number ?></td>
                                        <td><?= $f->co_no ?></td>
                                        <td><?= $f->co_date ?></td>
                                        <td><?= $f->co_delivery_date ?></td>
                                        <td><?= $f->art_no ?></td>
                                        <td><?= $f->alt_art_no ?></td>
                                        <td><?= $f->color ?></td>
                                        <td style="text-align: right;"><?= $f->co_quantity ?></td>
                                        <?php if($f->quantity != '') { ?>
                                        <td style="text-align: right;"><?= $f->quantity ?></td>
                                        <?php } else { ?>
                                        <td style="text-align: right;">0</td>
                                        <?php } ?>
                                        <td style="text-align: right;"><?= ($f->co_quantity - $f->quantity) ?></td>
                                        <td style="text-align: right;"><?= $f->rate_foreign ?></td>
                                        <td style="text-align: right;"><?= (($f->co_quantity - $f->quantity) * $f->rate_foreign) ?></td>
                                        <td style="text-align: right;">0.00</td>
                                        <td style="text-align: right;">0.00</td>
                                    </tr>                                

                                <?php
                                $new_iter++;
                            } ?>
                            <tr class="bg-info">
                            <th colspan="8">Total</th>
                            <th style="text-align: right;"><?=$gtt1?></th>
                            <th style="text-align: right;"><?=$gtt2?></th>
                            <th style="text-align: right;"><?=$gtt3?></th>
                            <th></th>
                            <th style="text-align: right;"><?=$gtt4?></th>
                            <th></th>
                            <th style="text-align: right;"><?=$gtt5?></th>
                            </tr>
                            <?php 
                            $gtt1=0;$gtt2=0;$gtt3=0;$gtt4=0;$gtt5=0;
                             ?>
                            <?php 
                            $count = 0;
                            $new_iter = 1;
                            }
                            }
                            ?>
                            <tr class="bg-primary">
                            <th colspan="8">Grand Total</th>
                            <th style="text-align: right;"><?=$gt1?></th>
                            <th style="text-align: right;"><?=$gt2?></th>
                            <th style="text-align: right;"><?=$gt3?></th>
                            <th></th>
                            <th style="text-align: right;"><?=$gt4?></th>
                            <th></th>
                            <th style="text-align: right;"><?=$gt5?></th>
                            </tr>
                            
                        </tbody>
            </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>
	
	<?php if($segment == 'payroll_reports_advance_ledger' ) {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">ADVANCE LEDGER</h3>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
                <tr>
                                    <th>Emp. Name</th>
                                    <th>Status</th>
                                    <th style="text-align: right;">Advance Amount</th>
                                    <th style="text-align: right;">Advance Adjusted</th>
                                </tr>
                </thead>
                <tbody>
                            <?php
                                foreach($result as $a){
                                    
                                    if($a->ADV == 0 and $a->LN == 0 ){
                                        continue;
                                    }
                                    
                                    ?>
                                    <tr>
                                        <td><?= $a->name . '['.$a->e_code.']' ?></td>
                                        <td><?= ($a->TAG == 1) ? 'Advance Taken on: ' . $a->MONNAME : 'Advance Adjusted on: ' . explode('~', $a->MONNAME)[0] ?></td>
                                        <td style="text-align: right;"><?= $a->ADV ?></td>
                                        <td style="text-align: right;"><?= $a->LN ?></td>
                                    </tr>
                                    <?php
                                }
                                ?>
                            
                        </tbody>
            </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>

	<?php if($segment == 'payroll_reports_leave' ) {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">LEAVE DETAILS</h3>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
                <tr>
                                    <th>Emp. Name</th>
                                    <th>Month</th>
                                    <th>Casual Leave</th>
                                    <th>Earn Leave</th>
                                    <th>ESI Leave</th>
                                </tr>
                </thead>
                <tbody>
                            <?php
                                foreach($result as $a){
                                    ?>
                                    <tr>
                                        <td><?= $a->name . '['.$a->e_code.']' ?></td>
                                        <td><?= explode('~', $a->MON)[0] ?></td>
                                        <td><?= $a->T4 ?></td>
                                        <td><?= $a->T5 ?></td>
                                        <td><?= $a->T6 ?></td>
                                    </tr>
                                    <?php
                                }
                                ?>
                            
                        </tbody>
            </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>

	<?php if($segment == 'payroll_esi_pf' ) {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">E.S.I. DETAILS</h3>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
                <tr>
                                    <th colspan="4">SHILPA OVERSEAS PVT. LTD. <br /> 51, Mahanirban Road, Kolkata-700029</th>
                                    <th colspan="3">
                                        Month: <?= $mont ?><br />
                                        Date: <?= date('d-m-Y') ?><br />
                                        Department: <?= $pos ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th>Sr. #</th>
                                    <th>Emp. Name</th>
                                    <th>E.S.I. No.</th>
                                    <th>Actual Days Worked</th>
                                    <th style="text-align: right;">Gross Salary (Rs.)</th>
                                    <th style="text-align: right;">ESI @ 4.75%</th>
                                    <th style="text-align: right;">ESI @ 1.75%</th>
                                </tr>
                </thead>
                <tbody>
                            <?php
                            $iter = 1;
                                foreach($result as $a){
                                    ?>
                                    <tr>
                                        <td><?= $iter++ ?></td>
                                        <td><?= $a->name . '['.$a->e_code.']' ?></td>
                                        <td><?= $a->esi_acc_no ?></td>
                                        <td><?= $a->T2 ?></td>
                                        <td style="text-align: right;"><?= $a->GROSS ?></td>
                                        <td style="text-align: right;"><?= floor($a->GROSS * (4.75/100)) ?></td>
                                        <td style="text-align: right;"><?= floor($a->GROSS * (1.75/100)) ?></td>
                                    </tr>
                                    <?php
                                }
                                ?>
                            
                        </tbody>
            </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>

	<?php if($segment == 'payroll_pf' ) {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">P.F. DETAILS</h3>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
                <tr>
                                    <th colspan="5">SHILPA OVERSEAS PVT. LTD. <br /> 51, Mahanirban Road, Kolkata-700029</th>
                                    <th colspan="3">
                                        Month: <?= $mont ?><br />
                                        Date: <?= date('d-m-Y') ?><br />
                                        Department: <?= $pos ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th rowspan="2">Sr. #</th>
                                    <th rowspan="2">Emp. Name</th>
                                    <th rowspan="2">P.F. A/C No.</th>
                                    <th rowspan="2">Actual Days Worked</th>
                                    <th rowspan="2">Bsic + D.A. (Rs.)</th>
                                    <th class="text-center" rowspan="1">Employee</th>
                                    <th class="text-center" colspan="2" rowspan="1">Employer</th>
                                </tr>
                                <tr>
                                    <th rowspan="1" style="text-align: right;">P.F. @ 12%</th>
                                    <th rowspan="1" style="text-align: right;">P.F. @ 8.33%</th>
                                    <th rowspan="1" style="text-align: right;">P.F. @ 3.67%</th>
                                </tr>
                </thead>
                <tbody>
                            <?php
                            $iter = 1;
                                foreach($result as $a){
                                    ?>
                                    <tr>
                                        <td><?= $iter++ ?></td>
                                        <td><?= $a->name . '['.$a->e_code.']' ?></td>
                                        <td><?= $a->pf_acc_no ?></td>
                                        <td><?= $a->T2 ?></td>
                                        <td style="text-align: right;"><?= $a->GROSS ?></td>
                                        <td style="text-align: right;"><?= $val= floor($a->GROSS * (12/100)) ?></td>
                                        <td style="text-align: right;">541</td>
                                        <td style="text-align: right;"><?= ($val - 541) ?></td>
                                    </tr>
                                    <?php
                                }
                                ?>
                            
                        </tbody>
            </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>

<?php if($segment == 'supplier_wise_item_position') {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
                <tr>
                    <th>PUR. #</th>
                    <th style="text-align:center">PUR. DT.</th>
                    <th style="text-align:center">PUR. QNTY.</th>
                    <th style="text-align:center">SUPP. #</th>
                    <th style="text-align:center">SUPP. DT.</th>
                    <th style="text-align:center">SUPP. QNTY.</th>
                    <th style="text-align:center">RCPT. #</th>
                    <th style="text-align:center">RCPT. DT.</th>
                    <th style="text-align:center">RCPT. QNTY.</th>
                    <th style="text-align:center">BAL. QNTY.</th>
                </tr>
                                    </thead>
									<tbody>
				<?php
    $pod_quantity = 0;
    $sup_quantity = 0;
    $rcv_quantity = 0;
    $bal_quantity = 0;
    $tot_pod_quantity = 0;
    $tot_sup_quantity = 0;
    $tot_rcv_quantity = 0;
    $tot_bal_quantity = 0;
    $tot_pod_quantity1 = 0;
    $tot_sup_quantity1 = 0;
    $tot_rcv_quantity1 = 0;
    $tot_bal_quantity1 = 0;
				 foreach ($result as $r) { 

 $query = "SELECT
                                    `purchase_order`.`po_id`,
                                    `purchase_order`.`po_number`,
                                    `purchase_order`.`am_id`,
                                    `purchase_order`.`po_date`,
                                    `acc_master`.`name`,
                                    `purchase_order_details`.`id_id`,
                                    `item_master`.`item`,
                                    `colors`.`color`,
                                    SUM(
                        IFNULL(
                            purchase_order_details.pod_quantity,
                            0
                        )
                    ) AS pod_quantity
                                FROM
                                    `purchase_order_details`
                                LEFT JOIN `purchase_order` ON `purchase_order`.`po_id` = `purchase_order_details`.`po_id`
                                LEFT JOIN `acc_master` ON `purchase_order`.`am_id` = `acc_master`.`am_id`
                                LEFT JOIN `item_dtl` ON `item_dtl`.`id_id` = `purchase_order_details`.`id_id`
                                LEFT JOIN `item_master` ON `item_master`.`im_id` = `item_dtl`.`im_id`
                                LEFT JOIN `colors` ON `colors`.`c_id` = `item_dtl`.`c_id`
                                WHERE
                                    `purchase_order_details`.id_id = $r->id_id AND `purchase_order`.status = 1
                                GROUP BY
                                purchase_order.po_id
                                ORDER BY
                                purchase_order.po_number";

            $purchase_order_details = $this->db->query($query)->result();

				 	?>

				 	<?php 
if(count($purchase_order_details) > 0) {
				 	 ?>						
									<tr>
    <td colspan="10" style="text-align:center"><strong>{<?= $r->item ?>} ({<?= $r->color ?>})</strong></td>
</tr>
            <?php foreach($purchase_order_details as $rc) {
             ?>
<tr>
    <td><?= $rc->po_number ?></td>
     <td><?= date ("d-m-Y", strtotime($rc->po_date)) ?></td>
     <td style="text-align: right;"><?php echo $rc->pod_quantity;
       $tot_pod_quantity += $rc->pod_quantity;
       $tot_pod_quantity1 += $rc->pod_quantity;
      ?></td>
     <td>
             <?php
              $result_sup = $this->db->select('supp_purchase_order.*, supp_purchase_order_detail.id_id')
            ->join('supp_purchase_order', 'supp_purchase_order.sup_id = supp_purchase_order_detail.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.po_id', $rc->po_id)
             ->where('supp_purchase_order.supp_status', '1')
             ->get_where('supp_purchase_order_detail')->result(); ?>
            <?php 
             if(count($result_sup) > 0) {
             	foreach($result_sup as $r_s) {
            echo $r_s->supp_po_number."<br />";
             }} else {
             	echo "<br />";
             }
          ?>
             </td>
             <td>
             <?php
              $result_sup = $this->db->select('supp_purchase_order.*, supp_purchase_order_detail.id_id')
            ->join('supp_purchase_order', 'supp_purchase_order.sup_id = supp_purchase_order_detail.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.po_id', $rc->po_id)
             ->where('supp_purchase_order.supp_status', '1')
             ->get_where('supp_purchase_order_detail')->result(); ?>
            <?php 
             if(count($result_sup) > 0) {
             	foreach($result_sup as $r_s) {
            echo date("d-m-Y", strtotime($r_s->pur_order_date))."<br />";
             }} else {
             	echo "<br />";
             }
          ?>
             </td>
             <td style="text-align: right;">
             <?php
             	$result_sup = $this->db->select('supp_purchase_order.*, supp_purchase_order_detail.id_id')
            ->join('supp_purchase_order_detail', 'supp_purchase_order_detail.sup_id = supp_purchase_order.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.po_id', $rc->po_id)
             ->where('supp_purchase_order.supp_status', '1')
             ->get_where('supp_purchase_order')->row();
             if(count($result_sup) > 0) {
            $result_su = $this->db->select('supp_purchase_order_detail.item_qty')
            ->join('supp_purchase_order', 'supp_purchase_order.sup_id = supp_purchase_order_detail.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.sup_id', $result_sup->sup_id)
             ->where('supp_purchase_order_detail.status', '1')
             // ->group_by('supp_purchase_order_detail.sup_id')
             ->get_where('supp_purchase_order_detail')->result();
             if(count($result_su) > 0) {
             	foreach($result_su as $r_s) {
              ?>
            <?php
            $tot_sup_quantity += $r_s->item_qty;
            $tot_sup_quantity1 += $r_s->item_qty; 
            echo $r_s->item_qty."<br />";
             }}
         } else {
             	echo "<br />";
             } ?>
             </td>



             <td>
             <?php
              $result_rcv = $this->db->select('purchase_order_receive.*, purchase_order_receive_detail.id_id')
            ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
             ->where('purchase_order_receive_detail.id_id', $rc->id_id)
             ->where('purchase_order_receive_detail.po_id', $rc->po_id)
             ->where('purchase_order_receive.status', '1')
             // ->group_by('purchase_order_receive_detail.purchase_order_receive_id')
             ->get_where('purchase_order_receive_detail')->result(); ?>
            <?php if(count($result_rcv) > 0) {
                foreach($result_rcv as $r_r) {
            echo $r_r->purchase_order_receive_bill_no."<br />";
                }
             } else {
             	echo "<br />"; 
             }
         
              ?>
             </td>
             <td>
             <?php
              $result_rcv = $this->db->select('purchase_order_receive.*, purchase_order_receive_detail.id_id')
            ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
             ->where('purchase_order_receive_detail.id_id', $rc->id_id)
             ->where('purchase_order_receive_detail.po_id', $rc->po_id)
             ->where('purchase_order_receive.status', '1')
             // ->group_by('purchase_order_receive_detail.purchase_order_receive_id')
             ->get_where('purchase_order_receive_detail')->result(); ?>
            <?php if(count($result_rcv) > 0) {
                foreach($result_rcv as $r_r) {
            echo date("d-m-Y", strtotime($r_r->purchase_order_receive_date))."<br />";
            }} else {
            echo "<br />"; 	
             }
              ?>
             </td>
             <td style="text-align: right;">
             <?php
            $result_rc = $this->db->select('purchase_order_receive_detail.item_quantity')
            ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
             ->where('purchase_order_receive_detail.id_id', $rc->id_id)
             ->where('purchase_order_receive_detail.po_id', $rc->po_id)
             ->where('purchase_order_receive_detail.status', '1')
             // ->group_by('purchase_order_receive_detail.purchase_order_receive_id')
             ->get('purchase_order_receive_detail')->result();
             	?>
            <?php
            if(count($result_rc)>0) {
                foreach($result_rc as $r_r) {
            $tot_rcv_quantity += $r_r->item_quantity;
            $tot_rcv_quantity1 += $r_r->item_quantity;
             echo $r_r->item_quantity."<br />";
                }} else {
             	echo "<br />";
             }
          ?>
             </td>
             <td style="text-align: right;">
             	<?php
                
                 $result_pu = $this->db->select_sum('purchase_order_details.pod_quantity')
            ->join('purchase_order', 'purchase_order.po_id = purchase_order_details.po_id', 'left')
             ->where('purchase_order_details.id_id', $rc->id_id)
             ->where('purchase_order_details.po_id', $rc->po_id)
             ->where('purchase_order.status', '1')
             ->group_by('purchase_order_details.po_id, purchase_order_details.id_id')
             ->get_where('purchase_order_details')->row(); ?>
            <?php
            if(count($result_pu) > 0) {
            $pod_quantity = $result_pu->pod_quantity;
             } else {
            $pod_quantity = 0;  	
             }
             
             $result_sup = $this->db->select('supp_purchase_order.*, supp_purchase_order_detail.id_id')
            ->join('supp_purchase_order_detail', 'supp_purchase_order_detail.sup_id = supp_purchase_order.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.po_id', $rc->po_id)
             ->where('supp_purchase_order.supp_status', '1')
             ->get_where('supp_purchase_order')->row();
             if(count($result_sup) > 0) {
            $result_su = $this->db->select_sum('supp_purchase_order_detail.item_qty')
            ->join('supp_purchase_order', 'supp_purchase_order.sup_id = supp_purchase_order_detail.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.sup_id', $result_sup->sup_id)
             ->where('supp_purchase_order_detail.status', '1')
             ->group_by('supp_purchase_order.po_id, supp_purchase_order_detail.id_id')
             ->get_where('supp_purchase_order_detail')->row();
             if(count($result_su) > 0) {
              ?>
            <?php
            $sup_quantity = $result_su->item_qty;
             }
         } else {
             	$sup_quantity = 0;
             }
             
             $result_rc = $this->db->select_sum('purchase_order_receive_detail.item_quantity')
            ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
             ->where('purchase_order_receive_detail.id_id', $rc->id_id)
             ->where('purchase_order_receive_detail.po_id', $rc->po_id)
             ->where('purchase_order_receive_detail.status', '1')
             ->group_by('purchase_order_receive_detail.po_id, purchase_order_receive_detail.id_id')
             ->get('purchase_order_receive_detail')->row();
             	?>
            <?php
            if(count($result_rc) > 0) {
            $rcv_quantity = $result_rc->item_quantity;
             } else {
             	$rcv_quantity = 0;
             }
             	?>
            <?php
            $bal_quantity = (($pod_quantity + $sup_quantity) - $rcv_quantity);
            $tot_bal_quantity += $bal_quantity;
            $tot_bal_quantity1 += $bal_quantity;
             echo $bal_quantity."<br />";
              ?>
             </td>
         </tr>
     <?php } ?>
 </tr>
 <tr style="background: #d4ecea;">
 	<th colspan="2">Total</th>
 	<td style="text-align: right;"><?php echo $tot_pod_quantity;
     $tot_pod_quantity = 0;
 	 ?></td>
 	<td colspan="3" style="text-align: right;"><?php echo $tot_sup_quantity; 
     $tot_sup_quantity = 0;
 	?></td>
 	<td colspan="3" style="text-align: right;"><?php echo $tot_rcv_quantity;
     $tot_rcv_quantity = 0;
 	 ?></td>
 	<td style="text-align: right;"><?php echo $tot_bal_quantity;
     $tot_bal_quantity = 0;
 	 ?></td>
 </tr>
                <?php }} ?>
                <tr style="background: #445767; color: white;">
 	<th colspan="2">Grand Total</th>
 	<td style="text-align: right;"><?php echo $tot_pod_quantity1;
 	 ?></td>
 	<td colspan="3" style="text-align: right;"><?php echo $tot_sup_quantity1; 
 	?></td>
 	<td colspan="3" style="text-align: right;"><?php echo $tot_rcv_quantity1;
 	 ?></td>
 	<td style="text-align: right;"><?php echo $tot_bal_quantity1;
 	 ?></td>
 </tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>
	</div>
	<div class="A4 landscape" id="page-content">

	<?php if($segment == 'order_summary'){
		// echo '<pre>',print_r($result),'</pre>';
		$temp_co_name_array = array();
		foreach($result as $co_name) {
			if(!in_array($co_name->co_no, $temp_co_name_array)){
				array_push($temp_co_name_array, $co_name->co_no);
			}
		}
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">Order Status Details</h3>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">Customer Order Number :
						<br />
						<?= implode(', ', $temp_co_name_array) ?>
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered order-summary">
									<thead>
										<tr>
											<th rowspan="2">Order No.</th>
											<th rowspan="2">Article</th>
											<th rowspan="2">Ord Qnty</th>
											<th colspan="2" class="text-center">Cutting Information</th>
											<th colspan="2" class="text-center">Skiving Information</th>
											<th colspan="2" class="text-center">Fabricator Information</th>
											<th rowspan="2" class="text-center">Shipping Information</th>
										</tr>
										<tr>
											<th>Cut Issue</th>
											<th>Cut Rcv.</th>
											<th>Skiv Issue</th>
											<th>Skiv Rcv.</th>
											<th>Fab Issue</th>
											<th>Fab Rcv.</th>
										</tr>
									</thead>
									<tbody>
										<?php 
										$sub_co = 0;
										$sub_ci = 0;
										$sub_cr = 0;
										$sub_sr = 0;
										$sub_ji = 0;
										$sub_jr = 0;
										$sub_shp = 0;

										$grand_co = 0;
										$grand_ci = 0;
										$grand_cr = 0;
										$grand_sr = 0;
										$grand_ji = 0;
										$grand_jr = 0;
										$grand_shp = 0;

										$summary_co_names[] = '';
										$summary_co_iter=1;

										// $last_co_qnty[] = '';
										foreach ($result as $res) {

											if(!in_array($res->co_no, $summary_co_names)){
												array_push($summary_co_names, $res->co_no);
												if($summary_co_iter++ == 1){
														// continue;
													}else{
														?>
													<tr style="background-color: #d9e2ea;">
														<th colspan="2">Total</th>
														<th class="text-right">
															<?php 
																echo abs($sub_co - $grand_co);
																$sub_co = $grand_co; 
																// array_push($last_co_qnty, var)
															?>
														</th>
														<th class="text-right">
															<?php 
																echo abs($sub_ci - $grand_ci);
																$sub_ci = $grand_ci; 
															?>
														</th>
														<th class="text-right">
															<?php 
																echo abs($sub_cr - $grand_cr);
																// $sub_cr = $grand_cr; 
															?>
														</th>
														<th class="text-right">
															<?php 
																echo abs($sub_cr - $grand_cr);
																$sub_cr = $grand_cr; 
															?>
														</th>
														<th class="text-right">
															<?php 
																echo abs($sub_sr - $grand_sr);
																$sub_sr = $grand_sr; 
															?>
														</th>
														<th class="text-right">
															<?php 
																echo abs($sub_ji - $grand_ji);
																$sub_ji = $grand_ji; 
															?>
														</th>
														<th class="text-right">
															<?php 
																echo abs($sub_jr - $grand_jr);
																$sub_jr = $grand_jr; 
															?>
														</th>
														<th class="text-right">
															<?php 
																echo abs($sub_shp - $grand_shp);
																$sub_shp = $grand_shp; 
															?>
														</th>
													</tr>
														<?php
													}
											}
											?>
											<tr>
												<th height="60" nowrap style="font-size: 12px"><?= $res->co_no ?></th>
												<td height="60" nowrap style="font-size: 12px"><?= $res->art_no .' ['.$res->color.']' ?></td>
												<td height="60" nowrap class="text-right">
													<?php 
														echo $res->co_quantity; 
														$grand_co += $res->co_quantity;
													?>
												</td>
												<td height="60" nowrap class="">
													<?php 
													echo $res->ci .'<span>'.$res->cut_co_quantity.'</span>';
													$grand_ci += $res->cut_co_quantity;
													?>	 	
												</td>
												<td height="60" nowrap class="">
													<?php 
													echo $res->cr .'<span>'.$res->receive_cut_quantity.'</span>'; 
													$grand_cr += $res->receive_cut_quantity;
													?>
													<br><br>
												</td>
												<td height="60" nowrap class="">
													<?php echo $res->cr .'<span>'.$res->receive_cut_quantity.'</span>'; ?></td>
												<td height="60" nowrap class="">
													<?php
													echo $res->sr .'<span>'.$res->receive_quantity.'</span>';
													$grand_sr += $res->receive_quantity;
													?>
													<br><br>
												</td>

												<td height="60" nowrap class="">
													<?php 
													echo $res->jobi .'<span>'.$res->jobber_issue_quantity.'</span>';
													$grand_ji += $res->jobber_issue_quantity;
													 ?>
													 <br><br>
													</td>
												<td height="60" nowrap class="">
													<?php echo $res->jobr .'<span>'.$res->jobber_receive_quantity.'</span>'; 
													$grand_jr += $res->jobber_receive_quantity;
													?>
													<br><br>
												</td>

												<td height="60" nowrap class="">
													<?php echo $res->ship .'<span>'.$res->total_quantity.'</span>'; 
													$grand_shp += $res->ship;
													?>
												</td>
												
											</tr>
											<?php
										} 
										if(end($result)){
											?>
											<tr style="background-color: #d9e2ea;">
												<th colspan="2">Total</th>
												<th class="text-right"><?= $grand_co - $sub_co ?></th>
												<th class="text-right"><?= $grand_ci - $sub_ci ?></th>
												<th class="text-right"><?= $grand_cr - $sub_cr ?></th>
												<th class="text-right"><?= $grand_cr - $sub_cr ?></th>
												<th class="text-right"><?= $grand_sr - $sub_sr ?></th>
												<th class="text-right"><?= $grand_ji - $sub_ji ?></th>
												<th class="text-right"><?= $grand_jr - $sub_jr ?></th>
												<th class="text-right"><?= $grand_shp - $sub_shp ?></th>
											</tr>
											<?php
										}
										?>
										<tr style="background-color: #445767;color: white;">
											<th colspan="2">Grand Total</th>
											<th class="text-right"><?= $grand_co ?></th>
											<th class="text-right"><?=$grand_ci?></th>
											<th class="text-right"><?=$grand_cr?></th>
											<th class="text-right"><?= $grand_cr ?></th>
											<th class="text-right"><?=$grand_sr?></th>
											<th class="text-right"><?=$grand_ji?></th>
											<th class="text-right"><?=$grand_jr?></th>
											<th class="text-right"><?=$grand_shp?></th>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>
	</div>
	<div class="A4" id="page-content">

	<?php if($segment == 'jobber_ledger_status_report'){
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">JOBBER LEDGER (ZERO)</h3>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class="mar_0"><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
					    <h4 class="mar_0"><?= $result[0]->name ?></h4>
						<p class="mar_0"><?= $result[0]->address ?></p>
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
										<tr>
										    <th rowspan="2">Article</th>
											<th rowspan="2">Order No.</th>
											<th>Issue Challan</th>
											<th>Issue Date</th>
											<th style="text-align: right;">Issue Qnty.</th>
											<th>Rcpt. Name</th>
											<th>Rcpt. Date</th>
											<th style="text-align: right;">Rcpt. Qnty</th>
											<th style="text-align: right;">Bal Qnty</th>
										</tr>
									</thead>
									<tbody>
										<?php 
										// $last_co_qnty[] = '';
										$total_jobber_issue = 0;
										$total_jobber_receive = 0;
										$total_balance = 0;
										foreach ($result as $res) {
											if($res->jobber_issue_quantity == 0) {
												continue;
											}
								// 			if(($res->jobber_issue_quantity - $res->jobber_receive_quantity) != 0) {
								// 				continue;
								// 			}
											?>
											<tr>
											    <td style="font-size: 12px"><?= $res->art_no .' ['.$res->color.']' ?></td>
												<td style="font-size: 12px"><?= $res->co_no ?></td>
												<td class="">
													<?php 
													echo $res->jobber_challan_number;
													 ?>
													</td>
													<td nowrap class="">
													<?php 
													echo $res->jobber_issue_date;
													 ?>
													</td>
													<td class="" style="text-align: right;">
													<?php 
													echo $res->jobber_issue_quantity;
													$total_jobber_issue += $res->jobber_issue_quantity;
													 ?>
													</td>
												<td class="">
													<?php echo $res->jobr_challan;
													?>
												</td>
												<td nowrap class="">
													<?php 
													if($res->jobr_challan_date != '') {
													echo $res->jobr_challan_date;
												} else {
													echo '';
												}
													?>
												</td>
												<td class="" style="text-align: right;">
													<?php 
													echo $res->jobr_challan_receive_quantity;
													$total_jobber_receive += $res->jobber_receive_quantity;
													?>
												</td>

												<td class="" style="text-align: right;">
													<?php 
                                                    $balance_quantity = ($res->jobber_issue_quantity - $res->jobber_receive_quantity);
													echo $balance_quantity;
													$total_balance += $balance_quantity;
													?>
												</td>
												
											</tr>
											<?php
										} 
										?>
										<tr>
										    <th colspan="4">Total</th>
										    <th style="text-align: right;"><?= $total_jobber_issue ?></th>
										    <th></th>
										    <th></th>
										    <th style="text-align: right;"><?= $total_jobber_receive ?></th>
										    <th style="text-align: right;"><?= $total_balance ?></th>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>
	<?php if($segment == 'jobber_ledger_status_report_non_zero'){
		?>
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">JOBBER LEDGER (NON-ZERO)</h3>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class="mar_0"><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
					    <h4 class="mar_0"><?= $result[0]->name ?></h4>
						<p class="mar_0"><?= $result[0]->address ?></p>
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
										<tr>
										    <th rowspan="2">Article</th>
											<th rowspan="2">Order No.</th>
											<th>Issue Challan</th>
											<th>Issue Date</th>
											<th style="text-align: right;">Issue Qnty.</th>
											<th>Rcpt. Name</th>
											<th>Rcpt. Date</th>
											<th style="text-align: right;">Rcpt. Qnty</th>
											<th style="text-align: right;">Bal Qnty</th>
										</tr>
									</thead>
									<tbody>
										<?php 
										// $last_co_qnty[] = '';
										$total_jobber_issue = 0;
										$total_jobber_receive = 0;
										$total_balance = 0;
										foreach ($result as $res) {
											if($res->jobber_issue_quantity == 0) {
												continue;
											}
											if(($res->jobber_issue_quantity - $res->jobber_receive_quantity) == 0) {
												continue;
											}
											?>
											<tr>
											    <td style="font-size: 12px"><?= $res->art_no .' ['.$res->color.']' ?></td>
												<td style="font-size: 12px"><?= $res->co_no ?></td>
												<td class="">
													<?php 
													echo $res->jobber_challan_number;
													 ?>
													</td>
													<td nowrap class="">
													<?php 
													echo $res->jobber_issue_date;
													 ?>
													</td>
													<td class="" style="text-align: right;">
													<?php 
													echo $res->jobber_issue_quantity;
													$total_jobber_issue += $res->jobber_issue_quantity;
													 ?>
													</td>
												<td class="">
													<?php echo $res->jobr_challan;
													?>
												</td>
												<td nowrap class="">
													<?php 
													if($res->jobr_challan_date != '') {
													echo $res->jobr_challan_date;
												} else {
													echo '';
												}
													?>
												</td>
												<td class="" style="text-align: right;">
													<?php 
													echo $res->jobr_challan_receive_quantity;
													$total_jobber_receive += $res->jobber_receive_quantity;
													?>
												</td>

												<td class="" style="text-align: right;">
													<?php 
                                                    $balance_quantity = ($res->jobber_issue_quantity - $res->jobber_receive_quantity);
													echo $balance_quantity;
													$total_balance += $balance_quantity;
													?>
												</td>
												
											</tr>
											<?php
										} 
										?>
										<tr>
										    <th colspan="4">Total</th>
										    <th style="text-align: right;"><?= $total_jobber_issue ?></th>
										    <th></th>
										    <th></th>
										    <th style="text-align: right;"><?= $total_jobber_receive ?></th>
										    <th style="text-align: right;"><?= $total_balance ?></th>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		<?php
	} ?>
	</div>
</body>

<?php if($segment == 'supplier_wise_purchase_position') {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<style>
			@media print{@page {size: landscape}}
			.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    padding: 5px;
    text-align: left;
    font-size: 12px;
}
		</style>
		<body class="A3 landscape" style="overflow-x: auto; padding-top: 20px">
        <div id="page-content">
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
                <tr>
                    <th style="text-align:center">SUPPLIER NAME</th>
                    <th style="text-align:center">P.O. #</th>
                    <th style="text-align:center">PUR. DT.</th>
                    <th style="text-align:center">ITEM NAME</th>
                    <th style="text-align:center">PUR. QNTY.</th>
                    <th style="text-align:center">SUPP. #</th>
                    <th style="text-align:center">SUPP. DT.</th>
                    <th style="text-align:center">SUPP. QNTY.</th>
                    <th style="text-align:center">RCPT. #</th>
                    <th style="text-align:center">RCPT. DT.</th>
                    <th style="text-align:center">RCPT. QNTY.</th>
                    <th style="text-align:center">BAL. QNTY.</th>
                </tr>
                                    </thead>
									<tbody>
				<?php 
    $pod_quantity = 0;
    $sup_quantity = 0;
    $rcv_quantity = 0;
    $bal_quantity = 0;
    $tot_pod_quantity = 0;
    $tot_sup_quantity = 0;
    $tot_rcv_quantity = 0;
    $tot_bal_quantity = 0;
				foreach ($result as $rc) { ?>						
									<tr>
    <td style="text-align:center"><?= $rc->name ?></td>
     <td><?= $rc->po_number ?></td>
     <td><?= date ("d-m-Y", strtotime($rc->po_date)) ?></td>
     <td><?= $rc->item ?> [<?= $rc->color ?>] </td>
     <td style="text-align: right;"><?= $rc->pod_quantity ?></td>
     <td>
             <?php
              $result_sup = $this->db->select('supp_purchase_order.*, supp_purchase_order_detail.id_id')
            ->join('supp_purchase_order', 'supp_purchase_order.sup_id = supp_purchase_order_detail.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.po_id', $rc->po_id)
             ->where('supp_purchase_order.supp_status', '1')
             ->get_where('supp_purchase_order_detail')->result(); ?>
            <?php 
             if(count($result_sup) > 0) {
             	foreach($result_sup as $r_s) {
            echo $r_s->supp_po_number."<br />";
             }} else {
             	echo "<br />";
             }
          ?>
             </td>
             <td>
             <?php
              $result_sup = $this->db->select('supp_purchase_order.*, supp_purchase_order_detail.id_id')
            ->join('supp_purchase_order', 'supp_purchase_order.sup_id = supp_purchase_order_detail.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.po_id', $rc->po_id)
             ->where('supp_purchase_order.supp_status', '1')
             ->get_where('supp_purchase_order_detail')->result(); ?>
            <?php 
             if(count($result_sup) > 0) {
             	foreach($result_sup as $r_s) {
            echo date("d-m-Y", strtotime($r_s->pur_order_date))."<br />";
             }} else {
             	echo "<br />";
             }
          ?>
             </td>
             <td style="text-align: right;">
             <?php
             	$result_sup = $this->db->select('supp_purchase_order.*, supp_purchase_order_detail.id_id')
            ->join('supp_purchase_order_detail', 'supp_purchase_order_detail.sup_id = supp_purchase_order.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.po_id', $rc->po_id)
             ->where('supp_purchase_order.supp_status', '1')
             ->get_where('supp_purchase_order')->row();
             if(count($result_sup) > 0) {
            $result_su = $this->db->select('supp_purchase_order_detail.item_qty')
            ->join('supp_purchase_order', 'supp_purchase_order.sup_id = supp_purchase_order_detail.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.sup_id', $result_sup->sup_id)
             ->where('supp_purchase_order_detail.status', '1')
             // ->group_by('supp_purchase_order_detail.sup_id')
             ->get_where('supp_purchase_order_detail')->result();
             if(count($result_su) > 0) {
             	foreach($result_su as $r_s) {
              ?>
            <?php
            $tot_sup_quantity += $r_s->item_qty; 
            echo $r_s->item_qty."<br />";
             }}
         } else {
             	echo "<br />";
             } ?>
             </td>



             <td>
             <?php
              $result_rcv = $this->db->select('purchase_order_receive.*, purchase_order_receive_detail.id_id')
            ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
             ->where('purchase_order_receive_detail.id_id', $rc->id_id)
             ->where('purchase_order_receive_detail.po_id', $rc->po_id)
             ->where('purchase_order_receive.status', '1')
             // ->group_by('purchase_order_receive_detail.purchase_order_receive_id')
             ->get_where('purchase_order_receive_detail')->result(); ?>
            <?php if(count($result_rcv) > 0) {
                foreach($result_rcv as $r_r) {
            echo $r_r->purchase_order_receive_bill_no."<br />";
                }
             } else {
             	echo "<br />"; 
             }
         
              ?>
             </td>
             <td>
             <?php
              $result_rcv = $this->db->select('purchase_order_receive.*, purchase_order_receive_detail.id_id')
            ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
             ->where('purchase_order_receive_detail.id_id', $rc->id_id)
             ->where('purchase_order_receive_detail.po_id', $rc->po_id)
             ->where('purchase_order_receive.status', '1')
             // ->group_by('purchase_order_receive_detail.purchase_order_receive_id')
             ->get_where('purchase_order_receive_detail')->result(); ?>
            <?php if(count($result_rcv) > 0) {
                foreach($result_rcv as $r_r) {
            echo date("d-m-Y", strtotime($r_r->purchase_order_receive_date))."<br />";
            }} else {
            echo "<br />"; 	
             }
              ?>
             </td>
             <td style="text-align: right;">
             <?php
            $result_rc = $this->db->select('purchase_order_receive_detail.item_quantity')
            ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
             ->where('purchase_order_receive_detail.id_id', $rc->id_id)
             ->where('purchase_order_receive_detail.po_id', $rc->po_id)
             ->where('purchase_order_receive_detail.status', '1')
             // ->group_by('purchase_order_receive_detail.purchase_order_receive_id')
             ->get('purchase_order_receive_detail')->result();
             	?>
            <?php
            if(count($result_rc)>0) {
                foreach($result_rc as $r_r) {
            $tot_rcv_quantity += $r_r->item_quantity;
             echo $r_r->item_quantity."<br />";
                }} else {
             	echo "<br />";
             }
          ?>
             </td>
             <td style="text-align: right;">
             	<?php
                
                 $result_pu = $this->db->select_sum('purchase_order_details.pod_quantity')
            ->join('purchase_order', 'purchase_order.po_id = purchase_order_details.po_id', 'left')
             ->where('purchase_order_details.id_id', $rc->id_id)
             ->where('purchase_order_details.po_id', $rc->po_id)
             ->where('purchase_order.status', '1')
             ->group_by('purchase_order_details.po_id, purchase_order_details.id_id')
             ->get_where('purchase_order_details')->row(); ?>
            <?php
            if(count($result_pu) > 0) {
            $pod_quantity = $result_pu->pod_quantity;
             } else {
            $pod_quantity = 0;  	
             }
             
             $result_sup = $this->db->select('supp_purchase_order.*, supp_purchase_order_detail.id_id')
            ->join('supp_purchase_order_detail', 'supp_purchase_order_detail.sup_id = supp_purchase_order.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.po_id', $rc->po_id)
             ->where('supp_purchase_order.supp_status', '1')
             ->get_where('supp_purchase_order')->row();
             if(count($result_sup) > 0) {
            $result_su = $this->db->select_sum('supp_purchase_order_detail.item_qty')
            ->join('supp_purchase_order', 'supp_purchase_order.sup_id = supp_purchase_order_detail.sup_id', 'left')
             ->where('supp_purchase_order_detail.id_id', $rc->id_id)
             ->where('supp_purchase_order.sup_id', $result_sup->sup_id)
             ->where('supp_purchase_order_detail.status', '1')
             ->group_by('supp_purchase_order.po_id, supp_purchase_order_detail.id_id')
             ->get_where('supp_purchase_order_detail')->row();
             if(count($result_su) > 0) {
              ?>
            <?php
            $sup_quantity = $result_su->item_qty;
             }
         } else {
             	$sup_quantity = 0;
             }
             
             $result_rc = $this->db->select_sum('purchase_order_receive_detail.item_quantity')
            ->join('purchase_order_receive', 'purchase_order_receive.purchase_order_receive_id = purchase_order_receive_detail.purchase_order_receive_id', 'left')
             ->where('purchase_order_receive_detail.id_id', $rc->id_id)
             ->where('purchase_order_receive_detail.po_id', $rc->po_id)
             ->where('purchase_order_receive_detail.status', '1')
             ->group_by('purchase_order_receive_detail.po_id, purchase_order_receive_detail.id_id')
             ->get('purchase_order_receive_detail')->row();
             	?>
            <?php
            if(count($result_rc) > 0) {
            $rcv_quantity = $result_rc->item_quantity;
             } else {
             	$rcv_quantity = 0;
             }
             	?>
            <?php
            $bal_quantity = (($pod_quantity + $sup_quantity) - $rcv_quantity);
            $tot_bal_quantity += $bal_quantity;
             echo $bal_quantity."<br />";
              ?>
             </td>
</tr>
           <?php } ?>	
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
</body>
		<?php
	} ?>

<?php if($segment == 'checking_entry_sheet_status'){
		// echo '<pre>',print_r($result),'</pre>';

		?>
		<style>
			@media print{@page {size: landscape}}
			.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    padding: 5px;
    text-align: left;
    font-size: 12px;
}
		</style>
		<body class="A3 landscape" style="overflow-x: auto; padding-top: 20px">
        <div id="page-content">
		<section class="sheet padding-5mm" style="overflow-x: auto; padding-top: 20px" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">Checking Entry Sheet Status </h3>
				</div>
				<div class="row mar_bot_3 text-center">
					<div class="col-sm-12 border_all header_left" style="height: 44px;">
						<h4 class="" style="margin-top: 2px; margin-bottom: 0px;"><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
										<tr>
									    <th rowspan="3" style="width: 2%;">Order No.</th>
                                        <th rowspan="3" style="width: 3%;">Article</th>
                                        <th rowspan="3" style="width: 2%;">Colour</th>
                                        <th rowspan="3" style="width: 2%;">Ord. Qnty.</th>
                            			<th>Date</th>
                            			<?php 
$dates = array();
      $current = strtotime($from);
      $date2 = strtotime($to);
      $stepVal = '+1 day';
      while( $current <= $date2 ) {
         $dates[] = date('d-m', $current);
         $current = strtotime($stepVal, $current);
      }
   foreach($dates as $d) {
                            			 ?>
<th style="width: 2%;"><?= $d ?></th>
                            			 <?php 
}
                            			  ?>
										<tr>
                            			<th style="width: 2%;">Emp. Name</th>
                            			<?php
                            			foreach($dates as $d) {
                            			 ?>
<th>Qty</th>
                            			 <?php 
}
                            			  ?>
										</tr>
										<tr>
                            			<th style="width: 2%;">Extra. Time</th>
                            			<?php
                            			foreach($dates as $d) {
                            			 ?>
<th></th>
                            			 <?php 
}
                            			  ?>
										</tr>
									</thead>
									<tbody>
										<?php 
                                        $iter = 0;
                                        $i1 = 3;
										foreach ($result as $res) {
											if($iter == 2 or $iter == $i1) {
												$i1 = $iter+2;
											?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
</body>
<body class="A3 landscape" style="overflow-x: auto; padding-top: 20px">
        <div id="page-content">
		<section class="sheet padding-5mm" style="overflow-x: auto; padding-top: 20px" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">Checking Entry Sheet Status </h3>
				</div>
				<div class="row mar_bot_3 text-center">
					<div class="col-sm-12 border_all header_left" style="height: 44px;">
						<h4 class="" style="margin-top: 2px; margin-bottom: 0px;"><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
										<tr>
									    <th rowspan="3" style="width: 2%;">Order No.</th>
                                        <th rowspan="3" style="width: 3%;">Article</th>
                                        <th rowspan="3" style="width: 2%;">Colour</th>
                                        <th rowspan="3" style="width: 2%;">Ord. Qnty.</th>
                            			<th>Date</th>
                            			<?php 
   foreach($dates as $d) {
                            			 ?>
<th style="width: 2%;"><?= $d ?></th>
                            			 <?php 
}
                            			  ?>
										<tr>
                            			<th style="width: 2%;">Emp. Name</th>
                            			<?php
                            			foreach($dates as $d) {
                            			 ?>
<th>Qty</th>
                            			 <?php 
}
                            			  ?>
										</tr>
										<tr>
                            			<th style="width: 2%;">Extra. Time</th>
                            			<?php
                            			foreach($dates as $d) {
                            			 ?>
<th></th>
                            			 <?php 
}
                            			  ?>
										</tr>
									</thead>
									<tbody>
									    <?php }
                            $iter++;
									     ?>
                                        <?php
        $result_emp = $this->db->select('departments.department, employees.name')
                         ->join('departments', 'departments.d_id=employees.d_id', 'left')
                         ->join('article_groups', 'article_groups.d_id=departments.d_id', 'left')
                         ->order_by('employees.name')
                         ->get_where('employees', array('article_groups.ag_id' => $res->ag_id))->result();
        $count_emp = count($result_emp);
        $i = 0;                  
                                         ?>
                                         <?php 
                    foreach($result_emp as $r_e) {
                    	$i++;
                                          ?>
											<tr>
												<?php 
                                if($i == 1) {
												 ?>
                                          <td rowspan="<?= $count_emp ?>" style="width: 2%;"><?= $res->co_no ?></td>
                                                <td rowspan="<?= $count_emp ?>" style="width: 3%;"><?= $res->art_no . '<br/>(' . $res->info . ')' ?></td>
                                                <td rowspan="<?= $count_emp ?>" style="width: 2%;"><?= $res->aricle_color ?></td>
                                                <td rowspan="<?= $count_emp ?>" style="width: 2%;"><?= $res->final_qnty ?></td>
                                                 <?php 
                                                }
                                                  ?>
                            <td style="width: 2%;">
                            	<?= $r_e->name ?>
                            </td>
                            <?php
                            			foreach($dates as $d) {
                            			 ?>
                            			 <td style="width: 2%;"></td>
                            			 <?php 
}
                            			  ?>
											</tr>
                                          <?php 
                            }
                            $count_emp = 0;
                            $i = 0;
                                           ?>
											<?php
										} ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
</body>
		<?php
	} ?>

<?php if($segment == 'payroll_register' ) {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<style>
			@media print{@page {size: landscape}}
			.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    padding: 5px;
    text-align: left;
    font-size: 12px;
}
		</style>
		<body class="A3 landscape" style="overflow-x: auto; padding-top: 20px">
        <div id="page-content">
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<div class="container">
				<div class="row border_all text-center text-uppercase mar_bot_3">
					<h3 class="mar_0 head_font">PAYROLL REGISTER</h3>
				</div>
				<div class="row mar_bot_3">
					<div class="col-sm-6 border_all header_left">
						<h4 class=""><strong>SHILPA OVERSEAS PVT. LTD. </strong></h4>
						<p class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</p>
					</div>
					<div class="col-sm-6 border_all header_right">
						<br />
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
									<thead>
                <tr>
                                    <th class="text-center" align="center" colspan="26">REGISTER OF WAGES <br /> [Prescribed under Rule 23(1) of the West Bengal Minimum Wages Rules 1951] <br /> [Prescribed under Rule 26(1) of the Central Minimum Wages Rules 1951]</th>
                                </tr>
                                <tr>
                                    <th colspan="22">SHILPA OVERSEAS PVT. LTD. <br /> 51, Mahanirban Road, Kolkata-700029</th>
                                    <th colspan="4">
                                        Month: <?= $mont ?><br />
                                        Date: <?= date('d-m-Y') ?><br />
                                        Department: <?= $pos ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th rowspan="2">Sr. #</th>
                                    <th rowspan="2">Name</th>
                                    <th rowspan="2">Working Days</th>
                                    <th rowspan="2">Days Worked</th>
                                    <th rowspan="2">Holidays</th>
                                    <th rowspan="2">Leave</th>
                                    <th rowspan="2">Absent</th>
                                    <th class="text-center" rowspan="1" colspan="3">Salary / Wages Scale</th>
                                    <th class="text-center" rowspan="1" colspan="3">Salary / Wages Paid</th>
                                    <th rowspan="2">HRA</th>
                                    <th rowspan="2">Conv. Allowance</th>
                                    <th rowspan="2">Med. Allowance</th>
                                    <th rowspan="2">Other Allowance</th>
                                    <th rowspan="2">Gorss Salary/Wages Paid</th>
                                    <th class="text-center" rowspan="1" colspan="6">Deductions</th>
                                    <th rowspan="2">Salary / Wages Paid</th>
                                    <th rowspan="2">Signature / Thumb Impression</th>
                                </tr>
                                <tr>
                                    <th rowspan="1">Basic</th>
                                    <th rowspan="1">D.A.</th>
                                    <th rowspan="1">Total</th>
                                    <th rowspan="1">Basic</th>
                                    <th rowspan="1">D.A.</th>
                                    <th rowspan="1">Total</th>
                                    <th rowspan="1">P.F.</th>
                                    <th rowspan="1">E.S.I.</th>
                                    <th rowspan="1">WB. PR TAX</th>
                                    <th rowspan="1">L.I.C./T.D.S.</th>
                                    <th rowspan="1">Loan/Advance</th>
                                    <th rowspan="1">Total</th>
                                </tr>
                </thead>
                <tbody>
                            <?php
                                $iter=1;
                                $total_BASIC1 = 0;
                                $total_DA1 = 0;
                                $total_TOTAL1 = 0;
                                $total_TOTAL2 = 0;
                                $total_DA2 = 0;
                                $total_TOTAL22 = 0;
                                $total_HRA = 0;
                                $total_CONV = 0;
                                $total_MED = 0;
                                $total_OA = 0;
                                $total_GROSS = 0;
                                $total_PFAMT = 0;
                                $total_ESIAMT = 0;
                                $total_TAX = 0;
                                $total_INS = 0;
                                $total_LOAN = 0;
                                $total_DEDUC = 0;
                                $total_NET = 0;
                                foreach($result as $r){
                                    ?>
                                    <tr>
                                        <td><?= $iter++ ?></td>
                                        <td nowrap class="text-left"><?= $r->name ?></td>
                                        <td><?= $r->T1 ?></td>
                                        <td><?= $r->T2 ?></td>
                                        <td><?= $r->T3 ?></td>
                                        <td><?= $r->T ?></td>
                                        <td><?= $r->T7 ?></td>
                                        <td style="text-align: right;"><?php echo $r->BASIC1;
                                        $total_BASIC1 += $r->BASIC1;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->DA1;
                                        $total_DA1 += $r->DA1;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->TOTAL1;
                                        $total_TOTAL1 += $r->TOTAL1;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->TOTAL2;
                                        $total_TOTAL2 += $r->TOTAL1;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->DA2;
                                        $total_DA2 += $r->DA2;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->TOTAL2;
                                        $total_TOTAL22 += $r->TOTAL2;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->HRA;
                                        $total_HRA += $r->HRA;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->CONV;
                                        $total_CONV += $r->CONV;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->MED;
                                        $total_MED += $r->MED;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->OA;
                                        $total_OA += $r->OA;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->GROSS;
                                        $total_GROSS += $r->GROSS;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->PFAMT;
                                        $total_PFAMT += $r->PFAMT;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->ESIAMT;
                                        $total_ESIAMT += $r->ESIAMT;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->TAX;
                                        $total_TAX += $r->TAX;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->INS;
                                        $total_INS += $r->INS;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->LOAN;
                                        $total_LOAN += $r->LOAN;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->DEDUC;
                                        $total_DEDUC += $r->DEDUC;
                                        ?></td>
                                        <td style="text-align: right;"><?php echo $r->NET;
                                        $total_NET += $r->NET;
                                        ?></td>
                                        <td style="text-align: right;"></td>
                                    </tr>
                                    <?php
                                }
                                ?>
                                    <tr>
                                        <th colspan="7">Total</th>
                                        <th style="text-align: right;"><?php echo
                                        $total_BASIC1;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_DA1;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_TOTAL1;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_TOTAL2;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_DA2;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_TOTAL22;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_HRA;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_CONV;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_MED;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_OA;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_GROSS;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_PFAMT;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_ESIAMT;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_TAX;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_INS;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_LOAN;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_DEDUC;
                                        ?></th>
                                        <th style="text-align: right;"><?php echo
                                        $total_NET;
                                        ?></th>
                                        <th style="text-align: right;"></th>
                                    </tr>
                        </tbody>
            </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
</body>
		<?php
	} ?>
	
	<?php if($segment == 'emp_pay_slip_section' ) {
		// echo '<pre>',print_r($result),'</pre>';
		?>
		<style>
			@media print{@page {size: landscape}}
			.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    padding: 5px;
    text-align: left;
    font-size: 12px;
}
		</style>
		<body class="A3 landscape" style="overflow-x: auto; padding-top: 20px">
        <div id="page-content">
		<section class="sheet padding-5mm" style="height: auto">
		<div>
			<!--<header class="pull-right">-->
			<!--    <small>Page No. </small>-->
			<!--</header>-->
			<div class="clearfix"></div>
			<?php if(isset($resultss)) {
		    foreach($resultss as $results) {
		        foreach($results as $result) {
			?>
			<div class="container">
				<div class="row mar_bot_3">
					<div class="col-sm-12 border_all text-center">
						<h4 class="mar_0">SHILPA OVERSEAS PVT. LTD.</h4>
						<h4 class="mar_0">KAIKHALI, CHIRIAMORE,P.O. : R.GOPALPUR, KOLKATA - 700 136</h4>
						<h4 class="mar_0">PAY SLIP FOR THE MONTH OF <?= $month ?></h4>
					</div>
				</div>
				<!--table data-->
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="table-responsive">
								<!--<h5>Retrieve Table</h5>-->
								<table id="all_det" class="table table-bordered">
							    <tbody>
                                <tr>
                                    <th style="text-align: center;">NAME OF EMPLOYEE- এমপলয়ী নাম</th>
                                    <th colspan="2" style="text-align: center;">RATE OF SALARY স্যালারি রেট </th>
                                    <th colspan="7" style="text-align: center;">SALARY EARNED</th>
                                    <th rowspan="2" style="text-align: center;">NET PAY</th>
                                    <th rowspan="3" style="text-align: center;">
                                        SIGNATURE OF THE <br/> EMPLOYERS <br/> 
                                        (WITH OFFICE SEAL)
                                    </th>
                                </tr>
                                <tr>
                                    <td><b><?= $result->name ?></b></td>
                                    <td><b>BASIC</b></td>
                                    <td><b><?= $result->BASIC ?></b></td>
                                    <td>BASIC</td>
                                    <td>CONV</td>
                                    <td>EDU ALLOW</td>
                                    <td>EPF SALARY</td>
                                    <td>HRA</td>
                                    <td>OTHERS/ARREAR</td>
                                    <td>GROSS TOTAL</td>
                                </tr>
                                <tr>
                                    <td>FPF UAN</td>
                                    <td><b>CONVENCE</b></td>
                                    <td><b><?= $result->CONV ?></b></td>
                                    <td><?= $result->BASIC ?></td>
                                    <td><?= $result->CONV ?></td>
                                    <td></td>
                                    <td><?= $result->PFAMT ?></td>
                                    <td><?= $result->HRA ?></td>
                                    <td></td>
                                    <td><?= $result->GROSS ?></td>
                                    <td rowspan="3"><?= $result->NET ?></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td><b>EDU ALLOW</b></td>
                                    <td><b></b></td>
                                    <td rowspan="2"><b>DEDUCTION</b></td>
                                    <td>EPF</td>
                                    <td>ESI</td>
                                    <td>P.TAX</td>
                                    <td>ADVANCE</td>
                                    <td>OTHERS</td>
                                    <td><?= $result->GROSS ?></td>
                                    <td rowspan="6"></td>
                                </tr>
                                <tr>
                                    <td>ESI INUSRANCE NO</td>
                                    <td><b>EPF SALARY</b></td>
                                    <td><b><?= $result->PFAMT ?></b></td>
                                    <td>EPF</td>
                                    <td>ESI</td>
                                    <td>P.TAX</td>
                                    <td>ADVANCE</td>
                                    <td>OTHERS</td>
                                    <td>TOTAL</td>
                                </tr>
                                <tr>
                                    <td><?= $result->esi_acc_no ?></td>
                                    <td><b>HRA</b></td>
                                    <td><b><?= $result->HRA ?></b></td>
                                    <td rowspan="4"></td>
                                    <td colspan="6"><b>EMPLOYER CONTRIBUTION</b></td>
                                    <td rowspan="4"></td>
                                </tr>
                                <tr>
                                    <td rowspan="3"></td>
                                    <td><b>GROSS SALARY</b></td>
                                    <td><b><?= $result->GROSS ?></b></td>
                                    <td>EPF</td>
                                    <td>PENSION</td>
                                    <td>ESI</td>
                                    <td></td>
                                    <td></td>
                                    <td><b>TOTAL</b></td>
                                </tr>
                                <tr>
                                    <td><b>MONTH DAYS</b></td>
                                    <td><b>SALARY PAID</b></td>
                                    <td><?= $result->PFAMT ?></td>
                                    <td rowspan="2"></td>
                                    <td rowspan="2"></td>
                                    <td rowspan="2"></td>
                                    <td rowspan="2"></td>
                                    <td rowspan="2"></td>
                                </tr>
                                <tr>
                                    <td><?= $result->T8 ?></td>
                                    <td><?= $result->T2 ?></td>
                                </tr>
                                <tr>
                                    <td colspn="2"><b>LEAVE TOTAL DUE</b></td>
                                    <td><?= ($result->cl_granted + $result->el_granted) ?></td>
                                    <td><b>LEAVE ALLOW</b></td>
                                    <td><?= ($result->T4 + $result->T5 + $result->T6) ?></td>
                                    <td><b>LEAVE BALANCE</b></td>
                                    <td><?= ($result->cl_granted + $result->el_granted) - ($result->T4 + $result->T5 + $result->T6) ?></td>
                                    <td colspan="2"><b>TOTAL ADVANCE TAKEN</b></td>
                                    <td>0</td>
                                    <td><b>ADVANCE BALANCE</b></td>
                                    <td>0</td>
                                </tr>
                        </tbody>
            </table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php }
		            
		        }
	        }
			?>
		</div>
	</section>
</div>
</body>
		<?php
	} ?>

</html>